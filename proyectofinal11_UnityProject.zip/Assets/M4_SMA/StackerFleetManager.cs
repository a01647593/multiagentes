using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace RoboArenaM4
{
    [Serializable]
    public class ExperimentResult
    {
        public string strategyName;
        public float duration;
        public int completedMissions;
        public float throughput;
        public float averageMissionTime;
        public float averageUtilization;
        public float averageDistance;
        public float averageBatteryEnd;
        public int waitEvents;
        public int chargeEvents;
    }

    public class StackerFleetManager : MonoBehaviour
    {
        public enum DecisionStrategy { BaselineNearest, ProposedHeuristic }
        public enum ExperimentMode { AutomaticComparison, BaselineOnly, ProposedOnly }

        [Header("Experimento M4")]
        public ExperimentMode experimentMode = ExperimentMode.AutomaticComparison;
        public DecisionStrategy strategy = DecisionStrategy.BaselineNearest;
        public StackerAgent[] agents;
        public float experimentDuration = 60f;
        public float publishInterval = 1.0f;

        [Header("Modo presentacion")]
        public bool presentationMode = true;
        public float presentationRunDuration = 120f;
        public bool createLiveCameras = true;
        public bool autoSaveCsv = true;

        [Header("HUD")]
        [Tooltip("Ajuste fino del tamano del HUD. 1 = automatico segun la resolucion. " +
                 "Sube a 1.3 si lo quieres mas grande, baja a 0.8 si estorba.")]
        [Range(0.5f, 2.5f)] public float hudTamano = 1f;

        [Header("Evento dinamico")]
        [Tooltip("Peatones que recorren pasillos completos. El enunciado pide al menos una condicion dinamica.")]
        public int peatones = 3;

        [Header("Estado actual")]
        public int completedMissions;
        public int waitEvents;
        public int chargeEvents;

        [Header("Resultados")]
        [NonSerialized] public ExperimentResult baselineResult;
        [NonSerialized] public ExperimentResult proposedResult;

        readonly List<M4Mission> missions = new List<M4Mission>();
        readonly List<GameObject> deliveredPallets = new List<GameObject>();

        class PalletHome
        {
            public GameObject pallet;
            public Transform parent;
            public Vector3 localPosition;
            public Quaternion localRotation;
            public Vector3 localScale;
            public bool activeSelf;
            public string rackName;
            public Vector3 initialWorldPosition;
            public Collider[] colliders;
            public bool[] colliderEnabled;
        }

        readonly List<PalletHome> rackPalletHomes = new List<PalletHome>();

        float nextPublish;
        float phaseStart;
        float totalMissionTime;
        int nextMissionToRelease;
        bool experimentFinished;

        Vector3[] initialPositions;
        Quaternion[] initialRotations;
        float[] initialBatteries;

        void Start()
        {
            if (presentationMode)
                experimentDuration = Mathf.Max(experimentDuration, presentationRunDuration);

            if (createLiveCameras && GetComponent<M4LiveCameraSystem>() == null)
                gameObject.AddComponent<M4LiveCameraSystem>();

            CaptureRackPallets();
            ConfigurarPeatones();
            WarehouseAStar.Flota = agents;   // el A* ya no busca la flota en la escena
            WarehouseAStar.RebuildNavigation();
            ResetPuestosDeCarga();
            ConfigurarEstacionDeCarga();      // necesita la rejilla ya construida
            baselineResult = null;
            proposedResult = null;
            CaptureInitialState();

            if (experimentMode == ExperimentMode.AutomaticComparison)
                BeginRun(DecisionStrategy.BaselineNearest);
            else if (experimentMode == ExperimentMode.BaselineOnly)
                BeginRun(DecisionStrategy.BaselineNearest);
            else
                BeginRun(DecisionStrategy.ProposedHeuristic);
        }

        void Update()
        {
            ActualizarLucesDeCarga();

            if (experimentFinished)
                return;

            float elapsed = Time.time - phaseStart;
            if (elapsed >= experimentDuration)
            {
                EndCurrentRun();
                return;
            }

            if (Time.time < nextPublish)
                return;

            nextPublish = Time.time + publishInterval;

            // Se liberan misiones gradualmente para mantener el sistema dinamico.
            if (nextMissionToRelease < missions.Count)
                nextMissionToRelease = Mathf.Min(missions.Count, nextMissionToRelease + 2);

            PublicarMisionesPendientes();
        }

        void CaptureInitialState()
        {
            if (agents == null)
                agents = new StackerAgent[0];

            initialPositions = new Vector3[agents.Length];
            initialRotations = new Quaternion[agents.Length];
            initialBatteries = new float[agents.Length];

            for (int i = 0; i < agents.Length; i++)
            {
                if (agents[i] == null)
                    continue;

                initialPositions[i] = agents[i].transform.position;
                initialRotations[i] = agents[i].transform.rotation;
                initialBatteries[i] = agents[i].battery;
            }
        }

        void BeginRun(DecisionStrategy newStrategy)
        {
            strategy = newStrategy;
            experimentFinished = false;
            completedMissions = 0;
            waitEvents = 0;
            chargeEvents = 0;
            totalMissionTime = 0f;
            nextMissionToRelease = 0;

            RestoreRackPallets();
            ClearDeliveredPallets();
            ResetPuestosDeCarga();   // ambas estrategias arrancan con la estacion vacia
            missions.Clear();
            BuildMissions();

            for (int i = 0; i < agents.Length; i++)
            {
                if (agents[i] == null)
                    continue;

                agents[i].transform.position = initialPositions[i];
                agents[i].transform.rotation = initialRotations[i];
                agents[i].battery = initialBatteries[i];
                agents[i].manager = this;
                agents[i].ResetRuntimeState();
            }

            ResetDynamicEvents();

            phaseStart = Time.time;
            nextPublish = Time.time + publishInterval;

            // Misma liberacion inicial para ambas estrategias.
            nextMissionToRelease = Mathf.Min(missions.Count, agents.Length);
            PublicarMisionesPendientes();

            Debug.Log("[M4] Inicia " + strategy + " con " + agents.Length + " AGV y " + missions.Count + " misiones.");
        }

        void ResetDynamicEvents()
        {
            // Se reutiliza la lista que ya armo ConfigurarPeatones: nada de buscar en
            // toda la escena, y sin la API deprecada.
            for (int i = 0; i < peatonesEnEscena.Count; i++)
                if (peatonesEnEscena[i] != null)
                    peatonesEnEscena[i].ResetPedestrian();
        }

        void PublicarMisionesPendientes()
        {
            // Primero se publican las misiones de prioridad mayor.
            for (int priority = 3; priority >= 1; priority--)
            {
                for (int m = 0; m < nextMissionToRelease; m++)
                {
                    if (missions[m].status != MissionStatus.Pending)
                        continue;

                    if (missions[m].priority != priority)
                        continue;

                    Publicar(missions[m]);
                }
            }
        }

        // =====================================================================
        //  EL MISSION MANAGER NO DECIDE
        //
        //  Antes, TryAuction() recorria a los agentes, les pedia su puja, comparaba,
        //  elegia un ganador y llamaba winner.AcceptMission(). El comentario decia
        //  "El Mission Manager publica la mision", pero quien adjudicaba era el
        //  gestor: un decisor centralizado, que es justo lo que el reto prohibe.
        //
        //  Ahora Publicar() SOLO AVISA. La decision vive en el agente, en
        //  StackerAgent.AlPublicarseMision(): cada AGV arma el tablero con lo que
        //  publican los demas, calcula la utilidad de todos y se auto-adjudica solo
        //  si el maximo es el suyo. Ningun metodo de esta clase elige agente.
        // =====================================================================
        void Publicar(M4Mission mission)
        {
            if (agents == null || mission == null)
                return;

            for (int i = 0; i < agents.Length; i++)
            {
                if (agents[i] == null)
                    continue;

                if (mission.status != MissionStatus.Pending)
                    break;   // ya se la auto-adjudico alguien

                agents[i].AlPublicarseMision(mission, agents);
            }
        }

        // =====================================================================
        //  ESTACION DE CARGA: RECURSO FISICO LIMITADO
        //  Antes GoCharge() mandaba a todos al mismo punto sin limite de plazas.
        // =====================================================================
        int[] puestosDeCarga;

        void ResetPuestosDeCarga()
        {
            if (puestosDeCarga == null || puestosDeCarga.Length != M4Params.PUESTOS_DE_CARGA)
                puestosDeCarga = new int[M4Params.PUESTOS_DE_CARGA];

            for (int i = 0; i < puestosDeCarga.Length; i++)
                puestosDeCarga[i] = 0;   // 0 = libre
        }

        public int PuestosLibres()
        {
            if (puestosDeCarga == null)
                return M4Params.PUESTOS_DE_CARGA;

            int n = 0;
            for (int i = 0; i < puestosDeCarga.Length; i++)
                if (puestosDeCarga[i] == 0) n++;
            return n;
        }

        public bool PedirPuestoDeCarga(StackerAgent quien, out int puesto)
        {
            puesto = -1;
            if (quien == null)
                return false;

            if (puestosDeCarga == null)
                ResetPuestosDeCarga();

            for (int i = 0; i < puestosDeCarga.Length; i++)
            {
                if (puestosDeCarga[i] == 0 || puestosDeCarga[i] == quien.agentId)
                {
                    puestosDeCarga[i] = quien.agentId;
                    puesto = i;
                    return true;
                }
            }
            return false;
        }

        public void LiberarPuestoDeCarga(StackerAgent quien, int puesto)
        {
            if (quien == null || puestosDeCarga == null)
                return;

            if (puesto >= 0 && puesto < puestosDeCarga.Length &&
                puestosDeCarga[puesto] == quien.agentId)
                puestosDeCarga[puesto] = 0;
        }

        /// <summary>Posicion fisica de una plaza de carga, ajustada a una celda
        /// transitable para que el AGV nunca quede dentro del modelo de la estacion.</summary>
        public Vector3 PosicionPuestoDeCarga(int puesto)
        {
            if (puestosPos == null || puesto < 0 || puesto >= puestosPos.Length)
                return M4Params.APROXIMACION_CARGA;

            return puestosPos[puesto];
        }

        // =====================================================================
        //  ESTACION DE CARGA VISIBLE: DOS PUESTOS
        //
        //  El enunciado pide puntos de carga en la simulacion 3D. Antes solo habia
        //  un cilindro decorativo en (9.8, 9.4) y GoCharge() mandaba a todos los AGV
        //  al mismo punto: ni se veian los puestos, ni habia limite.
        //
        //  Ahora las dos plazas se calculan UNA vez (despues de construir la rejilla,
        //  porque se ajustan a celda transitable) y la geometria se construye
        //  exactamente sobre esas mismas coordenadas. Visual y logica no pueden
        //  desalinearse: el marcador esta donde el AGV realmente aparca.
        //
        //  La luz de cada puesto es verde si esta libre y roja si esta ocupado, asi
        //  que la disputa por el recurso se VE, no solo se cuenta.
        //
        //  Todo el conjunto se construye SIN colliders a proposito: es senalizacion.
        //  El limite de plazas se impone por logica (PedirPuestoDeCarga), no
        //  poniendo obstaculos que podrian romper la navegacion.
        // =====================================================================
        Vector3[] puestosPos;
        Transform estacionRaiz;
        Renderer[] lucesPuesto;
        Material matLuzLibre;
        Material matLuzOcupado;

        public void ConfigurarEstacionDeCarga()
        {
            int n = M4Params.PUESTOS_DE_CARGA;
            puestosPos = new Vector3[n];

            const float sep = 1.05f;
            for (int i = 0; i < n; i++)
            {
                float dx = (i - (n - 1) * 0.5f) * sep;
                Vector3 deseada = new Vector3(8.4f + dx,
                                              M4Params.APROXIMACION_CARGA.y,
                                              M4Params.APROXIMACION_CARGA.z);
                puestosPos[i] = WarehouseAStar.SnapToFreePoint(deseada);
            }

            ConstruirEstacionVisual();
        }

        static Material MatSimple(Color c, Color emision)
        {
            Shader sh = Shader.Find("Universal Render Pipeline/Lit");
            if (sh == null) sh = Shader.Find("Standard");
            if (sh == null) sh = Shader.Find("Diffuse");

            Material m = new Material(sh);
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
            if (m.HasProperty("_Color")) m.SetColor("_Color", c);

            if (emision.maxColorComponent > 0.01f)
            {
                m.EnableKeyword("_EMISSION");
                if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", emision);
            }
            return m;
        }

        static GameObject Pieza(PrimitiveType tipo, string nombre, Transform padre,
                                Vector3 escala, Vector3 posicion, Material mat)
        {
            GameObject g = GameObject.CreatePrimitive(tipo);
            g.name = nombre;
            g.transform.SetParent(padre, true);
            g.transform.position = posicion;
            g.transform.localScale = escala;

            // Sin collider: es senalizacion, no debe estorbar a la navegacion.
            Collider col = g.GetComponent<Collider>();
            if (col != null)
            {
                // En el editor (fuera de Play) hay que usar DestroyImmediate.
                if (Application.isPlaying) Destroy(col);
                else DestroyImmediate(col);
            }

            Renderer r = g.GetComponent<Renderer>();
            if (r != null && mat != null) r.sharedMaterial = mat;

            return g;
        }

        void ConstruirEstacionVisual()
        {
            if (estacionRaiz != null || puestosPos == null)
                return;

            // Si la estacion ya esta construida en la escena (menu del editor), se
            // ADOPTA en vez de duplicarla: se recuperan sus balizas por nombre.
            GameObject yaEnEscena = GameObject.Find("ESTACION_DE_CARGA_M4");
            if (yaEnEscena != null)
            {
                estacionRaiz = yaEnEscena.transform;
                matLuzLibre   = MatSimple(new Color(0.10f, 0.85f, 0.30f), new Color(0.10f, 0.90f, 0.30f));
                matLuzOcupado = MatSimple(new Color(0.90f, 0.12f, 0.10f), new Color(0.95f, 0.12f, 0.10f));
                lucesPuesto = new Renderer[puestosPos.Length];

                for (int i = 0; i < puestosPos.Length; i++)
                {
                    Transform luzT = estacionRaiz.Find("Puesto_" + (i + 1) + "_Estado");
                    if (luzT != null) lucesPuesto[i] = luzT.GetComponent<Renderer>();
                }
                return;
            }

            GameObject raiz = new GameObject("ESTACION_DE_CARGA_M4");
            estacionRaiz = raiz.transform;

            Material matPiso   = MatSimple(new Color(0.09f, 0.42f, 0.30f), Color.black);
            Material matBorde  = MatSimple(new Color(0.90f, 0.72f, 0.06f), Color.black);
            Material matPoste  = MatSimple(new Color(0.20f, 0.21f, 0.23f), Color.black);
            Material matCable  = MatSimple(new Color(0.07f, 0.07f, 0.08f), Color.black);
            matLuzLibre   = MatSimple(new Color(0.10f, 0.85f, 0.30f), new Color(0.10f, 0.90f, 0.30f));
            matLuzOcupado = MatSimple(new Color(0.90f, 0.12f, 0.10f), new Color(0.95f, 0.12f, 0.10f));

            lucesPuesto = new Renderer[puestosPos.Length];

            for (int i = 0; i < puestosPos.Length; i++)
            {
                Vector3 p = puestosPos[i];

                // Plaza pintada en el piso, con dos franjas amarillas de delimitacion.
                Pieza(PrimitiveType.Cube, "Puesto_" + (i + 1) + "_Plaza", estacionRaiz,
                      new Vector3(1.15f, 0.02f, 2.30f), new Vector3(p.x, 0.015f, p.z), matPiso);

                for (int lado = -1; lado <= 1; lado += 2)
                    Pieza(PrimitiveType.Cube, "Puesto_" + (i + 1) + "_Franja", estacionRaiz,
                          new Vector3(0.09f, 0.025f, 2.30f),
                          new Vector3(p.x + 0.62f * lado, 0.018f, p.z), matBorde);

                // Poste cargador detras de la plaza, fuera del area navegable.
                float zPoste = p.z + 1.42f;
                Pieza(PrimitiveType.Cube, "Puesto_" + (i + 1) + "_Base", estacionRaiz,
                      new Vector3(0.52f, 0.10f, 0.42f), new Vector3(p.x, 0.05f, zPoste), matPoste);
                Pieza(PrimitiveType.Cube, "Puesto_" + (i + 1) + "_Columna", estacionRaiz,
                      new Vector3(0.34f, 1.25f, 0.28f), new Vector3(p.x, 0.72f, zPoste), matPoste);
                Pieza(PrimitiveType.Cube, "Puesto_" + (i + 1) + "_Pantalla", estacionRaiz,
                      new Vector3(0.26f, 0.20f, 0.05f), new Vector3(p.x, 1.10f, zPoste - 0.17f), matCable);
                Pieza(PrimitiveType.Cylinder, "Puesto_" + (i + 1) + "_Cable", estacionRaiz,
                      new Vector3(0.05f, 0.34f, 0.05f), new Vector3(p.x + 0.22f, 0.62f, zPoste - 0.20f), matCable);

                // Baliza de estado: verde libre / rojo ocupado.
                GameObject luz = Pieza(PrimitiveType.Sphere, "Puesto_" + (i + 1) + "_Estado",
                                       estacionRaiz, new Vector3(0.22f, 0.22f, 0.22f),
                                       new Vector3(p.x, 1.46f, zPoste), matLuzLibre);
                lucesPuesto[i] = luz.GetComponent<Renderer>();

                // Rotulo flotante.
                GameObject txt = new GameObject("Puesto_" + (i + 1) + "_Rotulo");
                txt.transform.SetParent(estacionRaiz, true);
                txt.transform.position = new Vector3(p.x, 1.95f, zPoste);
                txt.transform.rotation = Quaternion.Euler(0f, 180f, 0f);

                TextMesh tm = txt.AddComponent<TextMesh>();
                tm.text = "CARGA " + (i + 1);
                tm.anchor = TextAnchor.MiddleCenter;
                tm.alignment = TextAlignment.Center;
                tm.characterSize = 0.10f;
                tm.fontSize = 40;
                tm.color = new Color(0.95f, 0.95f, 0.95f);
            }

            Debug.Log("[M4] Estacion de carga: " + puestosPos.Length +
                      " puestos construidos en " + string.Join(" | ",
                      System.Array.ConvertAll(puestosPos, v => v.ToString("0.0"))));
        }

        void ActualizarLucesDeCarga()
        {
            if (lucesPuesto == null || puestosDeCarga == null)
                return;

            for (int i = 0; i < lucesPuesto.Length && i < puestosDeCarga.Length; i++)
            {
                if (lucesPuesto[i] == null) continue;
                lucesPuesto[i].sharedMaterial = puestosDeCarga[i] == 0 ? matLuzLibre : matLuzOcupado;
            }
        }

        /// <summary>Punto de cola propio de cada AGV, para que los que esperan turno
        /// no se amontonen sobre la misma celda.</summary>
        public Vector3 PuntoDeEsperaDeCarga(int agentId)
        {
            int idx = Mathf.Max(0, agentId - 1);
            Vector3 q = M4Params.APROXIMACION_CARGA + new Vector3(0f, 0f, -1.6f - 0.9f * idx);
            return WarehouseAStar.SnapToFreePoint(q);
        }

        // =====================================================================
        //  EVENTO DINAMICO REAL
        //
        //  Antes habia UN peaton yendo y viniendo entre z=1.35 y z=3.65: 2.3 m sobre
        //  el mismo punto. No obligaba a replanificar a nadie, asi que la condicion
        //  dinamica que pide el enunciado no se veia en la corrida. Ahora son tres
        //  peatones que RECORREN PASILLOS COMPLETOS de extremo a extremo, como en el
        //  notebook. Se configuran en tiempo de ejecucion para que la escena ya
        //  guardada no tenga que reconstruirse.
        // =====================================================================
        //  Recorridos dentro del area navegable real del A* (x en [-9, 9],
        //  z en [-6, 8.25]): los dos pasillos centrales en sentidos opuestos y el
        //  pasillo este en vertical. Son travesias de 14 a 16 m, no un vaiven.
        static readonly Vector3[] PEATON_A = {
            new Vector3(-8.0f, 1.0f,  2.5f),
            new Vector3( 8.0f, 1.0f, -2.5f),
            new Vector3( 7.5f, 1.0f, -5.0f),
        };

        static readonly Vector3[] PEATON_B = {
            new Vector3( 8.0f, 1.0f,  2.5f),
            new Vector3(-8.0f, 1.0f, -2.5f),
            new Vector3( 7.5f, 1.0f,  7.5f),
        };

        readonly List<DynamicPedestrian> peatonesEnEscena = new List<DynamicPedestrian>();

        void ConfigurarPeatones()
        {
            int total = Mathf.Clamp(peatones, 1, PEATON_A.Length);

            // Resources.FindObjectsOfTypeAll no esta deprecada en ninguna version; se
            // filtra por escena valida para no recoger prefabs del proyecto. Es el mismo
            // patron que ya usaba M4SceneSetup.
            List<DynamicPedestrian> lista = new List<DynamicPedestrian>();
            DynamicPedestrian[] todos = Resources.FindObjectsOfTypeAll<DynamicPedestrian>();
            for (int i = 0; i < todos.Length; i++)
                if (todos[i] != null && todos[i].gameObject.scene.IsValid())
                    lista.Add(todos[i]);

            while (lista.Count < total)
                lista.Add(CrearPeaton(lista.Count));

            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i] == null)
                    continue;

                int k = i % total;
                lista[i].pointA = PEATON_A[k];
                lista[i].pointB = PEATON_B[k];
                lista[i].speed = 1.0f + 0.15f * k;
                lista[i].ResetPedestrian();
            }

            peatonesEnEscena.Clear();
            peatonesEnEscena.AddRange(lista);
        }

        DynamicPedestrian CrearPeaton(int index)
        {
            GameObject ped = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            ped.name = "Peaton_Obstaculo_Dinamico_" + (index + 1);
            ped.transform.localScale = new Vector3(0.55f, 0.9f, 0.55f);

            Collider col = ped.GetComponent<Collider>();
            if (col != null)
                col.isTrigger = false;   // solido: los AGV lo detectan y ceden

            Renderer r = ped.GetComponent<Renderer>();
            if (r != null)
            {
                Shader sh = Shader.Find("Universal Render Pipeline/Lit");
                if (sh == null) sh = Shader.Find("Standard");
                if (sh != null)
                {
                    Material mat = new Material(sh);
                    Color c = new Color(0.10f, 0.55f, 0.25f);
                    if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", c);
                    if (mat.HasProperty("_Color")) mat.SetColor("_Color", c);
                    r.sharedMaterial = mat;
                }
            }

            return ped.AddComponent<DynamicPedestrian>();
        }

        void CaptureRackPallets()
        {
            rackPalletHomes.Clear();

            GameObject racksRoot = GameObject.Find("Racks");
            if (racksRoot == null)
            {
                Debug.LogWarning("[M4] No se encontro el objeto Racks. Se usaran misiones de respaldo.");
                return;
            }

            Transform[] all = racksRoot.GetComponentsInChildren<Transform>(true);
            for (int i = 0; i < all.Length; i++)
            {
                Transform t = all[i];
                if (t == null || t.gameObject == racksRoot || t.name != "Tarima")
                    continue;

                string rackName = FindRackName(t);
                if (string.IsNullOrEmpty(rackName))
                    continue;

                Collider[] cols = t.GetComponentsInChildren<Collider>(true);
                bool[] enabled = new bool[cols.Length];
                for (int c = 0; c < cols.Length; c++)
                    enabled[c] = cols[c] != null && cols[c].enabled;

                rackPalletHomes.Add(new PalletHome
                {
                    pallet = t.gameObject,
                    parent = t.parent,
                    localPosition = t.localPosition,
                    localRotation = t.localRotation,
                    localScale = t.localScale,
                    activeSelf = t.gameObject.activeSelf,
                    rackName = rackName,
                    initialWorldPosition = t.position,
                    colliders = cols,
                    colliderEnabled = enabled
                });
            }

            // Orden fijo para que baseline y estrategia propuesta usen exactamente los mismos pallets.
            rackPalletHomes.Sort((a, b) =>
            {
                int rackCompare = string.CompareOrdinal(a.rackName, b.rackName);
                if (rackCompare != 0) return rackCompare;

                int yCompare = a.initialWorldPosition.y.CompareTo(b.initialWorldPosition.y);
                if (yCompare != 0) return yCompare;

                int xCompare = a.initialWorldPosition.x.CompareTo(b.initialWorldPosition.x);
                if (xCompare != 0) return xCompare;

                return a.initialWorldPosition.z.CompareTo(b.initialWorldPosition.z);
            });

            Debug.Log("[M4] Pallets reales detectados dentro de racks: " + rackPalletHomes.Count);
        }

        void RestoreRackPallets()
        {
            for (int i = 0; i < rackPalletHomes.Count; i++)
            {
                PalletHome h = rackPalletHomes[i];
                if (h == null || h.pallet == null)
                    continue;

                h.pallet.transform.SetParent(h.parent, false);
                h.pallet.transform.localPosition = h.localPosition;
                h.pallet.transform.localRotation = h.localRotation;
                h.pallet.transform.localScale = h.localScale;
                h.pallet.SetActive(h.activeSelf);

                if (h.colliders != null && h.colliderEnabled != null)
                {
                    int count = Mathf.Min(h.colliders.Length, h.colliderEnabled.Length);
                    for (int c = 0; c < count; c++)
                    {
                        if (h.colliders[c] != null)
                            h.colliders[c].enabled = h.colliderEnabled[c];
                    }
                }
            }
        }

        static string FindRackName(Transform t)
        {
            Transform current = t != null ? t.parent : null;
            while (current != null)
            {
                if (current.name.StartsWith("Rack_", StringComparison.Ordinal))
                    return current.name;

                current = current.parent;
            }

            return "";
        }

        PalletHome FindHome(GameObject pallet)
        {
            for (int i = 0; i < rackPalletHomes.Count; i++)
                if (rackPalletHomes[i] != null && rackPalletHomes[i].pallet == pallet)
                    return rackPalletHomes[i];

            return null;
        }

        Vector3 RackPickupPoint(PalletHome h)
        {
            if (h == null || h.pallet == null)
                return Vector3.zero;

            Vector3 palletWorld = h.initialWorldPosition;
            Transform rack = h.parent;

            while (rack != null && !rack.name.StartsWith("Rack_", StringComparison.Ordinal))
                rack = rack.parent;

            Vector3 desired;

            if (rack == null)
            {
                desired = new Vector3(palletWorld.x, 0.05f, palletWorld.z);
            }
            else if (h.rackName.StartsWith("Rack_F", StringComparison.Ordinal))
            {
                // Se separa mas del rack para que el SphereCast frontal no lea
                // el rack como obstaculo cuando ya llego al punto de pickup.
                float side = h.rackName.EndsWith("_A", StringComparison.Ordinal) ? -1.85f : 1.85f;
                desired = new Vector3(palletWorld.x, 0.05f, rack.position.z + side);
            }
            else if (h.rackName.StartsWith("Rack_Este", StringComparison.Ordinal))
            {
                desired = new Vector3(rack.position.x - 1.85f, 0.05f, palletWorld.z);
            }
            else
            {
                desired = new Vector3(palletWorld.x, 0.05f, palletWorld.z);
            }

            return WarehouseAStar.SnapToFreePoint(desired);
        }

        void BuildMissions()
        {
            // Posiciones fisicas donde queda la tarima.
            Vector3[] palletDropoffs =
            {
                P(-8.25f, -5.85f), P(-7.70f, -5.20f), P(-8.65f, -4.85f), // D1 izquierda
                P(-3.35f, -5.85f), P(-2.75f, -5.20f), P(-3.75f, -4.85f), // D2 izquierda
                P( 2.65f, -5.85f), P( 3.25f, -5.20f), P( 2.25f, -4.85f), // D3 derecha
                P( 7.55f, -5.85f), P( 8.15f, -5.20f), P( 7.15f, -4.85f)  // D4 derecha
            };

            // El AGV NO intenta meterse dentro de la banda/slot. Se detiene en
            // un punto transitable frente a la salida y desde ahi hace la descarga.
            Vector3[] dropoffs = new Vector3[palletDropoffs.Length];
            for (int i = 0; i < palletDropoffs.Length; i++)
            {
                Vector3 desiredApproach = palletDropoffs[i] + new Vector3(0f, 0f, 1.35f);
                dropoffs[i] = WarehouseAStar.SnapToFreePoint(desiredApproach);
            }

            string[] dropNames =
            {
                "D1-A", "D1-B", "D1-C",
                "D2-A", "D2-B", "D2-C",
                "D3-A", "D3-B", "D3-C",
                "D4-A", "D4-B", "D4-C"
            };

            // Se priorizan pallets de los dos primeros niveles para que la demostracion
            // se vea creible con el stacker y haya pallets suficientes para varias misiones.
            List<PalletHome> candidates = new List<PalletHome>();
            for (int i = 0; i < rackPalletHomes.Count; i++)
            {
                PalletHome h = rackPalletHomes[i];
                if (h == null || h.pallet == null || !h.activeSelf)
                    continue;

                float localY = h.localPosition.y;
                if (localY <= 1.35f)
                    candidates.Add(h);
            }

            // Si no hay suficientes en niveles bajos, se completan con niveles superiores.
            if (candidates.Count < 36)
            {
                for (int i = 0; i < rackPalletHomes.Count && candidates.Count < 36; i++)
                {
                    PalletHome h = rackPalletHomes[i];
                    if (h == null || h.pallet == null || candidates.Contains(h))
                        continue;

                    candidates.Add(h);
                }
            }

            // Reordenamiento round-robin por rack para que las primeras 6 misiones
            // salgan de racks diferentes y todos los AGV tengan trabajo distribuido.
            Dictionary<string, Queue<PalletHome>> byRack = new Dictionary<string, Queue<PalletHome>>();
            for (int i = 0; i < candidates.Count; i++)
            {
                PalletHome h = candidates[i];
                if (!byRack.ContainsKey(h.rackName))
                    byRack[h.rackName] = new Queue<PalletHome>();

                byRack[h.rackName].Enqueue(h);
            }

            List<string> rackKeys = new List<string>(byRack.Keys);
            rackKeys.Sort(StringComparer.Ordinal);

            List<PalletHome> ordered = new List<PalletHome>();
            bool added = true;
            while (added && ordered.Count < 36)
            {
                added = false;
                for (int r = 0; r < rackKeys.Count && ordered.Count < 36; r++)
                {
                    Queue<PalletHome> q = byRack[rackKeys[r]];
                    if (q.Count == 0)
                        continue;

                    ordered.Add(q.Dequeue());
                    added = true;
                }
            }

            // Alterna izquierda/derecha en las primeras misiones:
            // D1, D4, D2, D3... para mostrar ambos lados desde el inicio.
            int[] dropOrder = { 0, 9, 3, 6, 1, 10, 4, 7, 2, 11, 5, 8 };

            int missionCount = Mathf.Min(36, ordered.Count);
            for (int i = 0; i < missionCount; i++)
            {
                PalletHome h = ordered[i];
                int d = dropOrder[i % dropOrder.Length];
                int priority = 3 - (i % 3);

                Add(
                    i + 1,
                    RackPickupPoint(h),
                    dropoffs[d],
                    priority,
                    dropNames[d],
                    h.pallet,
                    h.rackName,
                    palletDropoffs[d]);
            }

            // Respaldo para no dejar la simulacion vacia si el nombre/hierarquia de racks cambia.
            if (missions.Count == 0)
            {
                Debug.LogWarning("[M4] No se detectaron Tarimas dentro de Racks. Se crean misiones de respaldo.");
                Add(1, P(-5f, 2.5f), dropoffs[0], 3, dropNames[0]);
                Add(2, P( 1f, 2.5f), dropoffs[9], 3, dropNames[9]);
                Add(3, P(-2f,-2.5f), dropoffs[3], 2, dropNames[3]);
                Add(4, P(4.8f,-2.5f), dropoffs[6], 2, dropNames[6]);
            }

            Debug.Log("[M4] Misiones rack->salida creadas: " + missions.Count +
                      ". Cada mision toma una Tarima real del rack.");
        }

        static Vector3 P(float x, float z)
        {
            return new Vector3(x, 0.05f, z);
        }

        void Add(
            int id,
            Vector3 pickup,
            Vector3 dropoff,
            int priority,
            string dropoffName = "",
            GameObject sourcePallet = null,
            string pickupName = "",
            Vector3? palletDropoff = null)
        {
            M4Mission m = new M4Mission(id, pickup, dropoff, priority, dropoffName, sourcePallet, pickupName);
            m.palletDropoff = palletDropoff.HasValue ? palletDropoff.Value : dropoff;
            missions.Add(m);
        }

        public void NotifyMissionCompleted(StackerAgent agent, M4Mission mission)
        {
            NotifyMissionCompleted(agent, mission, mission != null ? mission.dropoff : Vector3.zero, null);
        }

        public void NotifyMissionCompleted(StackerAgent agent, M4Mission mission, Vector3 deliveredWorldPosition)
        {
            NotifyMissionCompleted(agent, mission, deliveredWorldPosition, null);
        }

        public void NotifyMissionCompleted(
            StackerAgent agent,
            M4Mission mission,
            Vector3 deliveredWorldPosition,
            GameObject deliveredSourcePallet)
        {
            if (mission == null)
                return;

            mission.status = MissionStatus.Completed;
            mission.completedAt = Time.time;

            if (deliveredSourcePallet != null)
                PlaceDeliveredRuntimePallet(mission, deliveredSourcePallet);
            else
                SpawnDeliveredPallet(mission, deliveredWorldPosition);

            completedMissions++;
            totalMissionTime += mission.completedAt - mission.startedAt;

            Debug.Log("[M4] Mision " + mission.id + " completada por AGV " + agent.agentId +
                      " | " + mission.pickupName + " -> " + mission.dropoffName);
        }

        void PlaceDeliveredRuntimePallet(M4Mission mission, GameObject pallet)
        {
            if (mission == null || pallet == null)
                return;

            int stack = 0;
            for (int i = 0; i < deliveredPallets.Count; i++)
            {
                GameObject old = deliveredPallets[i];
                if (old == null)
                    continue;

                Vector3 p = old.transform.position;
                if (Vector3.Distance(new Vector3(p.x, 0f, p.z),
                                     new Vector3(mission.palletDropoff.x, 0f, mission.palletDropoff.z)) < 0.35f)
                    stack++;
            }

            pallet.transform.SetParent(null, true);
            pallet.transform.position = new Vector3(mission.palletDropoff.x, 0.10f + stack * 0.16f, mission.palletDropoff.z);
            pallet.transform.rotation = Quaternion.identity;
            pallet.name = "Pallet_Entregado_M" + mission.id + "_" + mission.dropoffName;

            Collider[] cols = pallet.GetComponentsInChildren<Collider>(true);
            for (int c = 0; c < cols.Length; c++)
                if (cols[c] != null)
                    cols[c].enabled = false;

            deliveredPallets.Add(pallet);
            Debug.Log("[PALLET] Tarima visible dejada en " + mission.dropoffName);
        }

        void SpawnDeliveredPallet(M4Mission mission, Vector3 deliveredWorldPosition)
        {
            if (mission == null || string.IsNullOrEmpty(mission.dropoffName) || !mission.dropoffName.StartsWith("D"))
                return;

            int stack = 0;
            for (int i = 0; i < deliveredPallets.Count; i++)
            {
                GameObject old = deliveredPallets[i];
                if (old != null && Vector3.Distance(new Vector3(old.transform.position.x, 0f, old.transform.position.z),
                                                     new Vector3(deliveredWorldPosition.x, 0f, deliveredWorldPosition.z)) < 0.35f)
                    stack++;
            }

            GameObject pallet = GameObject.CreatePrimitive(PrimitiveType.Cube);
            pallet.name = "Pallet_Entregado_M" + mission.id + "_" + mission.dropoffName;
            Vector3 finalDrop = mission.palletDropoff;
            pallet.transform.position = new Vector3(finalDrop.x, 0.12f + stack * 0.16f, finalDrop.z);
            pallet.transform.localScale = new Vector3(0.72f, 0.14f, 0.90f);

            Collider c = pallet.GetComponent<Collider>();
            if (c != null) Destroy(c);

            Renderer r = pallet.GetComponent<Renderer>();
            if (r != null)
            {
                Shader shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null) shader = Shader.Find("Standard");
                if (shader == null) shader = Shader.Find("Sprites/Default");

                if (shader != null)
                {
                    Material mat = new Material(shader);
                    mat.color = new Color(0.58f, 0.34f, 0.16f);
                    r.material = mat;
                }
            }

            deliveredPallets.Add(pallet);
        }

        void ClearDeliveredPallets()
        {
            for (int i = 0; i < deliveredPallets.Count; i++)
            {
                if (deliveredPallets[i] != null)
                    Destroy(deliveredPallets[i]);
            }
            deliveredPallets.Clear();
        }

        public void NotifyWaitEvent()
        {
            waitEvents++;
        }

        public void NotifyChargeEvent()
        {
            chargeEvents++;
        }

        void EndCurrentRun()
        {
            ExperimentResult result = CollectResult();

            if (strategy == DecisionStrategy.BaselineNearest)
                baselineResult = result;
            else
                proposedResult = result;

            DebugResult(result);

            if (experimentMode == ExperimentMode.AutomaticComparison &&
                strategy == DecisionStrategy.BaselineNearest)
            {
                BeginRun(DecisionStrategy.ProposedHeuristic);
                return;
            }

            experimentFinished = true;

            for (int i = 0; i < agents.Length; i++)
                if (agents[i] != null)
                    agents[i].StopForExperiment();

            if (autoSaveCsv)
                SaveResultsCsv();

            Debug.Log("[M4] Experimento terminado. La tabla final aparece en Game View.");
        }

        ExperimentResult CollectResult()
        {
            float elapsed = Mathf.Max(0.01f, Mathf.Min(experimentDuration, Time.time - phaseStart));
            float utilization = 0f;
            float distance = 0f;
            float battery = 0f;
            int valid = 0;

            for (int i = 0; i < agents.Length; i++)
            {
                if (agents[i] == null)
                    continue;

                valid++;
                utilization += agents[i].ActiveTime / elapsed * 100f;
                distance += agents[i].DistanceTravelled;
                battery += agents[i].battery;
            }

            if (valid > 0)
            {
                utilization /= valid;
                distance /= valid;
                battery /= valid;
            }

            return new ExperimentResult
            {
                strategyName = strategy.ToString(),
                duration = elapsed,
                completedMissions = completedMissions,
                throughput = completedMissions / elapsed,
                averageMissionTime = completedMissions > 0 ? totalMissionTime / completedMissions : 0f,
                averageUtilization = utilization,
                averageDistance = distance,
                averageBatteryEnd = battery,
                waitEvents = waitEvents,
                chargeEvents = chargeEvents
            };
        }

        void DebugResult(ExperimentResult r)
        {
            Debug.Log("[RESULTADO " + r.strategyName + "] " +
                      "Misiones=" + r.completedMissions +
                      " | Throughput=" + r.throughput.ToString("0.000") +
                      " | Tprom=" + r.averageMissionTime.ToString("0.0") +
                      " | Util=" + r.averageUtilization.ToString("0.0") + "%" +
                      " | Dist=" + r.averageDistance.ToString("0.0") +
                      " | Esperas=" + r.waitEvents);
        }

        float CurrentElapsed()
        {
            float elapsed = Time.time - phaseStart;
            if (experimentFinished) elapsed = experimentDuration;
            return Mathf.Max(0.01f, Mathf.Min(experimentDuration, elapsed));
        }

        void CurrentMetrics(out float throughput, out float avgMission, out float avgBattery, out float utilization, out float avgDistance, out int active)
        {
            float elapsed = CurrentElapsed();
            throughput = completedMissions / elapsed;
            avgMission = completedMissions > 0 ? totalMissionTime / completedMissions : 0f;
            avgBattery = 0f;
            utilization = 0f;
            avgDistance = 0f;
            active = 0;
            int valid = 0;

            for (int i = 0; i < agents.Length; i++)
            {
                if (agents[i] == null)
                    continue;

                valid++;
                avgBattery += agents[i].battery;
                utilization += agents[i].ActiveTime / elapsed * 100f;
                avgDistance += agents[i].DistanceTravelled;

                if (agents[i].state != StackerState.Idle && agents[i].state != StackerState.Charging)
                    active++;
            }

            if (valid > 0)
            {
                avgBattery /= valid;
                utilization /= valid;
                avgDistance /= valid;
            }
        }

        void OnGUI()
        {
            // Se escala TODO el GUI de una vez -panel de metricas y tabla comparativa-
            // en vez de reposicionar cada Rect a mano. Asi el HUD se lee de lejos en
            // una presentacion sin tocar el resto del codigo.
            float e = EscalaHud();

            Matrix4x4 matrizPrevia = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity,
                                       new Vector3(e, e, 1f));

            DibujarHud();

            GUI.matrix = matrizPrevia;
        }

        /// <summary>
        /// El HUD se dibuja con coordenadas de pixel fijas, asi que en una vista 4K
        /// (2160 px de alto) salia diminuto y en 720p tapaba media pantalla. Un
        /// numero fijo no sirve: la escala se deriva de la resolucion real, tomando
        /// 900 px de alto como referencia, y hudTamano solo afina por encima de eso.
        /// </summary>
        float EscalaHud()
        {
            float porResolucion = Mathf.Clamp(Screen.height / 900f, 1f, 3.2f);
            return porResolucion * Mathf.Max(0.3f, hudTamano);
        }

        void DibujarHud()
        {
            float throughput;
            float avgMission;
            float avgBattery;
            float utilization;
            float avgDistance;
            int active;
            CurrentMetrics(out throughput, out avgMission, out avgBattery, out utilization, out avgDistance, out active);

            GUI.Box(new Rect(12, 12, 440, 322), "M4 - Sistema Multiagente");
            GUI.Label(new Rect(25, 38, 390, 22), "Fase: " + (experimentFinished ? "FINALIZADA" : strategy.ToString()));
            GUI.Label(new Rect(25, 60, 390, 22), "Problema: asignacion + congestion entre AGV");
            GUI.Label(new Rect(25, 82, 390, 22), "AGV activos: " + active + "/" + agents.Length);
            GUI.Label(new Rect(25, 104, 390, 22), "Misiones: " + completedMissions + "/" + missions.Count);
            GUI.Label(new Rect(25, 126, 390, 22), "Throughput: " + throughput.ToString("0.000") + " mis/s");
            GUI.Label(new Rect(25, 148, 390, 22), "Tiempo prom.: " + avgMission.ToString("0.0") + " s");
            GUI.Label(new Rect(25, 170, 390, 22), "Utilizacion: " + utilization.ToString("0.0") + "%");
            GUI.Label(new Rect(25, 192, 390, 22), "Distancia prom.: " + avgDistance.ToString("0.0") + " m");
            GUI.Label(new Rect(25, 214, 390, 22), "Bateria prom.: " + avgBattery.ToString("0") + "% | Esperas: " + waitEvents);
            // El HUD anunciaba la formula vieja (U=-0.55D+8B-3C-6R), que ya no existe.
            // Ahora muestra lo que el enunciado califica: que la decision es
            // descentralizada, que formula se esta usando y el estado del recurso
            // en disputa.
            GUI.Label(new Rect(25, 236, 415, 22), "Decision: DESCENTRALIZADA (cada AGV se auto-adjudica)");
            GUI.Label(new Rect(25, 258, 415, 22), strategy == DecisionStrategy.ProposedHeuristic
                ? "U = -40D +15S -15L -20C +10P  (min-max entre candidatos)"
                : "Baseline: gana el mas cercano  (U = -D)");
            GUI.Label(new Rect(25, 280, 415, 22), "Filtro energia: B - 1.20E >= 12  |  Carga: " +
                      PuestosLibres() + "/" + M4Params.PUESTOS_DE_CARGA + " plazas libres");
            GUI.Label(new Rect(25, 302, 415, 22), "Evento dinamico: " + peatones +
                      " peatones cruzando pasillos completos");

            if (baselineResult != null || proposedResult != null)
                DrawComparisonTable();
        }

        void DrawComparisonTable()
        {
            float x = 435f;
            float y = 12f;
            float w = 585f;
            float h = 300f;

            GUI.Box(new Rect(x, y, w, h), "Comparacion experimental justa");

            GUI.Label(new Rect(x + 15, y + 30, 190, 22), "Metrica");
            GUI.Label(new Rect(x + 210, y + 30, 120, 22), "Baseline");
            GUI.Label(new Rect(x + 335, y + 30, 120, 22), "Propuesta");
            GUI.Label(new Rect(x + 460, y + 30, 110, 22), "Mejora");

            DrawRow(x, y + 55, "Misiones completadas",
                    baselineResult != null ? baselineResult.completedMissions.ToString() : "-",
                    proposedResult != null ? proposedResult.completedMissions.ToString() : "-",
                    ImprovementHigher(BaselineValue(r => r.completedMissions), ProposedValue(r => r.completedMissions)));

            DrawRow(x, y + 80, "Throughput (mis/s)",
                    Format(BaselineValue(r => r.throughput), "0.000"),
                    Format(ProposedValue(r => r.throughput), "0.000"),
                    ImprovementHigher(BaselineValue(r => r.throughput), ProposedValue(r => r.throughput)));

            DrawRow(x, y + 105, "Tiempo prom. (s)",
                    Format(BaselineValue(r => r.averageMissionTime), "0.0"),
                    Format(ProposedValue(r => r.averageMissionTime), "0.0"),
                    ImprovementLower(BaselineValue(r => r.averageMissionTime), ProposedValue(r => r.averageMissionTime)));

            DrawRow(x, y + 130, "Utilizacion (%)",
                    Format(BaselineValue(r => r.averageUtilization), "0.0"),
                    Format(ProposedValue(r => r.averageUtilization), "0.0"),
                    ImprovementHigher(BaselineValue(r => r.averageUtilization), ProposedValue(r => r.averageUtilization)));

            DrawRow(x, y + 155, "Distancia prom. (m)",
                    Format(BaselineValue(r => r.averageDistance), "0.0"),
                    Format(ProposedValue(r => r.averageDistance), "0.0"),
                    ImprovementLower(BaselineValue(r => r.averageDistance), ProposedValue(r => r.averageDistance)));

            DrawRow(x, y + 180, "Eventos de espera",
                    Format(BaselineValue(r => r.waitEvents), "0"),
                    Format(ProposedValue(r => r.waitEvents), "0"),
                    ImprovementLower(BaselineValue(r => r.waitEvents), ProposedValue(r => r.waitEvents)));

            DrawRow(x, y + 205, "Bateria final (%)",
                    Format(BaselineValue(r => r.averageBatteryEnd), "0.0"),
                    Format(ProposedValue(r => r.averageBatteryEnd), "0.0"),
                    ImprovementHigher(BaselineValue(r => r.averageBatteryEnd), ProposedValue(r => r.averageBatteryEnd)));

            if (experimentFinished)
            {
                if (GUI.Button(new Rect(x + 15, y + 245, 190, 32), "Repetir comparacion"))
                {
                    baselineResult = null;
                    proposedResult = null;
                    BeginRun(experimentMode == ExperimentMode.ProposedOnly
                        ? DecisionStrategy.ProposedHeuristic
                        : DecisionStrategy.BaselineNearest);
                }

                if (GUI.Button(new Rect(x + 215, y + 245, 190, 32), "Guardar CSV"))
                    SaveResultsCsv();
            }
        }

        void DrawRow(float x, float y, string name, string baseline, string proposed, string improvement)
        {
            GUI.Label(new Rect(x + 15, y, 190, 22), name);
            GUI.Label(new Rect(x + 210, y, 120, 22), baseline);
            GUI.Label(new Rect(x + 335, y, 120, 22), proposed);
            GUI.Label(new Rect(x + 460, y, 110, 22), improvement);
        }

        float BaselineValue(Func<ExperimentResult, float> selector)
        {
            return baselineResult != null ? selector(baselineResult) : float.NaN;
        }

        float ProposedValue(Func<ExperimentResult, float> selector)
        {
            return proposedResult != null ? selector(proposedResult) : float.NaN;
        }

        string Format(float value, string format)
        {
            return float.IsNaN(value) ? "-" : value.ToString(format);
        }

        string ImprovementHigher(float baseline, float proposed)
        {
            if (float.IsNaN(baseline) || float.IsNaN(proposed) || Mathf.Abs(baseline) < 0.0001f)
                return "-";

            return ((proposed - baseline) / Mathf.Abs(baseline) * 100f).ToString("+0.0;-0.0;0.0") + "%";
        }

        string ImprovementLower(float baseline, float proposed)
        {
            if (float.IsNaN(baseline) || float.IsNaN(proposed) || Mathf.Abs(baseline) < 0.0001f)
                return "-";

            return ((baseline - proposed) / Mathf.Abs(baseline) * 100f).ToString("+0.0;-0.0;0.0") + "%";
        }

        public void SaveResultsCsv()
        {
            string folder = Path.Combine(Application.dataPath, "M4_SMA");
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder, "resultados_m4.csv");

            CultureInfo inv = CultureInfo.InvariantCulture;
            var lines = new List<string>();
            lines.Add("Metrica,Baseline,Estrategia Propuesta,Mejora");

            if (baselineResult != null && proposedResult != null)
            {
                lines.Add("Misiones completadas," + baselineResult.completedMissions + "," + proposedResult.completedMissions + "," + ImprovementHigher(baselineResult.completedMissions, proposedResult.completedMissions));
                lines.Add("Throughput," + baselineResult.throughput.ToString("0.000", inv) + "," + proposedResult.throughput.ToString("0.000", inv) + "," + ImprovementHigher(baselineResult.throughput, proposedResult.throughput));
                lines.Add("Tiempo promedio mision," + baselineResult.averageMissionTime.ToString("0.000", inv) + "," + proposedResult.averageMissionTime.ToString("0.000", inv) + "," + ImprovementLower(baselineResult.averageMissionTime, proposedResult.averageMissionTime));
                lines.Add("Utilizacion AGV," + baselineResult.averageUtilization.ToString("0.000", inv) + "," + proposedResult.averageUtilization.ToString("0.000", inv) + "," + ImprovementHigher(baselineResult.averageUtilization, proposedResult.averageUtilization));
                lines.Add("Distancia promedio," + baselineResult.averageDistance.ToString("0.000", inv) + "," + proposedResult.averageDistance.ToString("0.000", inv) + "," + ImprovementLower(baselineResult.averageDistance, proposedResult.averageDistance));
                lines.Add("Eventos de espera," + baselineResult.waitEvents + "," + proposedResult.waitEvents + "," + ImprovementLower(baselineResult.waitEvents, proposedResult.waitEvents));
                lines.Add("Bateria final," + baselineResult.averageBatteryEnd.ToString("0.000", inv) + "," + proposedResult.averageBatteryEnd.ToString("0.000", inv) + "," + ImprovementHigher(baselineResult.averageBatteryEnd, proposedResult.averageBatteryEnd));
                lines.Add("Eventos de carga," + baselineResult.chargeEvents + "," + proposedResult.chargeEvents + ",-");
            }
            else
            {
                ExperimentResult r = proposedResult != null ? proposedResult : baselineResult;
                if (r != null)
                {
                    lines.Add("Estrategia," + r.strategyName);
                    lines.Add("Misiones completadas," + r.completedMissions);
                    lines.Add("Throughput," + r.throughput.ToString("0.000", inv));
                    lines.Add("Tiempo promedio mision," + r.averageMissionTime.ToString("0.000", inv));
                    lines.Add("Utilizacion AGV," + r.averageUtilization.ToString("0.000", inv));
                    lines.Add("Distancia promedio," + r.averageDistance.ToString("0.000", inv));
                    lines.Add("Eventos de espera," + r.waitEvents);
                    lines.Add("Bateria final," + r.averageBatteryEnd.ToString("0.000", inv));
                }
            }

            File.WriteAllLines(path, lines.ToArray());
            Debug.Log("[M4] CSV guardado en: " + path);

#if UNITY_EDITOR
            UnityEditor.AssetDatabase.Refresh();
#endif
        }
    }
}
