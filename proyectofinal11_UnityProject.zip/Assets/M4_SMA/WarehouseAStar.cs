using System.Collections.Generic;
using UnityEngine;

namespace RoboArenaM4
{
    // A* decide COMO llegar. La heuristica de pujas decide QUIEN toma la mision.
    // Esta version construye una cuadricula usando los colliders REALES del almacen,
    // por lo que los AGV ya no planean rutas a traves de racks, bandas u obstaculos.
    public static class WarehouseAStar
    {
        const float MinX = -9.0f;
        const float MaxX = 9.0f;
        const float MinZ = -6.0f;
        const float MaxZ = 8.25f;
        const float Cell = 0.75f;
        // Radio de inflado de obstaculos del planeador.
        // NO subir: la banda navegable frente a los andenes (z entre -4.45 y -6) mide
        // 1.55 m, y con un radio mayor se queda sin nodos y los puntos de descarga
        // dejan de ser alcanzables. La garantia de no atravesar estructura NO vive
        // aqui, vive en StackerAgent.PoseLibre(), que comprueba la caja real del
        // vehiculo antes de aplicar cada movimiento y cada giro.
        const float NavRadius = 0.48f;
        const float ProbeY = 0.68f;

        /// <summary>Flota registrada por StackerFleetManager. Evita buscar en toda la
        /// escena en cada planificacion.</summary>
        public static StackerAgent[] Flota;

        static int nx;
        static int nz;
        static Vector3[] nodes;
        static bool[] free;

        // Holgura de cada celda: 0 = pegada a un obstaculo, 1 = totalmente despejada.
        // Sirve para que las rutas prefieran el CENTRO de los pasillos.
        static float[] holgura;

        // Cuanto se penaliza pasar rozando. Comparable al coste de una celda (0.75),
        // asi que despeja la ruta sin provocar rodeos absurdos.
        const float PesoEstrechez = 0.9f;
        static bool built;

        // Cache de costes de ruta. RouteCost() se llama muchisimo mas ahora que la
        // decision es de dos fases (cada AGV evalua a todos los candidatos), y sin
        // cache cada llamada corria un A* completo. El coste solo depende de la
        // geometria estatica -Plan(start, target, null) no aplica penalizacion por
        // agentes- asi que es seguro cachearlo hasta que se reconstruya el grafo.
        static readonly Dictionary<long, float> costCache = new Dictionary<long, float>();

        static long QuantizePoint(Vector3 p)
        {
            long x = (long)Mathf.Round(p.x * 2f) + 4096L;
            long z = (long)Mathf.Round(p.z * 2f) + 4096L;
            return x * 8192L + z;
        }

        static long CostKey(Vector3 a, Vector3 b)
        {
            return QuantizePoint(a) * 100000000L + QuantizePoint(b);
        }

        public static void RebuildNavigation()
        {
            built = false;
            costCache.Clear();
            BuildGraph();
        }

        static void BuildGraph()
        {
            if (built)
                return;

            Physics.SyncTransforms();

            nx = Mathf.RoundToInt((MaxX - MinX) / Cell) + 1;
            nz = Mathf.RoundToInt((MaxZ - MinZ) / Cell) + 1;
            nodes = new Vector3[nx * nz];
            free = new bool[nodes.Length];

            for (int z = 0; z < nz; z++)
            {
                for (int x = 0; x < nx; x++)
                {
                    int id = Index(x, z);
                    Vector3 p = new Vector3(MinX + x * Cell, 0.05f, MinZ + z * Cell);
                    nodes[id] = p;
                    free[id] = !HasStaticObstacle(p, NavRadius);
                }
            }

            // Holgura por celda: fraccion de celdas libres en su vecindario 5x5.
            //
            // POR QUE. NavRadius no se puede subir (la banda frente a los andenes se
            // quedaria sin nodos), asi que el planeador podia trazar rutas pegadas a
            // los puntales. Con un vehiculo de 2.45 m eso hacia que la contencion
            // bloqueara constantemente: frenar, replanear, frenar... que es justo lo
            // que se veia como movimiento sin sentido.
            //
            // Con esta penalizacion las rutas van por el centro del pasillo cuando hay
            // sitio, y solo se pegan cuando no hay alternativa. Ninguna celda deja de
            // ser alcanzable: solo cambia cual se prefiere.
            holgura = new float[nodes.Length];
            for (int z = 0; z < nz; z++)
            {
                for (int x = 0; x < nx; x++)
                {
                    int id = Index(x, z);
                    if (!free[id]) { holgura[id] = 0f; continue; }

                    int libres = 0, total = 0;
                    for (int dz = -2; dz <= 2; dz++)
                    {
                        for (int dx = -2; dx <= 2; dx++)
                        {
                            total++;
                            int cx = x + dx, cz = z + dz;
                            if (cx < 0 || cz < 0 || cx >= nx || cz >= nz) continue;
                            if (free[Index(cx, cz)]) libres++;
                        }
                    }
                    holgura[id] = total > 0 ? (float)libres / total : 0f;
                }
            }

            built = true;
        }

        static int Index(int x, int z)
        {
            return z * nx + x;
        }

        static void Coords(int id, out int x, out int z)
        {
            z = id / nx;
            x = id % nx;
        }

        static bool IgnoreCollider(Collider col)
        {
            if (col == null || col.isTrigger)
                return true;

            if (col.GetComponentInParent<StackerAgent>() != null)
                return true;

            if (col.GetComponentInParent<DynamicPedestrian>() != null)
                return true;

            // Pisos y zonas muy bajas no deben bloquear la navegacion horizontal.
            if (col.bounds.max.y < 0.18f)
                return true;

            string n = col.gameObject.name.ToLowerInvariant();
            if (n.Contains("piso") || n.Contains("floor") || n.Contains("suelo"))
                return true;

            return false;
        }

        static bool HasStaticObstacle(Vector3 p, float radius)
        {
            Vector3 center = new Vector3(p.x, ProbeY, p.z);
            Collider[] hits = Physics.OverlapSphere(center, radius, ~0, QueryTriggerInteraction.Ignore);

            for (int i = 0; i < hits.Length; i++)
            {
                if (!IgnoreCollider(hits[i]))
                    return true;
            }

            return false;
        }

        public static bool IsPositionFree(Vector3 p, float radius)
        {
            return !HasStaticObstacle(p, radius);
        }

        static int NearestFreeNode(Vector3 p)
        {
            BuildGraph();

            int best = -1;
            float bestD = float.MaxValue;

            for (int i = 0; i < nodes.Length; i++)
            {
                if (!free[i])
                    continue;

                float d = (new Vector2(p.x, p.z) - new Vector2(nodes[i].x, nodes[i].z)).sqrMagnitude;
                if (d < bestD)
                {
                    bestD = d;
                    best = i;
                }
            }

            return best;
        }

        // Ajusta un punto a la celda transitable mas cercana. Se usa para que
        // pickup/dropoff nunca queden dentro de un rack, banda o pared.
        public static Vector3 SnapToFreePoint(Vector3 p)
        {
            BuildGraph();
            int id = NearestFreeNode(p);
            if (id < 0)
                return new Vector3(p.x, 0.05f, p.z);

            return nodes[id];
        }

        public static bool HasRoute(Vector3 start, Vector3 target)
        {
            List<Vector3> r = Plan(start, target, null);
            return r != null && r.Count > 0;
        }

        /// <summary>Coste extra por circular pegado a un obstaculo.</summary>
        static float PenalizacionPorEstrechez(int id)
        {
            if (holgura == null || id < 0 || id >= holgura.Length)
                return 0f;

            return PesoEstrechez * (1f - holgura[id]);
        }

        static float H(Vector3 a, Vector3 b)
        {
            return Mathf.Abs(a.x - b.x) + Mathf.Abs(a.z - b.z);
        }

        static IEnumerable<int> Neighbors(int id)
        {
            int x, z;
            Coords(id, out x, out z);

            if (x > 0) yield return Index(x - 1, z);
            if (x < nx - 1) yield return Index(x + 1, z);
            if (z > 0) yield return Index(x, z - 1);
            if (z < nz - 1) yield return Index(x, z + 1);
        }

        static float AgentPenalty(Vector3 p, StackerAgent self, StackerAgent[] agents)
        {
            if (self == null || agents == null)
                return 0f;

            float penalty = 0f;

            for (int i = 0; i < agents.Length; i++)
            {
                StackerAgent other = agents[i];
                if (other == null || other == self)
                    continue;

                float d = Vector3.Distance(new Vector3(p.x, 0f, p.z),
                                           new Vector3(other.transform.position.x, 0f, other.transform.position.z));

                if (d < 0.9f)
                    penalty += 30f;
                else if (d < 1.6f)
                    penalty += 8f;
                else if (d < 2.4f)
                    penalty += 2f;
            }

            return penalty;
        }

        static bool SegmentClear(Vector3 a, Vector3 b, StackerAgent self)
        {
            Vector3 start = new Vector3(a.x, ProbeY, a.z);
            Vector3 end = new Vector3(b.x, ProbeY, b.z);
            Vector3 delta = end - start;
            float dist = delta.magnitude;

            if (dist < 0.01f)
                return true;

            RaycastHit[] hits = Physics.SphereCastAll(start, NavRadius, delta.normalized, dist, ~0, QueryTriggerInteraction.Ignore);

            for (int i = 0; i < hits.Length; i++)
            {
                Collider col = hits[i].collider;
                if (col == null)
                    continue;

                StackerAgent hitAgent = col.GetComponentInParent<StackerAgent>();
                if (hitAgent != null)
                    continue;

                if (col.GetComponentInParent<DynamicPedestrian>() != null)
                    continue;

                if (!IgnoreCollider(col))
                    return false;
            }

            return true;
        }

        public static List<Vector3> Plan(Vector3 start, Vector3 target, StackerAgent self = null)
        {
            BuildGraph();

            int startId = NearestFreeNode(start);
            int goalId = NearestFreeNode(target);

            if (startId < 0 || goalId < 0)
                return new List<Vector3>();

            // ANTES: Object.FindObjectsByType<StackerAgent>(FindObjectsSortMode.None)
            // en CADA planificacion de ruta. Dos problemas: una busqueda por toda la
            // escena por cada Plan(), y la sobrecarga con FindObjectsSortMode quedo
            // deprecada en Unity 6.5 (warning CS0618).
            // Ahora la flota la registra el gestor una sola vez.
            StackerAgent[] agents = null;
            if (self != null)
                agents = Flota;

            var open = new List<int>();
            open.Add(startId);

            int[] came = new int[nodes.Length];
            float[] g = new float[nodes.Length];
            float[] f = new float[nodes.Length];
            bool[] hasG = new bool[nodes.Length];
            bool[] closed = new bool[nodes.Length];

            for (int i = 0; i < came.Length; i++)
                came[i] = -1;

            g[startId] = 0f;
            f[startId] = H(nodes[startId], nodes[goalId]);
            hasG[startId] = true;

            while (open.Count > 0)
            {
                int current = open[0];
                float bestF = f[current];

                for (int i = 1; i < open.Count; i++)
                {
                    int candidate = open[i];
                    if (f[candidate] < bestF)
                    {
                        current = candidate;
                        bestF = f[candidate];
                    }
                }

                if (current == goalId)
                {
                    List<int> ids = new List<int>();
                    int c = current;
                    ids.Add(c);

                    while (came[c] >= 0)
                    {
                        c = came[c];
                        ids.Add(c);
                    }

                    ids.Reverse();

                    List<Vector3> raw = new List<Vector3>();
                    for (int i = 0; i < ids.Count; i++)
                        raw.Add(nodes[ids[i]]);

                    List<Vector3> route = Compress(raw);

                    // Solo llega al punto exacto si el ultimo tramo tambien esta libre.
                    if (route.Count > 0 && SegmentClear(route[route.Count - 1], target, self))
                        route.Add(new Vector3(target.x, 0.05f, target.z));

                    return route;
                }

                open.Remove(current);
                closed[current] = true;

                foreach (int nb in Neighbors(current))
                {
                    if (!free[nb] || closed[nb])
                        continue;

                    float step = Vector3.Distance(nodes[current], nodes[nb]);
                    float tentative = g[current] + step
                                      + AgentPenalty(nodes[nb], self, agents)
                                      + PenalizacionPorEstrechez(nb);

                    if (!hasG[nb] || tentative < g[nb])
                    {
                        came[nb] = current;
                        g[nb] = tentative;
                        f[nb] = tentative + H(nodes[nb], nodes[goalId]);
                        hasG[nb] = true;

                        if (!open.Contains(nb))
                            open.Add(nb);
                    }
                }
            }

            return new List<Vector3>();
        }

        static List<Vector3> Compress(List<Vector3> raw)
        {
            if (raw == null || raw.Count <= 2)
                return raw ?? new List<Vector3>();

            List<Vector3> result = new List<Vector3>();
            result.Add(raw[0]);

            Vector3 previousDir = (raw[1] - raw[0]).normalized;

            for (int i = 1; i < raw.Count - 1; i++)
            {
                Vector3 nextDir = (raw[i + 1] - raw[i]).normalized;
                if (Vector3.Dot(previousDir, nextDir) < 0.999f)
                {
                    result.Add(raw[i]);
                    previousDir = nextDir;
                }
            }

            result.Add(raw[raw.Count - 1]);
            return result;
        }

        public static float RouteCost(Vector3 start, Vector3 target)
        {
            long key = CostKey(start, target);
            float cached;
            if (costCache.TryGetValue(key, out cached))
                return cached;

            float value = RouteCostUncached(start, target);
            costCache[key] = value;
            return value;
        }

        static float RouteCostUncached(Vector3 start, Vector3 target)
        {
            List<Vector3> route = Plan(start, target, null);
            if (route == null || route.Count == 0)
                return 999f;

            Vector3 previous = start;
            float total = 0f;

            for (int i = 0; i < route.Count; i++)
            {
                total += Vector3.Distance(previous, route[i]);
                previous = route[i];
            }

            return total;
        }
    }
}
