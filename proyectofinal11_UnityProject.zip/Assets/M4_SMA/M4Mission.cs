using System;
using UnityEngine;

namespace RoboArenaM4
{
    public enum MissionStatus { Pending, Assigned, InProgress, Completed }

    [Serializable]
    public class M4Mission
    {
        public int id;
        // Punto al que llega el AGV para recoger.
        public Vector3 pickup;
        // Punto seguro al que llega el AGV para descargar.
        public Vector3 dropoff;
        // Lugar fisico donde finalmente queda la tarima.
        public Vector3 palletDropoff;
        public int priority;
        public string pickupName;
        public string dropoffName;
        public GameObject sourcePallet;
        public MissionStatus status = MissionStatus.Pending;
        public float createdAt;
        public float startedAt;
        public float completedAt;

        public M4Mission(
            int id,
            Vector3 pickup,
            Vector3 dropoff,
            int priority,
            string dropoffName = "",
            GameObject sourcePallet = null,
            string pickupName = "")
        {
            this.id = id;
            this.pickup = pickup;
            this.dropoff = dropoff;
            this.palletDropoff = dropoff;
            this.priority = priority;
            this.dropoffName = dropoffName;
            this.sourcePallet = sourcePallet;
            this.pickupName = pickupName;
            createdAt = Time.time;
        }
    }
}
