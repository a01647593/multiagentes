using UnityEngine;

namespace RoboArenaM4
{
    /// <summary>
    /// Obstaculo movil: una persona que recorre un pasillo completo de extremo a
    /// extremo. Los recorridos los asigna StackerFleetManager.ConfigurarPeatones().
    ///
    /// ANTES este script movia al peaton con un MoveTowards incondicional: no miraba
    /// nada, asi que atravesaba a los AGV limpiamente. Ahora se detiene cuando tiene
    /// un apilador delante, que es lo que hace una persona en un almacen y lo que
    /// obliga al AGV a negociar el paso en vez de cruzarse por dentro.
    /// </summary>
    public class DynamicPedestrian : MonoBehaviour
    {
        public Vector3 pointA = new Vector3(-8f, 1f, 2.5f);
        public Vector3 pointB = new Vector3(8f, 1f, 2.5f);
        public float speed = 1.2f;

        [Tooltip("A que distancia por delante se detiene si hay un apilador.")]
        public float distanciaDeParo = 1.35f;

        [Tooltip("Radio del cuerpo del peaton para la comprobacion de paso.")]
        public float radioCuerpo = 0.45f;

        bool toB = true;

        /// <summary>True mientras esta detenido porque tiene un AGV delante.
        /// Sirve para que se vea que el evento dinamico interactua de verdad.</summary>
        public bool Detenido { get; private set; }

        void Update()
        {
            Vector3 target = toB ? pointB : pointA;

            Vector3 delta = target - transform.position;
            delta.y = 0f;

            if (delta.sqrMagnitude < 0.0001f)
            {
                toB = !toB;
                Detenido = false;
                return;
            }

            Vector3 direccion = delta.normalized;

            if (HayApiladorDelante(direccion))
            {
                Detenido = true;   // cede el paso: no lo atraviesa
                return;
            }

            Detenido = false;
            transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);

            if (Vector3.Distance(transform.position, target) < 0.05f)
                toB = !toB;
        }

        bool HayApiladorDelante(Vector3 direccion)
        {
            Vector3 origen = new Vector3(transform.position.x, 0.75f, transform.position.z);

            RaycastHit[] hits = Physics.SphereCastAll(
                origen, radioCuerpo, direccion, distanciaDeParo, ~0, QueryTriggerInteraction.Ignore);

            for (int i = 0; i < hits.Length; i++)
            {
                Collider col = hits[i].collider;
                if (col == null || col.isTrigger)
                    continue;

                Transform t = col.transform;
                if (t == transform || t.IsChildOf(transform))
                    continue;

                if (col.GetComponentInParent<StackerAgent>() != null)
                    return true;
            }

            return false;
        }

        public void ResetPedestrian()
        {
            toB = true;
            Detenido = false;
            transform.position = pointA;
        }
    }
}
