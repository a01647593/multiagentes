#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace RoboArenaM4.EditorTools
{
    public static class M4SceneSetup
    {
        const string RootName = "M4_SMA_COMPLETO";

        // ---------------------------------------------------------------------
        //  La estacion de carga se construye sola al darle Play. Esta opcion la
        //  deja tambien FIJA en la escena, para verla y capturarla sin ejecutar.
        //  Al entrar en Play, StackerFleetManager la ADOPTA en vez de duplicarla.
        // ---------------------------------------------------------------------
        [MenuItem("M4 RoboArena/Construir estacion de carga (2 puestos)")]
        public static void ConstruirEstacionDeCarga()
        {
            StackerFleetManager gestor = null;
            GameObject[] todos = Resources.FindObjectsOfTypeAll<GameObject>();

            for (int i = 0; i < todos.Length; i++)
            {
                if (todos[i] == null || !todos[i].scene.IsValid()) continue;

                StackerFleetManager m = todos[i].GetComponent<StackerFleetManager>();
                if (m != null) { gestor = m; break; }
            }

            if (gestor == null)
            {
                EditorUtility.DisplayDialog("M4 RoboArena",
                    "No encontre el MissionManager en la escena abierta.\n\n" +
                    "Abre la escena de la entrega y vuelve a intentarlo.", "OK");
                return;
            }

            GameObject vieja = GameObject.Find("ESTACION_DE_CARGA_M4");
            if (vieja != null) Object.DestroyImmediate(vieja);

            WarehouseAStar.RebuildNavigation();
            gestor.ConfigurarEstacionDeCarga();

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());

            GameObject nueva = GameObject.Find("ESTACION_DE_CARGA_M4");
            if (nueva != null) Selection.activeGameObject = nueva;

            EditorUtility.DisplayDialog("M4 RoboArena",
                "Estacion de carga construida con " + M4Params.PUESTOS_DE_CARGA +
                " puestos.\n\nEsta en la Hierarchy como ESTACION_DE_CARGA_M4.\n" +
                "Guarda la escena con Cmd/Ctrl+S.", "OK");
        }

        [MenuItem("M4 RoboArena/Preparar M4 COMPLETO - 6 Stackers")]
        public static void Prepare()
        {
            PrepareInternal();
        }

        [MenuItem("M4 RoboArena/REPARAR movimiento y colisiones V2")]
        public static void RepairMovement()
        {
            PrepareInternal();
        }

        static void PrepareInternal()
        {
            if (Application.isPlaying)
            {
                EditorUtility.DisplayDialog("M4 RoboArena", "Sal de Play Mode antes de preparar la escena.", "OK");
                return;
            }

            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/V4_Apilador_de_Stacks.prefab");
            if (prefab == null)
                prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/Vehiculos/V4_Apilador_Stacker.prefab");

            if (prefab == null)
            {
                EditorUtility.DisplayDialog(
                    "M4 RoboArena",
                    "No encontre el prefab del stacker. Importa primero el paquete del proyecto M2/M3.",
                    "OK");
                return;
            }

            GameObject old = GameObject.Find(RootName);
            if (old != null)
                Object.DestroyImmediate(old);

            GameObject oldV2 = GameObject.Find("M4_SMA_6_STACKERS");
            if (oldV2 != null)
                Object.DestroyImmediate(oldV2);

            GameObject root = new GameObject(RootName);
            Undo.RegisterCreatedObjectUndo(root, "Preparar M4 completo");

            HideVehicleShowcase(root);

            Vector3[] spawn =
            {
                new Vector3(-8f, 0.05f, 2.5f),
                new Vector3(-5f, 0.05f, 2.5f),
                new Vector3(-2f, 0.05f, 2.5f),
                new Vector3( 1f, 0.05f, 2.5f),
                new Vector3( 4.7f, 0.05f, 2.5f),
                new Vector3( 7.2f, 0.05f, 2.5f)
            };

            StackerAgent[] agents = new StackerAgent[6];

            for (int i = 0; i < agents.Length; i++)
            {
                GameObject go = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
                go.name = "Stacker_AGV_" + (i + 1);
                go.transform.SetParent(root.transform);
                go.transform.position = spawn[i];

                // El modelo fue construido mirando hacia +X, por eso identidad ya lo deja
                // visualmente alineado con el corredor horizontal inicial.
                go.transform.rotation = Quaternion.identity;

                Rigidbody rb = go.GetComponent<Rigidbody>();
                if (rb == null)
                    rb = go.AddComponent<Rigidbody>();

                rb.isKinematic = true;
                rb.useGravity = false;
                rb.interpolation = RigidbodyInterpolation.Interpolate;
                rb.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;

                // Si por alguna razon el prefab no trae colliders, agrega uno de seguridad.
                if (go.GetComponentInChildren<Collider>() == null)
                {
                    BoxCollider bc = go.AddComponent<BoxCollider>();
                    bc.center = new Vector3(-0.15f, 0.85f, 0.27f);
                    bc.size = new Vector3(1.9f, 1.7f, 1.25f);
                }

                StackerAgent agent = go.GetComponent<StackerAgent>();
                if (agent == null)
                    agent = go.AddComponent<StackerAgent>();

                agent.agentId = i + 1;
                agent.battery = 100f - i * 6f;
                agent.speed = 1.75f;
                agent.acceleration = 3.5f;
                agent.braking = 5f;
                agent.turnDegreesPerSecond = 120f;
                agent.turnInPlaceAngle = 32f;
                agent.stopDistance = 0.24f;
                agent.detectionDistance = 1.45f;
                agent.bodyRadius = 0.46f;
                agent.modelYawOffset = -90f;
                agents[i] = agent;
            }

            GameObject managerGO = new GameObject("MissionManager_Distribuido");
            managerGO.transform.SetParent(root.transform);

            StackerFleetManager manager = managerGO.AddComponent<StackerFleetManager>();
            manager.agents = agents;
            manager.experimentMode = StackerFleetManager.ExperimentMode.AutomaticComparison;
            manager.experimentDuration = 60f;
            manager.publishInterval = 1f;
            manager.autoSaveCsv = true;

            for (int i = 0; i < agents.Length; i++)
                agents[i].manager = manager;

            CreateDynamicPedestrian(root.transform);
            CreateChargeMarker(root.transform);
            CreateOverviewCamera(root.transform);

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            Selection.activeGameObject = root;

            EditorUtility.DisplayDialog(
                "M4 RoboArena V2",
                "Listo. Movimiento suavizado, orientacion corregida, A* basado en colliders reales y deteccion de racks/bandas/columnas/AGV. Guarda la escena y presiona Play.",
                "OK");
        }

        static void HideVehicleShowcase(GameObject root)
        {
            GameObject[] all = Resources.FindObjectsOfTypeAll<GameObject>();
            for (int i = 0; i < all.Length; i++)
            {
                if (!all[i].scene.IsValid())
                    continue;

                if (all[i] == root)
                    continue;

                if (all[i].name == "VEHICULOS")
                    all[i].SetActive(false);
            }
        }

        static void CreateDynamicPedestrian(Transform parent)
        {
            GameObject ped = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            ped.name = "Peaton_Obstaculo_Dinamico";
            ped.transform.SetParent(parent);
            ped.transform.localScale = new Vector3(0.55f, 0.9f, 0.55f);

            DynamicPedestrian dynamicPed = ped.AddComponent<DynamicPedestrian>();
            dynamicPed.pointA = new Vector3(1f, 1f, 1.35f);
            dynamicPed.pointB = new Vector3(1f, 1f, 3.65f);
            dynamicPed.speed = 1.0f;
            dynamicPed.ResetPedestrian();

            Renderer renderer = ped.GetComponent<Renderer>();
            AssignProjectMaterial(renderer, "Assets/Materials/M_Verde.mat");
        }

        static void CreateChargeMarker(Transform parent)
        {
            GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            marker.name = "Marcador_Estacion_Carga_M4";
            marker.transform.SetParent(parent);
            marker.transform.position = new Vector3(9.8f, 0.03f, 9.4f);
            marker.transform.localScale = new Vector3(0.65f, 0.03f, 0.65f);

            Collider collider = marker.GetComponent<Collider>();
            if (collider != null)
                Object.DestroyImmediate(collider);

            Renderer renderer = marker.GetComponent<Renderer>();
            AssignProjectMaterial(renderer, "Assets/Materials/M_PlasticoAzul.mat");
        }

        static void AssignProjectMaterial(Renderer renderer, string materialPath)
        {
            if (renderer == null)
                return;

            Material mat = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (mat != null)
                renderer.sharedMaterial = mat;
        }

        static void CreateOverviewCamera(Transform parent)
        {
            // Camera.allCameras es API estable y no queda deprecada en ninguna version.
            Camera[] cameras = Camera.allCameras;
            for (int i = 0; i < cameras.Length; i++)
                cameras[i].enabled = false;

            GameObject camGO = new GameObject("M4_Overview_Camera");
            camGO.transform.SetParent(parent);
            camGO.transform.position = new Vector3(0f, 24f, -25f);
            camGO.transform.rotation = Quaternion.LookRotation(Vector3.zero - camGO.transform.position, Vector3.up);

            Camera cam = camGO.AddComponent<Camera>();
            cam.fieldOfView = 56f;
            cam.farClipPlane = 200f;
            cam.enabled = true;
            camGO.tag = "MainCamera";
        }
    }
}
#endif
