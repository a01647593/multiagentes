// -----------------------------------------------------------------------------
//  M4Params.cs  -  Unica fuente de verdad de la capa de decision
// -----------------------------------------------------------------------------
//  Estos son EXACTAMENTE los parametros de la seccion M4.7 del notebook, para que
//  la simulacion 3D y la simulacion de Colab tomen las mismas decisiones.
//
//  Antes estaban repartidos y en su mayoria no existian: los pesos venian
//  hardcodeados dentro de CalculateBid sin normalizar, no habia filtro duro de
//  energia y la estacion de carga era un punto magico sin limite de plazas.
// -----------------------------------------------------------------------------
using UnityEngine;

namespace RoboArenaM4
{
    public static class M4Params
    {
        // --- Pesos de la utilidad multicriterio. Suman 100. ---------------------
        public const float W_D = 40f;   // distancia al pickup
        public const float W_S = 15f;   // holgura de bateria
        public const float W_L = 15f;   // carga de trabajo acumulada
        public const float W_C = 20f;   // congestion alrededor del pickup
        public const float W_P = 10f;   // prioridad de la mision

        // --- Filtro duro de factibilidad energetica ----------------------------
        //  Un AGV solo puja si:   bateria - MARGEN * energia_estimada >= RESERVA
        //  Es una regla dura, no un castigo suave: quien no la cumple se autoexcluye
        //  en vez de aceptar una mision que no puede terminar.
        public const float MARGEN_SEGURIDAD = 1.20f;
        public const float RESERVA = 12f;

        // --- La estacion de carga es un recurso en disputa ----------------------
        public const int PUESTOS_DE_CARGA = 2;      // 2 plazas para 6 apiladores
        public static readonly Vector3 ESTACION_CARGA = new Vector3(9.8f, 0.05f, 9.4f);
        public static readonly Vector3 APROXIMACION_CARGA = new Vector3(8.55f, 0.05f, 8.15f);

        // Prioridad maxima de una mision (BuildMissions usa 1..3).
        public const float PRIORIDAD_MAXIMA = 3f;
    }
}
