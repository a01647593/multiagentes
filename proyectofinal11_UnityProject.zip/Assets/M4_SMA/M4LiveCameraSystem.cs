using UnityEngine;

namespace RoboArenaM4
{
    // Sistema de camaras creado en runtime para no requerir cambios manuales en la escena.
    // Mantiene la camara principal y agrega una camara LIVE de seguimiento + un minimapa cenital.
    [RequireComponent(typeof(StackerFleetManager))]
    public class M4LiveCameraSystem : MonoBehaviour
    {
        public float switchEvery = 7f;
        public float followHeight = 4.8f;
        public float followDistance = 4.3f;
        public float smooth = 4.5f;
        public bool showMiniMap = true;

        StackerFleetManager manager;
        Camera followCamera;
        Camera mapCamera;
        int currentIndex;
        float nextSwitch;
        StackerAgent currentTarget;

        void Awake()
        {
            manager = GetComponent<StackerFleetManager>();
        }

        void Start()
        {
            CreateFollowCamera();
            if (showMiniMap)
                CreateMapCamera();

            nextSwitch = Time.time + 1f;
        }

        void CreateFollowCamera()
        {
            GameObject go = new GameObject("M4_Camera_AGV_LIVE");
            go.transform.SetParent(transform, false);
            followCamera = go.AddComponent<Camera>();
            followCamera.depth = 20f;
            followCamera.rect = new Rect(0.665f, 0.53f, 0.325f, 0.45f);
            followCamera.fieldOfView = 55f;
            followCamera.clearFlags = CameraClearFlags.SolidColor;
            followCamera.backgroundColor = new Color(0.05f, 0.06f, 0.07f, 1f);
            followCamera.nearClipPlane = 0.08f;
            followCamera.farClipPlane = 150f;
        }

        void CreateMapCamera()
        {
            GameObject go = new GameObject("M4_Camera_Mapa_LIVE");
            go.transform.SetParent(transform, false);
            mapCamera = go.AddComponent<Camera>();
            mapCamera.depth = 19f;
            mapCamera.rect = new Rect(0.74f, 0.035f, 0.25f, 0.36f);
            mapCamera.orthographic = true;
            mapCamera.orthographicSize = 12.5f;
            mapCamera.clearFlags = CameraClearFlags.SolidColor;
            mapCamera.backgroundColor = new Color(0.04f, 0.05f, 0.06f, 1f);
            mapCamera.transform.position = new Vector3(0f, 25f, 0f);
            mapCamera.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            mapCamera.nearClipPlane = 0.1f;
            mapCamera.farClipPlane = 80f;
        }

        void LateUpdate()
        {
            if (manager == null || manager.agents == null || manager.agents.Length == 0)
                return;

            StackerAgent special = FindLoadingOrUnloadingAgent();
            if (special != null)
            {
                currentTarget = special;
                nextSwitch = Time.time + 2.5f;
            }
            else if (currentTarget == null || Time.time >= nextSwitch)
            {
                SelectNextWorkingAgent();
                nextSwitch = Time.time + switchEvery;
            }

            if (currentTarget == null || followCamera == null)
                return;

            Vector3 target = currentTarget.transform.position + Vector3.up * 0.9f;

            // Vista 3/4 estable. No depende de la orientacion geometrica del modelo.
            Vector3 diagonal = new Vector3(-1f, 0f, -1f).normalized;
            Vector3 desiredPosition = target - diagonal * followDistance + Vector3.up * followHeight;
            float k = 1f - Mathf.Exp(-smooth * Time.deltaTime);
            followCamera.transform.position = Vector3.Lerp(followCamera.transform.position, desiredPosition, k);

            Quaternion desiredRotation = Quaternion.LookRotation(target - followCamera.transform.position, Vector3.up);
            followCamera.transform.rotation = Quaternion.Slerp(followCamera.transform.rotation, desiredRotation, k);
        }

        StackerAgent FindLoadingOrUnloadingAgent()
        {
            for (int i = 0; i < manager.agents.Length; i++)
            {
                StackerAgent a = manager.agents[i];
                if (a == null) continue;
                if (a.state == StackerState.Unloading)
                    return a;
            }

            for (int i = 0; i < manager.agents.Length; i++)
            {
                StackerAgent a = manager.agents[i];
                if (a == null) continue;
                if (a.state == StackerState.Loading)
                    return a;
            }

            return null;
        }

        void SelectNextWorkingAgent()
        {
            int count = manager.agents.Length;
            for (int step = 0; step < count; step++)
            {
                currentIndex = (currentIndex + 1) % count;
                StackerAgent candidate = manager.agents[currentIndex];
                if (candidate == null) continue;

                if (candidate.state != StackerState.Idle && candidate.state != StackerState.Charging)
                {
                    currentTarget = candidate;
                    return;
                }
            }

            // Si todos estan momentaneamente libres, muestra cualquiera que exista.
            for (int i = 0; i < count; i++)
            {
                if (manager.agents[i] != null)
                {
                    currentTarget = manager.agents[i];
                    currentIndex = i;
                    return;
                }
            }
        }

        void OnGUI()
        {
            if (followCamera != null)
            {
                string label = currentTarget != null
                    ? "CAMARA LIVE - AGV " + currentTarget.agentId + " | " + currentTarget.state
                    : "CAMARA LIVE - AGV";

                float x = Screen.width * 0.665f + 8f;
                float y = Screen.height * 0.025f;
                GUI.Box(new Rect(x, y, Screen.width * 0.31f, 25f), label);
            }

            if (mapCamera != null)
            {
                float x = Screen.width * 0.74f + 8f;
                float y = Screen.height * 0.605f;
                GUI.Box(new Rect(x, y, Screen.width * 0.23f, 24f), "MAPA EN VIVO - FLOTA AGV");
            }
        }
    }
}
