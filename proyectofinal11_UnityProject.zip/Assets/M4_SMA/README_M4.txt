M4 RoboArena - PARCHE V2 MOVIMIENTO + COLISIONES

CORRECCIONES PRINCIPALES
- Los AGV ya NO ignoran racks, bandas, columnas, pallets ni obstaculos con collider.
- A* construye su cuadricula usando los colliders reales del almacen.
- Si un AGV encuentra un obstaculo persistente intenta replanear.
- Los AGV detectan al peaton y a otros AGV antes de tocarse.
- Movimiento con aceleracion, frenado y giro suave.
- En esquinas cerradas el stacker gira antes de avanzar para evitar derrape lateral.
- Se corrigio la orientacion del prefab: el frente geometrico del stacker esta hacia +X.
- El pallet visual ahora se coloca enfrente de las horquillas, no al costado.
- Las misiones de salida usan puntos seguros de aproximacion a los docks y ya no meten el AGV dentro de las bandas.
- La carga usa un punto seguro cercano a la estacion real (9.8, 0, 9.4).

COMO USAR
1. Importa M4_RoboArena_FIX_Movimiento_Colisiones_V2.unitypackage sobre tu proyecto actual.
2. Abre Assets/proyecto.unity.
3. Sal de Play Mode.
4. Menu superior: M4 RoboArena > REPARAR movimiento y colisiones V2.
5. Guarda con Ctrl+S.
6. Play.

IMPORTANTE
El boton de reparar recrea la raiz M4_SMA_COMPLETO para aplicar los nuevos valores de velocidad, giro y deteccion.
No borra tu almacen M2.
