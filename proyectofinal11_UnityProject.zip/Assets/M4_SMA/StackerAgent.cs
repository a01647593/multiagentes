using System.Collections.Generic;
using UnityEngine;

namespace RoboArenaM4
{
    public enum StackerState
    {
        Idle,
        ToPickup,
        Loading,
        ToDropoff,
        Unloading,
        Waiting,
        ToCharge,
        Charging
    }

    public class StackerAgent : MonoBehaviour
    {
        [Header("Identidad")]
        public int agentId = 1;
        public StackerState state = StackerState.Idle;

        [Header("Movimiento suave")]
        public float speed = 1.75f;
        public float acceleration = 3.5f;
        public float braking = 5.0f;
        public float turnDegreesPerSecond = 145f;
        [Tooltip("Por encima de este angulo el AGV deja de acelerar y corrige el rumbo.")]
        public float turnInPlaceAngle = 32f;
        [Tooltip("Angulo a partir del cual si se detiene del todo para girar (media vuelta).")]
        public float anguloGiroParado = 105f;
        [Tooltip("Fraccion de velocidad que conserva mientras corrige el rumbo. 0 = se para en cada esquina.")]
        [Range(0f, 0.6f)] public float velocidadEnGiro = 0.22f;
        [Tooltip("Distancia del punto adelantado que persigue. Suaviza el trazado.")]
        public float distanciaAnticipacion = 1.30f;
        public float stopDistance = 0.24f;
        public float detectionDistance = 1.45f;
        public float bodyRadius = 0.46f;
        public float emergencyStopDistance = 0.58f;
        public float yieldDistance = 1.25f;
        public float yieldSpeed = 0.95f;

        [Header("Animacion de pallet")]
        public float loadingDuration = 3.20f;
        public float unloadingDuration = 3.20f;
        public Vector3 carriedPalletLocalPosition = new Vector3(0.0f, -0.01f, 0.88f);
        public Vector3 unloadPalletLocalPosition = new Vector3(0.0f, -0.05f, 1.48f);
        [Tooltip("Cuanto suben las horquillas para levantar la tarima del larguero.")]
        public float alturaEnganche = 0.07f;
        [Tooltip("Altura a la que viajan las horquillas con carga, sobre su reposo.")]
        public float alturaTransporte = 0.32f;
        [Tooltip("Elevacion maxima de las horquillas.")]
        public float alturaMaximaHorquillas = 2.20f;

        [Header("Anti atasco")]
        public float nearDestinationArrivalDistance = 0.62f;
        public float recoveryAfterSeconds = 2.25f;
        public float emergencyRecoveryAfterSeconds = 4.25f;

        [Tooltip("El modelo del stacker esta construido mirando hacia +X. -90 alinea esa direccion con el forward de la ruta.")]
        public float modelYawOffset = -90f;

        [Header("Energia")]
        [Range(0, 100)] public float battery = 100f;
        public float batteryPerMeter = 0.22f;
        public float lowBatteryThreshold = 18f;
        public float chargeRate = 24f;

        [HideInInspector] public StackerFleetManager manager;
        [System.NonSerialized] public M4Mission mission;

        readonly List<Vector3> route = new List<Vector3>();
        int routeIndex;
        float phaseTimer;
        float distanceTravelled;
        float activeTime;
        float waitingTime;
        float currentSpeed;
        float blockedTimer;
        float replanCooldown;
        Vector3 currentDestination;
        TextMesh label;
        StackerState stateBeforeWaiting;
        GameObject payloadVisual;
        bool payloadIsScenePallet;
        Vector3 payloadLoadStartLocalPosition;
        Quaternion payloadLoadStartLocalRotation;
        bool runtimeEnabled = true;
        bool performingYield;
        Vector3 yieldTarget;
        Transform forkCarriage;
        Vector3 forkCarriageBaseLocalPosition;
        bool forkCarriageReady;
        bool loadingPayloadAttached;
        float noProgressTimer;
        Vector3 lastProgressPosition;
        float progressSampleTimer;
        float routeRetryTimer;
        int failedRoutePlans;
        int chargeBay = -1;
        int vecFrame = -1;
        int vecMisionId = -1;
        VectorEstado vecCache;

        Bounds cuerpoLocal;      // volumen real del vehiculo, en sus ejes locales
        bool cuerpoListo;

        float alturaApoyoRaiz;          // altura de la cara util de las horquillas, en la raiz
        Vector3 cargaLocal;             // pivote de la carga apoyada en las horquillas
        Vector3 descargaLocal;          // pivote extendido, para depositar
        Quaternion cargaRotacionLocal;  // tarima alineada con las horquillas
        bool posicionesCargaListas;

        enum BlockType { None, Pedestrian, Agent, Static }

        public bool IsAvailable
        {
            get { return runtimeEnabled && state == StackerState.Idle && mission == null && battery > lowBatteryThreshold; }
        }

        public float DistanceTravelled { get { return distanceTravelled; } }
        public float ActiveTime { get { return activeTime; } }
        public float WaitingTime { get { return waitingTime; } }

        void Awake()
        {
            CachearVolumenDelCuerpo();
            ResetRuntimeState();
        }

        // =====================================================================
        //  CONTENCION FISICA
        //
        //  PROBLEMA QUE RESUELVE. Los AGV son cinematicos y se mueven escribiendo
        //  transform.position: la fisica de Unity nunca los detiene. La unica
        //  proteccion era un SphereCast hacia adelante de radio 0.46 m... y ademas
        //  BelongsToRackOrPallet() descartaba TODO lo que colgara de un objeto
        //  llamado "Rack_*", puntales incluidos. O sea: la estructura de los
        //  anaqueles estaba explicitamente excluida del sensor. Por eso los
        //  atravesaban.
        //
        //  Ademas el apilador mide ~2.45 m de largo y el sensor era una esfera de
        //  0.46 m alrededor del pivote: al girar en el sitio, la nariz y las
        //  horquillas barren muy por fuera de esa esfera y se metian en el rack.
        //
        //  SOLUCION. Se mide el volumen real del vehiculo a partir de sus propios
        //  renderers y, antes de aplicar CUALQUIER cambio de posicion o rotacion,
        //  se comprueba que esa caja orientada no invada estructura solida. Si la
        //  invade, el movimiento simplemente no se aplica. Es una garantia dura:
        //  ninguna pose del AGV puede quedar dentro de un muro, una columna o un
        //  puntal, pase lo que pase con el planeador o con las maniobras.
        // =====================================================================
        void CachearVolumenDelCuerpo()
        {
            Renderer[] rs = GetComponentsInChildren<Renderer>();

            if (rs == null || rs.Length == 0)
            {
                // Medidas nominales del apilador si el modelo aun no esta listo.
                cuerpoLocal = new Bounds(new Vector3(0f, 1.10f, 0f), new Vector3(2.45f, 2.20f, 0.95f));
                cuerpoListo = true;
                return;
            }

            // Matriz que quita rotacion y traslacion pero conserva la escala del
            // mundo: asi los extents quedan en metros reales sobre los ejes locales.
            Matrix4x4 aLocal = Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one).inverse;

            bool primero = true;
            Bounds acumulado = new Bounds();

            for (int i = 0; i < rs.Length; i++)
            {
                if (rs[i] == null) continue;

                Bounds wb = rs[i].bounds;
                Vector3 c = wb.center;
                Vector3 e = wb.extents;

                for (int k = 0; k < 8; k++)
                {
                    Vector3 esquina = c + new Vector3(
                        (k & 1) == 0 ? -e.x : e.x,
                        (k & 2) == 0 ? -e.y : e.y,
                        (k & 4) == 0 ? -e.z : e.z);

                    Vector3 lp = aLocal.MultiplyPoint3x4(esquina);

                    if (primero) { acumulado = new Bounds(lp, Vector3.zero); primero = false; }
                    else acumulado.Encapsulate(lp);
                }
            }

            cuerpoLocal = acumulado;
            cuerpoListo = true;
        }

        /// <summary>Tarimas, cajas y estibas: carga blanda. Las horquillas SI entran
        /// ahi, es su trabajo. No confundir con la estructura del anaquel.</summary>
        static bool EsCargaBlanda(Collider col)
        {
            if (col == null) return false;

            Transform t = col.transform;
            while (t != null)
            {
                string n = t.name.ToLowerInvariant();
                if (n.StartsWith("tarima") || n.StartsWith("estiba") || n.StartsWith("caja") ||
                    n.Contains("pallet") || n.StartsWith("duela") || n.StartsWith("patin") ||
                    n.StartsWith("taco"))
                    return true;
                t = t.parent;
            }
            return false;
        }

        /// <summary>Estructura solida contra la que el vehiculo no puede pasar:
        /// muros, puntales y vigas de rack, bandas, andenes, columnas, obstaculos.</summary>
        bool EsEstructuraSolida(Collider col)
        {
            if (col == null || col.isTrigger)
                return false;

            Transform t = col.transform;
            if (t == transform || t.IsChildOf(transform))
                return false;

            if (col.bounds.max.y < 0.18f)
                return false;   // piso y calcomanias

            string n = col.gameObject.name.ToLowerInvariant();
            if (n.Contains("piso") || n.Contains("floor") || n.Contains("suelo") ||
                n.Contains("carril") || n.Contains("marcador") || n.Contains("andador"))
                return false;

            // Los otros AGV y los peatones tienen su propia logica de negociacion.
            if (col.GetComponentInParent<StackerAgent>() != null) return false;
            if (col.GetComponentInParent<DynamicPedestrian>() != null) return false;

            // La carga que este AGV lleva encima no lo bloquea.
            if (payloadVisual != null)
            {
                Transform pv = payloadVisual.transform;
                if (t == pv || t.IsChildOf(pv)) return false;
            }

            if (EsCargaBlanda(col)) return false;

            return true;
        }

        /// <summary>True si el vehiculo cabe en esa pose sin invadir estructura.</summary>
        bool PoseLibre(Vector3 posicion, Quaternion rotacion)
        {
            if (!cuerpoListo)
                return true;

            Vector3 medio = cuerpoLocal.extents * 0.90f;   // 10% de holgura: no roza
            medio.y = Mathf.Max(0.20f, medio.y - 0.15f);

            Vector3 centro = posicion + rotacion * cuerpoLocal.center;
            centro.y = posicion.y + cuerpoLocal.center.y;

            Collider[] hits = Physics.OverlapBox(centro, medio, rotacion, ~0, QueryTriggerInteraction.Ignore);

            for (int i = 0; i < hits.Length; i++)
                if (EsEstructuraSolida(hits[i]))
                    return false;

            return true;
        }

        void Start()
        {
            CacheForkCarriage();
            CreateLabel();
            UpdateLabel();
        }

        void Update()
        {
            if (!runtimeEnabled)
            {
                UpdateLabel();
                return;
            }

            if (replanCooldown > 0f)
                replanCooldown -= Time.deltaTime;

            if (state != StackerState.Idle && state != StackerState.Charging)
                activeTime += Time.deltaTime;

            if (performingYield)
            {
                PerformYield();
                UpdateLabel();
                return;
            }

            if (state == StackerState.Loading || state == StackerState.Unloading)
            {
                currentSpeed = Mathf.MoveTowards(currentSpeed, 0f, braking * Time.deltaTime);
                phaseTimer -= Time.deltaTime;

                if (state == StackerState.Loading)
                    AnimateLoading();
                else
                    AnimateUnloading();

                if (phaseTimer <= 0f)
                {
                    if (state == StackerState.Loading)
                    {
                        EnsurePayloadOnForks();
                        ResetForkCarriageToCarryHeight();

                        state = StackerState.ToDropoff;
                        SetRoute(mission.dropoff);
                    }
                    else
                    {
                        Vector3 deliveredWorldPosition = mission != null
                            ? mission.palletDropoff
                            : transform.position;

                        // payloadVisual es una copia runtime de la Tarima real. Esto evita
                        // problemas con Static Batching de las tarimas que viven en los racks.
                        GameObject deliveredSourcePallet = null;
                        if (payloadVisual != null)
                        {
                            deliveredSourcePallet = payloadVisual;
                            deliveredSourcePallet.transform.SetParent(null, true);
                            deliveredSourcePallet.transform.position = deliveredWorldPosition;
                            deliveredSourcePallet.transform.rotation = Quaternion.identity;
                            payloadVisual = null;
                            payloadIsScenePallet = false;
                        }

                        ResetForkCarriageToFloor();

                        M4Mission done = mission;
                        mission = null;
                        state = StackerState.Idle;

                        if (manager != null)
                            manager.NotifyMissionCompleted(this, done, deliveredWorldPosition, deliveredSourcePallet);
                    }
                }
            }
            else if (state == StackerState.Charging)
            {
                currentSpeed = 0f;
                battery = Mathf.Min(100f, battery + chargeRate * Time.deltaTime);

                if (battery >= 95f)
                {
                    LiberarPuestoDeCarga();   // deja la plaza al siguiente de la cola
                    state = StackerState.Idle;
                }
            }
            else if (state == StackerState.Idle)
            {
                currentSpeed = Mathf.MoveTowards(currentSpeed, 0f, braking * Time.deltaTime);

                if (battery <= lowBatteryThreshold)
                    GoCharge();
            }
            else
            {
                // Una mision ToDropoff nunca debe verse vacia. Si por cualquier motivo
                // el visual se perdio, se reconstruye inmediatamente sobre las horquillas.
                if (state == StackerState.ToDropoff)
                    EnsurePayloadOnForks();

                FollowRoute();
            }

            UpdateLabel();
        }

        public void ResetRuntimeState()
        {
            mission = null;
            state = StackerState.Idle;
            route.Clear();
            routeIndex = 0;
            phaseTimer = 0f;
            distanceTravelled = 0f;
            activeTime = 0f;
            waitingTime = 0f;
            currentSpeed = 0f;
            blockedTimer = 0f;
            replanCooldown = 0f;
            currentDestination = transform.position;
            stateBeforeWaiting = StackerState.Idle;
            runtimeEnabled = true;
            performingYield = false;
            yieldTarget = transform.position;
            noProgressTimer = 0f;
            progressSampleTimer = 0f;
            lastProgressPosition = transform.position;
            routeRetryTimer = 0f;
            failedRoutePlans = 0;
            loadingPayloadAttached = false;
            LiberarPuestoDeCarga();
            RemovePayload();
            payloadIsScenePallet = false;
            ResetForkCarriageToFloor();
        }

        public void StopForExperiment()
        {
            runtimeEnabled = false;
            currentSpeed = 0f;
            route.Clear();
            routeIndex = 0;
        }

        // =====================================================================
        //  DECISION EN DOS FASES  (seccion M4.7 del notebook)
        //
        //  Fase 1  cada AGV publica su vector de estado (distancia, holgura de
        //          bateria, carga de trabajo, congestion) o SE AUTOEXCLUYE si no le
        //          alcanza la energia para ir, entregar y volver a cargar.
        //  Fase 2  cada AGV normaliza min-max DENTRO del conjunto de candidatos y
        //          calcula la utilidad. El maximo se auto-adjudica la mision.
        //
        //  POR QUE CAMBIO. La puja anterior era
        //      -0.55*D + 8*B - 3*C - 6*R
        //  sin normalizar. D es un coste de ruta A* real con rango 0-40 en esta nave;
        //  B, C y R van de 0 a 1. Multiplicados por esos pesos, la distancia aplastaba
        //  a todo lo demas y la estrategia "propuesta" ordenaba a los agentes casi
        //  igual que el baseline (-D). Es decir: la comparacion automatica media dos
        //  estrategias practicamente identicas. Normalizar dentro del conjunto de
        //  candidatos es lo que hace que congestion, carga y energia pesen de verdad.
        //  Ademas la prioridad de la mision no entraba en la puja: solo ordenaba el
        //  bucle de subasta. Ahora si entra, con su peso.
        // =====================================================================
        public struct VectorEstado
        {
            public bool valido;   // paso el filtro duro de energia
            public float d;       // coste de ruta hasta el pickup
            public float s;       // holgura de bateria al terminar el viaje
            public float l;       // carga de trabajo acumulada
            public float c;       // congestion alrededor del pickup
        }

        /// <summary>Fase 1. Devuelve el vector de estado de este AGV para la mision,
        /// o valido=false si se autoexcluye por energia.</summary>
        public VectorEstado CalcularVectorEstado(M4Mission m)
        {
            // Memo por (frame, mision). Dentro de una misma publicacion los seis AGV
            // piden el vector de estado de todos, asi que sin esto se recalcularian
            // seis veces exactamente las mismas rutas.
            if (m != null && vecFrame == Time.frameCount && vecMisionId == m.id)
                return vecCache;

            VectorEstado calculado = CalcularVectorEstadoInterno(m);

            if (m != null)
            {
                vecFrame = Time.frameCount;
                vecMisionId = m.id;
                vecCache = calculado;
            }

            return calculado;
        }

        VectorEstado CalcularVectorEstadoInterno(M4Mission m)
        {
            VectorEstado v = new VectorEstado();
            v.valido = false;

            if (m == null || !IsAvailable)
                return v;

            float dPickup = WarehouseAStar.RouteCost(transform.position, m.pickup);
            if (float.IsNaN(dPickup) || float.IsInfinity(dPickup))
                return v;

            float dEntrega = WarehouseAStar.RouteCost(m.pickup, m.dropoff);
            // Se usa el punto de APROXIMACION, no el centro de la estacion: la
            // estacion esta en (9.8, 9.4), fuera del area navegable del A*, y es el
            // punto de aproximacion el que los AGV recorren de verdad.
            float dRegreso = WarehouseAStar.RouteCost(m.dropoff, M4Params.APROXIMACION_CARGA);
            if (float.IsNaN(dEntrega) || float.IsInfinity(dEntrega)) dEntrega = 0f;
            if (float.IsNaN(dRegreso) || float.IsInfinity(dRegreso)) dRegreso = 0f;

            // Energia del recorrido COMPLETO: ir, entregar y poder volver a cargar.
            float energia = (dPickup + dEntrega + dRegreso) * batteryPerMeter;
            float holgura = battery - M4Params.MARGEN_SEGURIDAD * energia;

            // FILTRO DURO. Antes esto era un castigo suave (batteryRisk) y un AGV sin
            // bateria suficiente podia ganar igual por estar cerca, aceptar la mision
            // y quedarse tirado a mitad del pasillo.
            if (holgura < M4Params.RESERVA)
                return v;

            v.valido = true;
            v.d = dPickup;
            v.s = holgura;
            v.l = distanceTravelled;
            v.c = EstimateCongestion(m.pickup);
            return v;
        }

        static float Norm(float x, float min, float max)
        {
            if (max - min < 0.0001f)
                return 0f;
            return (x - min) / (max - min);
        }

        /// <summary>Fase 2. Utilidad de un vector de estado, normalizado min-max
        /// contra el tablero de candidatos.</summary>
        public float Utilidad(VectorEstado v, List<VectorEstado> tablero, M4Mission m)
        {
            if (!v.valido)
                return float.NegativeInfinity;

            // El baseline es literalmente la puja de M3: gana el mas cercano.
            if (manager != null && manager.strategy == StackerFleetManager.DecisionStrategy.BaselineNearest)
                return -v.d;

            float dMin = float.MaxValue, dMax = float.MinValue;
            float sMin = float.MaxValue, sMax = float.MinValue;
            float lMin = float.MaxValue, lMax = float.MinValue;
            float cMin = float.MaxValue, cMax = float.MinValue;

            for (int i = 0; i < tablero.Count; i++)
            {
                VectorEstado t = tablero[i];
                if (!t.valido)
                    continue;

                if (t.d < dMin) dMin = t.d;
                if (t.d > dMax) dMax = t.d;
                if (t.s < sMin) sMin = t.s;
                if (t.s > sMax) sMax = t.s;
                if (t.l < lMin) lMin = t.l;
                if (t.l > lMax) lMax = t.l;
                if (t.c < cMin) cMin = t.c;
                if (t.c > cMax) cMax = t.c;
            }

            float p = m != null ? Mathf.Clamp01(m.priority / M4Params.PRIORIDAD_MAXIMA) : 0f;

            return -M4Params.W_D * Norm(v.d, dMin, dMax)
                   + M4Params.W_S * Norm(v.s, sMin, sMax)
                   - M4Params.W_L * Norm(v.l, lMin, lMax)
                   - M4Params.W_C * Norm(v.c, cMin, cMax)
                   + M4Params.W_P * p;
        }

        /// <summary>
        /// El Mission Manager NO adjudica: solo avisa de que hay una mision publicada.
        /// Este metodo es la decision, y vive en el agente. Cada AGV arma el tablero
        /// con lo que publican los demas, calcula la utilidad de todos los candidatos
        /// y SE AUTO-ADJUDICA solo si el maximo es el suyo.
        /// </summary>
        public void AlPublicarseMision(M4Mission m, StackerAgent[] flota)
        {
            if (m == null || flota == null || m.status != MissionStatus.Pending)
                return;

            VectorEstado mio = CalcularVectorEstado(m);
            if (!mio.valido)
                return;   // me autoexcluyo: no me alcanza la energia o no estoy libre

            List<VectorEstado> tablero = new List<VectorEstado>();
            List<StackerAgent> candidatos = new List<StackerAgent>();

            for (int i = 0; i < flota.Length; i++)
            {
                StackerAgent a = flota[i];
                if (a == null)
                    continue;

                VectorEstado v = a.CalcularVectorEstado(m);
                if (!v.valido)
                    continue;

                tablero.Add(v);
                candidatos.Add(a);
            }

            if (candidatos.Count == 0)
                return;

            float miUtilidad = float.NegativeInfinity;
            float mejorUtilidad = float.NegativeInfinity;
            StackerAgent mejor = null;

            for (int i = 0; i < candidatos.Count; i++)
            {
                float u = candidatos[i].Utilidad(tablero[i], tablero, m);

                if (candidatos[i] == this)
                    miUtilidad = u;

                // Desempate estable por agentId: sin esto, dos AGV con la misma
                // utilidad podrian auto-adjudicarse los dos, o ninguno.
                bool gana = mejor == null ||
                            u > mejorUtilidad + 0.0001f ||
                            (Mathf.Abs(u - mejorUtilidad) <= 0.0001f && candidatos[i].agentId < mejor.agentId);

                if (gana)
                {
                    mejorUtilidad = u;
                    mejor = candidatos[i];
                }
            }

            if (mejor != this)
                return;   // otro candidato tiene mejor utilidad: no la tomo

            m.status = MissionStatus.Assigned;
            AcceptMission(m);

            Debug.Log("[NEGOCIACION] AGV " + agentId + " SE AUTO-ADJUDICA la mision " + m.id +
                      " P" + m.priority +
                      " | U=" + miUtilidad.ToString("0.00") +
                      " | candidatos=" + candidatos.Count +
                      " | estrategia=" + (manager != null ? manager.strategy.ToString() : "?"));
        }

        float EstimateCongestion(Vector3 destination)
        {
            if (manager == null || manager.agents == null)
                return 0f;

            int near = 0;
            for (int i = 0; i < manager.agents.Length; i++)
            {
                StackerAgent other = manager.agents[i];
                if (other == null || other == this)
                    continue;

                if (Vector3.Distance(other.transform.position, destination) < 4f)
                    near++;
            }

            return near;
        }

        public void AcceptMission(M4Mission m)
        {
            mission = m;
            state = StackerState.ToPickup;
            m.status = MissionStatus.InProgress;
            m.startedAt = Time.time;
            SetRoute(m.pickup);
        }

        void SetRoute(Vector3 target)
        {
            currentDestination = target;
            route.Clear();
            route.AddRange(WarehouseAStar.Plan(transform.position, target, this));
            routeIndex = 0;

            // El primer nodo puede estar practicamente debajo del AGV.
            while (routeIndex < route.Count && FlatDistance(transform.position, route[routeIndex]) < stopDistance * 1.5f)
                routeIndex++;

            if (routeIndex >= route.Count && FlatDistance(transform.position, currentDestination) > nearDestinationArrivalDistance)
            {
                failedRoutePlans++;
                routeRetryTimer = 0.65f;
            }
            else
            {
                failedRoutePlans = 0;
                routeRetryTimer = 0f;
            }
        }

        static float FlatDistance(Vector3 a, Vector3 b)
        {
            a.y = 0f;
            b.y = 0f;
            return Vector3.Distance(a, b);
        }

        void FollowRoute()
        {
            UpdateProgressWatchdog();

            if (route.Count == 0 || routeIndex >= route.Count)
            {
                float remaining = FlatDistance(transform.position, currentDestination);
                if (remaining <= nearDestinationArrivalDistance)
                {
                    Arrived();
                    return;
                }

                // Una ruta vacia ya no significa "llegue". Antes esto podia hacer
                // que un AGV pasara a ToDropoff aun pegado al rack.
                currentSpeed = Mathf.MoveTowards(currentSpeed, 0f, braking * Time.deltaTime);
                waitingTime += Time.deltaTime;
                routeRetryTimer -= Time.deltaTime;

                if (routeRetryTimer <= 0f)
                {
                    Vector3 safeTarget = WarehouseAStar.SnapToFreePoint(currentDestination);
                    currentDestination = safeTarget;
                    SetRoute(currentDestination);
                    routeRetryTimer = 0.75f;
                }

                // El rescate reposiciona al AGV, asi que ahora solo se permite cuando
                // de verdad quedo con el cuerpo dentro de geometria (por ejemplo si
                // alguien lo movio a mano en el editor). Si su pose es valida, no se
                // le mueve: se sigue replaneando.
                if (failedRoutePlans >= 3 && !PoseLibre(transform.position, transform.rotation))
                {
                    // Si el AGV quedo montado sobre un collider, lo ajusta a la celda
                    // transitable mas cercana y vuelve a planear. Es un rescate corto.
                    Vector3 rescue = WarehouseAStar.SnapToFreePoint(transform.position);
                    transform.position = new Vector3(rescue.x, transform.position.y, rescue.z);
                    failedRoutePlans = 0;
                    SetRoute(currentDestination);
                    Debug.Log("[RUTA] AGV " + agentId + " recupera una ruta valida hacia su objetivo.");
                }
                return;
            }

            Vector3 waypoint = route[routeIndex];
            Vector3 alWaypoint = waypoint - transform.position;
            alWaypoint.y = 0f;
            float distanceToWaypoint = alWaypoint.magnitude;

            // Se avanza de vertice por cercania O POR REBASE. Antes solo por cercania:
            // si el AGV se desviaba un poco al esquivar, podia orbitar alrededor de un
            // vertice que ya habia dejado atras sin llegar nunca a tocarlo. Eso es
            // buena parte de lo que se veia como movimiento sin sentido.
            bool rebasado = false;
            if (routeIndex + 1 < route.Count && distanceToWaypoint < 1.6f)
            {
                Vector3 seg = route[routeIndex + 1] - waypoint;
                seg.y = 0f;
                if (seg.sqrMagnitude > 0.0001f)
                {
                    Vector3 rel = transform.position - waypoint;
                    rel.y = 0f;
                    rebasado = Vector3.Dot(rel, seg.normalized) > 0f;
                }
            }

            if (distanceToWaypoint <= stopDistance || rebasado)
            {
                routeIndex++;

                if (routeIndex >= route.Count)
                    Arrived();

                return;
            }

            // Persecucion de punto adelantado: se apunta a un punto situado
            // 'distanciaAnticipacion' metros mas adelante SOBRE la ruta, no al vertice
            // inmediato. Con esto el AGV entra en las curvas describiendo un arco en
            // vez de ir en linea recta al vertice, frenar, girar y volver a arrancar.
            Vector3 target = PuntoAdelantado();
            Vector3 flat = target - transform.position;
            flat.y = 0f;
            if (flat.sqrMagnitude < 0.0001f) flat = alWaypoint;

            Vector3 moveDirection = flat.normalized;

            // Muy cerca del destino de pickup/dropoff, el rack o la banda pueden aparecer
            // en el SphereCast. En ese caso se considera llegada en vez de quedar en Waiting.
            if (FlatDistance(transform.position, currentDestination) <= nearDestinationArrivalDistance)
            {
                Arrived();
                return;
            }

            StackerAgent blockingAgent;
            BlockType block = DetectBlock(moveDirection, Mathf.Min(detectionDistance, distanceToWaypoint), out blockingAgent);

            if (block != BlockType.None)
            {
                EnterWaiting();
                blockedTimer += Time.deltaTime;
                waitingTime += Time.deltaTime;
                currentSpeed = Mathf.MoveTowards(currentSpeed, 0f, braking * Time.deltaTime);

                // Desempate distribuido: el AGV de menor prioridad se aparta fisicamente.
                if (block == BlockType.Agent && blockingAgent != null && ShouldYieldTo(blockingAgent))
                {
                    if (blockedTimer >= 0.18f)
                        StartYieldManeuver(blockingAgent, moveDirection);
                    return;
                }

                // Peatones solo provocan espera breve. Para racks/AGV se intenta recuperar
                // automaticamente para que ningun agente quede congelado durante la demo.
                if (blockedTimer >= recoveryAfterSeconds && block != BlockType.Pedestrian)
                {
                    if (TryEmergencyRecovery(blockingAgent, moveDirection))
                        return;
                }

                if (blockedTimer >= 0.65f && replanCooldown <= 0f && block != BlockType.Pedestrian)
                {
                    SetRoute(currentDestination);
                    replanCooldown = 0.8f;
                }

                if (blockedTimer >= emergencyRecoveryAfterSeconds)
                {
                    // Ultimo recurso: si ya estamos razonablemente cerca del objetivo,
                    // completar la aproximacion para evitar deadlocks visuales.
                    if (FlatDistance(transform.position, currentDestination) <= 0.95f)
                    {
                        Arrived();
                        return;
                    }

                    TryEmergencyRecovery(blockingAgent, moveDirection);
                    blockedTimer = 0f;
                }

                return;
            }

            if (state == StackerState.Waiting)
                state = stateBeforeWaiting;

            blockedTimer = 0f;

            Quaternion desired = Quaternion.LookRotation(moveDirection, Vector3.up) * Quaternion.Euler(0f, modelYawOffset, 0f);
            Quaternion siguienteRotacion = Quaternion.RotateTowards(
                transform.rotation, desired, turnDegreesPerSecond * Time.deltaTime);

            // Girar tambien puede meter la nariz dentro de un rack: se comprueba.
            if (PoseLibre(transform.position, siguienteRotacion))
                transform.rotation = siguienteRotacion;
            else
                blockedTimer += Time.deltaTime;

            float angle = Quaternion.Angle(transform.rotation, desired);

            float targetSpeed = speed;

            // ANTES: cualquier desvio de mas de 32 grados ponia la velocidad a CERO, asi
            // que el AGV se detenia en seco en cada esquina y en cada correccion de rumbo.
            // Visualmente era lo mas artificial de todo: avanzar, congelarse, girar,
            // avanzar. Un apilador de verdad reduce y sigue rodando mientras corrige.
            if (angle > anguloGiroParado)
                targetSpeed = 0f;                       // media vuelta: si gira parado
            else if (angle > turnInPlaceAngle)
                targetSpeed = speed * velocidadEnGiro;  // corrige rumbo sin detenerse
            else
                targetSpeed *= Mathf.Clamp01(1f - angle / Mathf.Max(1f, turnInPlaceAngle * 1.4f));

            // ANTES se frenaba al acercarse a CADA vertice de la ruta. Como el A*
            // deja vertices cada pocos metros, el AGV vivia frenando y acelerando
            // aunque fuera en linea recta. Ahora solo frena de verdad al acercarse al
            // DESTINO; en las esquinas ya reduce por el termino de angulo de arriba.
            float alDestino = FlatDistance(transform.position, currentDestination);
            if (alDestino < 1.3f)
                targetSpeed *= Mathf.Lerp(0.30f, 1f, alDestino / 1.3f);

            float rate = targetSpeed > currentSpeed ? acceleration : braking;
            currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, rate * Time.deltaTime);

            if (currentSpeed <= 0.001f)
                return;

            Vector3 old = transform.position;
            Vector3 desiredPosition = new Vector3(target.x, old.y, target.z);
            Vector3 next = Vector3.MoveTowards(old, desiredPosition, currentSpeed * Time.deltaTime);

            // GARANTIA DURA: si esa posicion mete el cuerpo dentro de estructura, no
            // se aplica. Pero antes de rendirse se prueba un paso mas corto: muchas
            // veces la caja solo roza por unos centimetros y basta con avanzar menos.
            // Sin esto el AGV se paraba en seco y replaneaba una y otra vez, que es
            // otra de las causas del movimiento a tirones.
            if (!PoseLibre(next, transform.rotation))
            {
                bool avanzo = false;
                for (float f = 0.55f; f >= 0.15f; f -= 0.20f)
                {
                    Vector3 corto = Vector3.MoveTowards(old, desiredPosition,
                                                        currentSpeed * Time.deltaTime * f);
                    if (PoseLibre(corto, transform.rotation))
                    {
                        next = corto;
                        avanzo = true;
                        break;
                    }
                }

                if (!avanzo)
                {
                    currentSpeed = Mathf.MoveTowards(currentSpeed, 0f, braking * Time.deltaTime);
                    blockedTimer += Time.deltaTime;

                    if (replanCooldown <= 0f)
                    {
                        SetRoute(currentDestination);
                        replanCooldown = 0.6f;
                    }
                    return;
                }
            }

            transform.position = next;

            float d = Vector3.Distance(old, next);
            distanceTravelled += d;
            battery = Mathf.Max(0f, battery - d * batteryPerMeter);
        }

        /// <summary>Punto situado 'distanciaAnticipacion' metros por delante SOBRE la
        /// ruta ya planeada. No inventa atajos: recorre los segmentos existentes, asi
        /// que nunca apunta fuera del camino que el A* considero transitable.</summary>
        Vector3 PuntoAdelantado()
        {
            Vector3 pos = transform.position;

            if (route.Count == 0 || routeIndex >= route.Count)
                return pos;

            Vector3 objetivo = route[routeIndex];
            Vector3 d = objetivo - pos;
            d.y = 0f;

            float restante = distanciaAnticipacion - d.magnitude;
            int i = routeIndex;

            while (restante > 0f && i + 1 < route.Count)
            {
                Vector3 a = route[i];
                Vector3 b = route[i + 1];
                Vector3 seg = b - a;
                seg.y = 0f;

                float largo = seg.magnitude;
                if (largo < 0.001f) { i++; continue; }

                if (restante >= largo)
                {
                    objetivo = b;
                    restante -= largo;
                    i++;
                }
                else
                {
                    objetivo = a + seg.normalized * restante;
                    restante = 0f;
                }
            }

            objetivo.y = pos.y;
            return objetivo;
        }

        void EnterWaiting()
        {
            if (state == StackerState.Waiting)
                return;

            stateBeforeWaiting = state;
            state = StackerState.Waiting;

            if (manager != null)
                manager.NotifyWaitEvent();
        }

        BlockType DetectBlock(Vector3 direction, float distance, out StackerAgent blockingAgent)
        {
            blockingAgent = null;

            if (direction.sqrMagnitude < 0.001f || distance <= 0.01f)
                return BlockType.None;

            Vector3 origin = transform.position + Vector3.up * 0.68f;
            RaycastHit[] hits = Physics.SphereCastAll(origin, bodyRadius, direction, distance, ~0, QueryTriggerInteraction.Ignore);

            for (int i = 0; i < hits.Length; i++)
            {
                Collider col = hits[i].collider;
                if (col == null || col.isTrigger)
                    continue;

                Transform t = col.transform;
                if (t == transform || t.IsChildOf(transform))
                    continue;

                // Ignora piso y zonas planas muy bajas.
                if (col.bounds.max.y < 0.18f)
                    continue;

                string n = col.gameObject.name.ToLowerInvariant();
                if (n.Contains("piso") || n.Contains("floor") || n.Contains("suelo"))
                    continue;

                DynamicPedestrian pedestrian = col.GetComponentInParent<DynamicPedestrian>();
                if (pedestrian != null)
                    return BlockType.Pedestrian;

                StackerAgent otherAgent = col.GetComponentInParent<StackerAgent>();
                if (otherAgent != null && otherAgent != this)
                {
                    // El que pierde la prioridad se aparta. El que tiene prioridad
                    // solo se detiene si ya existe una separacion de emergencia.
                    if (ShouldYieldTo(otherAgent) || hits[i].distance < emergencyStopDistance)
                    {
                        blockingAgent = otherAgent;
                        return BlockType.Agent;
                    }

                    continue;
                }

                // ANTES: BelongsToRackOrPallet() descartaba TODO lo que colgara de un
                // objeto llamado "Rack_*" -puntales y vigas incluidos- con el argumento
                // de que "A* ya evita los racks". Pero el A* planea con un disco de
                // radio 0.48 m y el vehiculo mide 2.45 m de largo, asi que al girar
                // barria dentro del anaquel. Esa exclusion era la causa directa de que
                // los AGV atravesaran las columnas.
                //
                // Ahora solo se ignora la carga BLANDA (tarimas, cajas, estibas), que es
                // donde las horquillas tienen que entrar. La estructura bloquea.
                if (EsCargaBlanda(col))
                    continue;

                return BlockType.Static;
            }

            return BlockType.None;
        }




        void StartYieldManeuver(StackerAgent other, Vector3 routeDirection)
        {
            if (performingYield || other == null)
                return;

            Vector3 dir = routeDirection;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.001f)
                dir = (currentDestination - transform.position).normalized;
            if (dir.sqrMagnitude < 0.001f)
                dir = transform.forward;
            dir.Normalize();

            Vector3 right = Vector3.Cross(Vector3.up, dir).normalized;
            Vector3 origin = transform.position;

            Vector3[] candidates = new Vector3[]
            {
                origin - dir * yieldDistance,
                origin - dir * (yieldDistance * 0.75f) + right * 0.95f,
                origin - dir * (yieldDistance * 0.75f) - right * 0.95f,
                origin + right * 1.10f,
                origin - right * 1.10f
            };

            float bestScore = float.NegativeInfinity;
            Vector3 best = origin;

            for (int i = 0; i < candidates.Length; i++)
            {
                Vector3 c = candidates[i];
                c.y = origin.y;

                if (!WarehouseAStar.IsPositionFree(c, bodyRadius * 0.92f))
                    continue;
                if (!IsClearOfOtherAgents(c, other))
                    continue;

                float score = FlatDistance(c, other.transform.position) * 2f
                              - FlatDistance(c, currentDestination) * 0.08f;

                if (score > bestScore)
                {
                    bestScore = score;
                    best = c;
                }
            }

            if (bestScore == float.NegativeInfinity)
                return;

            yieldTarget = best;
            performingYield = true;
            blockedTimer = 0f;
        }

        bool IsClearOfOtherAgents(Vector3 point, StackerAgent ignored)
        {
            if (manager == null || manager.agents == null)
                return true;

            for (int i = 0; i < manager.agents.Length; i++)
            {
                StackerAgent other = manager.agents[i];
                if (other == null || other == this || other == ignored)
                    continue;

                if (FlatDistance(point, other.transform.position) < bodyRadius * 2.3f)
                    return false;
            }

            return true;
        }

        void PerformYield()
        {
            EnterWaiting();
            waitingTime += Time.deltaTime;

            Vector3 flat = yieldTarget - transform.position;
            flat.y = 0f;

            if (flat.magnitude <= 0.10f)
            {
                performingYield = false;
                blockedTimer = 0f;
                replanCooldown = 0.25f;
                state = stateBeforeWaiting;
                SetRoute(currentDestination);
                return;
            }

            Vector3 moveDirection = flat.normalized;
            Quaternion desired = Quaternion.LookRotation(moveDirection, Vector3.up) * Quaternion.Euler(0f, modelYawOffset, 0f);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, desired, turnDegreesPerSecond * Time.deltaTime);

            currentSpeed = Mathf.MoveTowards(currentSpeed, yieldSpeed, acceleration * Time.deltaTime);
            Vector3 old = transform.position;
            Vector3 next = Vector3.MoveTowards(old, new Vector3(yieldTarget.x, old.y, yieldTarget.z), currentSpeed * Time.deltaTime);

            if (!WarehouseAStar.IsPositionFree(next, bodyRadius * 0.90f) ||
                !PoseLibre(next, transform.rotation))
            {
                performingYield = false;
                currentSpeed = 0f;
                return;
            }

            transform.position = next;
            float d = Vector3.Distance(old, next);
            distanceTravelled += d;
            battery = Mathf.Max(0f, battery - d * batteryPerMeter);
        }

        bool ShouldYieldTo(StackerAgent other)
        {
            if (other == null)
                return false;

            bool myChargingTrip = state == StackerState.ToCharge || stateBeforeWaiting == StackerState.ToCharge;
            bool otherChargingTrip = other.state == StackerState.ToCharge || other.stateBeforeWaiting == StackerState.ToCharge;

            if (myChargingTrip != otherChargingTrip)
                return !myChargingTrip;

            int myPriority = mission != null ? mission.priority : 0;
            int otherPriority = other.mission != null ? other.mission.priority : 0;

            if (myPriority != otherPriority)
                return myPriority < otherPriority;

            return agentId > other.agentId;
        }

        void Arrived()
        {
            currentSpeed = 0f;
            route.Clear();
            routeIndex = 0;

            if (state == StackerState.ToPickup ||
                (state == StackerState.Waiting && stateBeforeWaiting == StackerState.ToPickup))
            {
                state = StackerState.Loading;
                phaseTimer = loadingDuration;
                BeginLoadingPayload();
            }
            else if (state == StackerState.ToDropoff ||
                     (state == StackerState.Waiting && stateBeforeWaiting == StackerState.ToDropoff))
            {
                state = StackerState.Unloading;
                phaseTimer = unloadingDuration;
            }
            else if (state == StackerState.ToCharge ||
                     (state == StackerState.Waiting && stateBeforeWaiting == StackerState.ToCharge))
            {
                // Solo se carga si hay plaza. La estacion tiene 2 puestos para 6
                // apiladores: es un recurso en disputa, no un punto magico donde
                // caben todos. Si no hay plaza el AGV espera en su punto de cola y
                // vuelve a intentarlo (Arrived se reevalua con la ruta vacia).
                if (manager == null)
                {
                    state = StackerState.Charging;
                }
                else if (chargeBay >= 0 || manager.PedirPuestoDeCarga(this, out chargeBay))
                {
                    Vector3 plaza = manager.PosicionPuestoDeCarga(chargeBay);
                    if (FlatDistance(transform.position, plaza) > nearDestinationArrivalDistance)
                    {
                        state = StackerState.ToCharge;
                        SetRoute(plaza);   // consiguio plaza estando en la cola: va a ella
                    }
                    else
                    {
                        state = StackerState.Charging;
                    }
                }
                else
                {
                    state = StackerState.ToCharge;
                    waitingTime += Time.deltaTime;
                }
            }
        }

        void GoCharge()
        {
            state = StackerState.ToCharge;

            if (manager != null)
                manager.NotifyChargeEvent();

            // Antes todos los AGV iban al mismo punto hardcodeado, sin limite de
            // plazas: los seis podian encimarse en la misma celda y cargar a la vez.
            // Ahora se pide plaza; si no hay, se hace cola en un punto propio.
            if (manager != null && manager.PedirPuestoDeCarga(this, out chargeBay))
            {
                SetRoute(manager.PosicionPuestoDeCarga(chargeBay));
            }
            else
            {
                chargeBay = -1;
                SetRoute(manager != null
                    ? manager.PuntoDeEsperaDeCarga(agentId)
                    : M4Params.APROXIMACION_CARGA);
            }
        }

        void LiberarPuestoDeCarga()
        {
            if (manager != null && chargeBay >= 0)
                manager.LiberarPuestoDeCarga(this, chargeBay);
            chargeBay = -1;
        }

        void BeginLoadingPayload()
        {
            RemovePayload();
            CacheForkCarriage();
            loadingPayloadAttached = false;

            if (mission == null || mission.sourcePallet == null)
            {
                // Respaldo visual para que ToDropoff nunca vaya vacio.
                AttachPayload();
                loadingPayloadAttached = payloadVisual != null;
                return;
            }

            GameObject source = mission.sourcePallet;
            if (!source.activeSelf)
                source.SetActive(true);

            // Las Tarimas originales del rack forman parte del escenario y algunas estan
            // incluidas en static batching. Mover un clon de ese objeto puede hacerlo invisible.
            // Por eso se crea una carga runtime 100% movil y visible, inspirada en la tarima real.
            payloadVisual = CreateTransportLoad(source.transform.position, source.transform.rotation, source);
            payloadVisual.name = "Tarima_En_AGV_" + agentId + "_M" + mission.id;
            payloadIsScenePallet = false;

            // El original se oculta durante la mision. Se restaura al reiniciar
            // baseline/propuesta desde StackerFleetManager.RestoreRackPallets().
            source.SetActive(false);

            Debug.Log("[PICKUP] AGV " + agentId +
                      " toma Tarima REAL de " + mission.pickupName +
                      " -> " + mission.dropoffName);
        }

        void CacheForkCarriage()
        {
            if (forkCarriageReady && forkCarriage != null)
                return;

            // 1) El modelo de VehicleFactory trae un nodo "Carro" que ya agrupa las
            //    horquillas. Si existe, se usa tal cual.
            Transform[] all = GetComponentsInChildren<Transform>(true);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].name == "Carro")
                {
                    forkCarriage = all[i];
                    forkCarriageBaseLocalPosition = forkCarriage.localPosition;
                    forkCarriageReady = true;
                    return;
                }
            }

            // 2) El prefab V4_Apilador_de_Stacks esta modelado a mano y NO tiene
            //    "Carro": sus horquillas se llaman Pala1 y Pala2 y cuelgan de la raiz.
            //    Antes se caia al respaldo forkCarriage = transform, y como toda la
            //    animacion estaba detras de un  if (forkCarriage != transform),
            //    LAS HORQUILLAS NUNCA SE MOVIAN. La unica animacion visible era la
            //    caja deslizandose sola, que es justo lo que se veia poco natural.
            //
            //    Ahora se construye el carro que al modelo le falta: un nodo propio
            //    que agrupa las horquillas y que si se puede subir y bajar.
            Transform creado = ConstruirCarroDeHorquillas();
            if (creado != null)
            {
                forkCarriage = creado;
                forkCarriageBaseLocalPosition = creado.localPosition;
                forkCarriageReady = true;
                return;
            }

            forkCarriage = transform;
            forkCarriageBaseLocalPosition = Vector3.zero;
            forkCarriageReady = true;
        }

        Transform ConstruirCarroDeHorquillas()
        {
            Transform yaEsta = transform.Find("Carro_Horquillas");
            if (yaEsta != null)
                return yaEsta;

            List<Transform> piezas = new List<Transform>();
            Transform[] all = GetComponentsInChildren<Transform>(true);

            for (int i = 0; i < all.Length; i++)
            {
                Transform t = all[i];
                if (t == null || t == transform) continue;

                string n = t.name.ToLowerInvariant();
                if (!(n.StartsWith("pala") || n.StartsWith("horquilla") || n.StartsWith("fork")))
                    continue;

                // No reparentar algo que ya cuelga de otra pieza recogida.
                bool descendiente = false;
                for (int k = 0; k < piezas.Count; k++)
                    if (t.IsChildOf(piezas[k])) { descendiente = true; break; }

                if (!descendiente)
                    piezas.Add(t);
            }

            if (piezas.Count == 0)
                return null;

            GameObject carro = new GameObject("Carro_Horquillas");
            carro.transform.SetParent(transform, false);
            carro.transform.localPosition = Vector3.zero;
            carro.transform.localRotation = Quaternion.identity;
            carro.transform.localScale = Vector3.one;

            // true conserva la pose mundial: las horquillas no se mueven al agruparlas.
            for (int i = 0; i < piezas.Count; i++)
                piezas[i].SetParent(carro.transform, true);

            Debug.Log("[HORQUILLAS] AGV " + agentId + ": carro construido con " +
                      piezas.Count + " pieza(s).");

            return carro.transform;
        }

        bool HayCarro()
        {
            CacheForkCarriage();
            return forkCarriage != null && forkCarriage != transform;
        }

        /// <summary>Coloca las horquillas a una altura RELATIVA a su reposo.
        /// 0 = posicion modelada, positivo = elevadas.</summary>
        void PonerHorquillas(float alturaRelativa)
        {
            if (!HayCarro())
                return;

            Vector3 p = forkCarriageBaseLocalPosition;
            p.y = forkCarriageBaseLocalPosition.y +
                  Mathf.Clamp(alturaRelativa, -0.08f, alturaMaximaHorquillas);
            forkCarriage.localPosition = p;
        }

        /// <summary>Interpolacion suave entre dos marcas de tiempo normalizadas.</summary>
        static float Tramo(float desde, float hasta, float t)
        {
            if (hasta - desde < 0.0001f) return 1f;
            return Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((t - desde) / (hasta - desde)));
        }

        void ResetForkCarriageToFloor()
        {
            PonerHorquillas(0f);
        }

        void ResetForkCarriageToCarryHeight()
        {
            PonerHorquillas(alturaTransporte);
        }

        /// <summary>Cuanto tienen que subir las horquillas para llegar a la tarima
        /// que esta en el rack, medido desde su reposo.</summary>
        float AlturaDeRecogida()
        {
            if (!HayCarro() || mission == null || mission.sourcePallet == null)
                return alturaTransporte;

            CalcularPosicionesDeCarga();

            float yTarima = transform.InverseTransformPoint(mission.sourcePallet.transform.position).y;
            return Mathf.Clamp(yTarima - alturaApoyoRaiz, 0f, alturaMaximaHorquillas);
        }

        // =====================================================================
        //  RECOGIDA: subir -> enganchar -> extraer -> bajar a transporte
        //
        //  Antes esto era una interpolacion lineal de la caja mientras las
        //  horquillas se quedaban quietas (ver CacheForkCarriage). Ahora es la
        //  secuencia de un apilador de verdad, con las horquillas subiendo hasta
        //  la altura real de la tarima en el rack y bajando con ella despues.
        // =====================================================================
        void AnimateLoading()
        {
            CacheForkCarriage();

            float t = 1f - Mathf.Clamp01(phaseTimer / Mathf.Max(0.01f, loadingDuration));
            float hRecogida = AlturaDeRecogida();

            // ---- 0 a 30%: las horquillas suben hasta la tarima ------------------
            if (t < 0.30f)
            {
                PonerHorquillas(Mathf.Lerp(0f, hRecogida, Tramo(0f, 0.30f, t)));
                return;
            }

            // ---- al 30%: la tarima se engancha conservando su pose mundial ------
            if (!loadingPayloadAttached && payloadVisual != null)
            {
                Transform padre = forkCarriage != null ? forkCarriage : transform;
                payloadVisual.transform.SetParent(padre, true);
                payloadLoadStartLocalPosition = payloadVisual.transform.localPosition;
                payloadLoadStartLocalRotation = payloadVisual.transform.localRotation;
                loadingPayloadAttached = true;
            }

            // ---- 30 a 45%: levanta la tarima del larguero -----------------------
            if (t < 0.45f)
            {
                PonerHorquillas(hRecogida + alturaEnganche * Tramo(0.30f, 0.45f, t));
                return;
            }

            // ---- 45 a 78%: la tarima sale del rack y se centra en las horquillas -
            if (t < 0.78f)
            {
                PonerHorquillas(hRecogida + alturaEnganche);

                if (payloadVisual != null && loadingPayloadAttached)
                {
                    float u = Tramo(0.45f, 0.78f, t);
                    payloadVisual.transform.localPosition =
                        Vector3.Lerp(payloadLoadStartLocalPosition, CargaLocal(), u);
                    payloadVisual.transform.localRotation =
                        Quaternion.Slerp(payloadLoadStartLocalRotation, CargaRotacionLocal(), u);
                }
                return;
            }

            // ---- 78 a 100%: desciende a la altura de transporte -----------------
            float v = Tramo(0.78f, 1f, t);
            PonerHorquillas(Mathf.Lerp(hRecogida + alturaEnganche, alturaTransporte, v));
            EnsurePayloadOnForks();
        }

        // =====================================================================
        //  DESCARGA: bajar -> depositar deslizando -> soltar
        // =====================================================================
        void AnimateUnloading()
        {
            CacheForkCarriage();

            float t = 1f - Mathf.Clamp01(phaseTimer / Mathf.Max(0.01f, unloadingDuration));

            // ---- 0 a 32%: las horquillas bajan con la tarima hasta el suelo ------
            if (t < 0.32f)
            {
                PonerHorquillas(Mathf.Lerp(alturaTransporte, 0f, Tramo(0f, 0.32f, t)));
                return;
            }

            PonerHorquillas(0f);

            // ---- 32 a 80%: la tarima se desliza hacia adelante y queda depositada
            if (payloadVisual != null)
            {
                float u = Tramo(0.32f, 0.80f, t);
                payloadVisual.transform.localPosition =
                    Vector3.Lerp(CargaLocal(), DescargaLocal(), u);
                payloadVisual.transform.localRotation = CargaRotacionLocal();
            }

            // ---- 80 a 100%: las horquillas se retiran un poco por debajo ---------
            if (t >= 0.80f)
                PonerHorquillas(Mathf.Lerp(0f, -0.05f, Tramo(0.80f, 1f, t)));

            // El manager fija la tarima exactamente en D1-D4 al terminar la fase.
        }

        void EnsurePayloadOnForks()
        {
            if (payloadVisual == null)
            {
                AttachPayload();
                loadingPayloadAttached = payloadVisual != null;
            }

            if (payloadVisual == null)
                return;

            CacheForkCarriage();
            Transform payloadParent = forkCarriage != null ? forkCarriage : transform;

            if (payloadVisual.transform.parent != payloadParent)
                payloadVisual.transform.SetParent(payloadParent, true);

            payloadVisual.transform.localPosition = CargaLocal();
            payloadVisual.transform.localRotation = CargaRotacionLocal();
        }

        void UpdateProgressWatchdog()
        {
            progressSampleTimer += Time.deltaTime;
            if (progressSampleTimer < 0.50f)
                return;

            float moved = FlatDistance(transform.position, lastProgressPosition);
            if (moved < 0.035f)
                noProgressTimer += progressSampleTimer;
            else
                noProgressTimer = 0f;

            lastProgressPosition = transform.position;
            progressSampleTimer = 0f;

            if (noProgressTimer >= emergencyRecoveryAfterSeconds &&
                state != StackerState.Loading &&
                state != StackerState.Unloading &&
                state != StackerState.Charging)
            {
                Vector3 dir = currentDestination - transform.position;
                dir.y = 0f;
                if (dir.sqrMagnitude < 0.001f)
                    dir = transform.forward;

                TryEmergencyRecovery(null, dir.normalized);
                noProgressTimer = 0f;
            }
        }

        bool TryEmergencyRecovery(StackerAgent blockingAgent, Vector3 routeDirection)
        {
            if (performingYield)
                return true;

            Vector3 dir = routeDirection;
            dir.y = 0f;
            if (dir.sqrMagnitude < 0.001f)
                dir = currentDestination - transform.position;
            if (dir.sqrMagnitude < 0.001f)
                dir = transform.forward;
            dir.Normalize();

            Vector3 right = Vector3.Cross(Vector3.up, dir).normalized;
            float sideSign = (agentId % 2 == 0) ? 1f : -1f;

            Vector3[] candidates =
            {
                transform.position - dir * 1.10f,
                transform.position - dir * 0.85f + right * sideSign * 0.95f,
                transform.position - dir * 0.85f - right * sideSign * 0.95f,
                transform.position + right * sideSign * 1.05f,
                transform.position - right * sideSign * 1.05f,
                transform.position - dir * 1.45f
            };

            for (int i = 0; i < candidates.Length; i++)
            {
                Vector3 c = candidates[i];
                c.y = transform.position.y;

                if (!WarehouseAStar.IsPositionFree(c, bodyRadius * 0.82f))
                    continue;

                if (!IsClearOfOtherAgents(c, blockingAgent))
                    continue;

                yieldTarget = c;
                performingYield = true;
                blockedTimer = 0f;
                replanCooldown = 0.15f;
                Debug.Log("[RECOVERY] AGV " + agentId + " se aparta para romper bloqueo.");
                return true;
            }

            // Si no hay hueco lateral, busca alrededor del AGV una celda libre real.
            // Esto rompe casos en los que queda encerrado por varios AGV en un cruce.
            for (int ring = 0; ring < 3; ring++)
            {
                float radius = 0.85f + ring * 0.45f;
                for (int a = 0; a < 16; a++)
                {
                    float angle = (Mathf.PI * 2f * a) / 16f;
                    Vector3 c = transform.position + new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * radius;
                    c.y = transform.position.y;
                    if (!WarehouseAStar.IsPositionFree(c, bodyRadius * 0.78f))
                        continue;
                    if (!IsClearOfOtherAgents(c, blockingAgent))
                        continue;

                    yieldTarget = c;
                    performingYield = true;
                    blockedTimer = 0f;
                    replanCooldown = 0.15f;
                    Debug.Log("[RECOVERY] AGV " + agentId + " encuentra salida de emergencia.");
                    return true;
                }
            }

            // Si ya esta junto al objetivo, completa la aproximacion en vez de esperar para siempre.
            if (FlatDistance(transform.position, currentDestination) <= 1.05f)
            {
                Arrived();
                return true;
            }

            return false;
        }

        static float SafeScale(float worldScale, float parentScale)
        {
            if (Mathf.Abs(parentScale) < 0.0001f)
                return worldScale;

            return worldScale / parentScale;
        }

        GameObject CreateTransportLoad(Vector3 worldPosition, Quaternion worldRotation, GameObject source)
        {
            GameObject root = new GameObject("Carga_AGV");
            root.transform.position = worldPosition;
            root.transform.rotation = worldRotation;

            Material sourceMaterial = null;
            if (source != null)
            {
                Renderer sr = source.GetComponentInChildren<Renderer>(true);
                if (sr != null && sr.sharedMaterial != null)
                    sourceMaterial = sr.sharedMaterial;
            }

            Material wood = CreateRuntimeMaterial(new Color(0.58f, 0.34f, 0.16f));
            Material box = sourceMaterial != null ? sourceMaterial : CreateRuntimeMaterial(new Color(0.72f, 0.52f, 0.28f));

            CreateLoadCube(root.transform, "Pallet_Base", new Vector3(0f, 0f, 0f), new Vector3(0.70f, 0.10f, 0.84f), wood);
            CreateLoadCube(root.transform, "Pallet_Slat_I", new Vector3(-0.24f, 0.08f, 0f), new Vector3(0.11f, 0.08f, 0.84f), wood);
            CreateLoadCube(root.transform, "Pallet_Slat_D", new Vector3(0.24f, 0.08f, 0f), new Vector3(0.11f, 0.08f, 0.84f), wood);

            CreateLoadCube(root.transform, "Caja_1", new Vector3(-0.18f, 0.28f, -0.18f), new Vector3(0.32f, 0.34f, 0.32f), box);
            CreateLoadCube(root.transform, "Caja_2", new Vector3( 0.18f, 0.28f, -0.18f), new Vector3(0.32f, 0.34f, 0.32f), box);
            CreateLoadCube(root.transform, "Caja_3", new Vector3(-0.18f, 0.28f,  0.18f), new Vector3(0.32f, 0.34f, 0.32f), box);
            CreateLoadCube(root.transform, "Caja_4", new Vector3( 0.18f, 0.28f,  0.18f), new Vector3(0.32f, 0.34f, 0.32f), box);

            return root;
        }

        static void CreateLoadCube(Transform parent, string name, Vector3 localPosition, Vector3 localScale, Material material)
        {
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = name;
            cube.transform.SetParent(parent, false);
            cube.transform.localPosition = localPosition;
            cube.transform.localRotation = Quaternion.identity;
            cube.transform.localScale = localScale;

            Collider c = cube.GetComponent<Collider>();
            if (c != null) Destroy(c);

            Renderer r = cube.GetComponent<Renderer>();
            if (r != null && material != null)
                r.sharedMaterial = material;
        }

        static Material CreateRuntimeMaterial(Color color)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            if (shader == null) return null;

            Material mat = new Material(shader);
            mat.color = color;
            return mat;
        }

        // =====================================================================
        //  DONDE VA LA CARGA: SE CALCULA DE LA GEOMETRIA, NO SE ADIVINA
        //
        //  PROBLEMA QUE RESUELVE. La carga se colocaba con un offset fijo
        //      carriedPalletLocalPosition = (0, -0.01, 0.88)
        //  es decir 0.88 m sobre el eje local +Z del objeto. Pero ESTE prefab esta
        //  construido mirando hacia +X -por eso modelYawOffset vale -90- asi que
        //  ese punto cae AL COSTADO del apilador, no delante, y a y = -0.01 queda
        //  practicamente a ras de suelo. Por eso la caja se veia flotando fuera de
        //  las horquillas.
        //
        //  Ademas CacheForkCarriage() busca un hijo llamado exactamente "Carro",
        //  que existe en el modelo de VehicleFactory pero NO en este prefab (aqui
        //  las horquillas se llaman Pala1 y Pala2 y cuelgan de la raiz). Al no
        //  encontrarlo, el padre de la carga acababa siendo la raiz, con lo que el
        //  offset equivocado se aplicaba tal cual.
        //
        //  SOLUCION. Se localizan las horquillas por nombre (Pala*, Horquilla*,
        //  fork*), se toma el volumen real que ocupan y se apoya la tarima justo
        //  encima de su cara superior, centrada entre ellas. La direccion de avance
        //  se deduce tambien de la geometria -del cuerpo hacia las horquillas- asi
        //  que no se asume ningun eje: funciona con este prefab, con el de
        //  VehicleFactory y con cualquier otro que se use manana.
        // =====================================================================
        void CalcularPosicionesDeCarga()
        {
            if (posicionesCargaListas)
                return;

            CacheForkCarriage();
            Transform padre = forkCarriage != null ? forkCarriage : transform;

            Bounds b = new Bounds();
            bool hay = false;

            Renderer[] rs = GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < rs.Length; i++)
            {
                if (rs[i] == null) continue;

                string n = rs[i].gameObject.name.ToLowerInvariant();
                if (!(n.StartsWith("pala") || n.StartsWith("horquilla") || n.StartsWith("fork")))
                    continue;

                if (!hay) { b = rs[i].bounds; hay = true; }
                else b.Encapsulate(rs[i].bounds);
            }

            if (!hay)
            {
                // Sin horquillas identificables se usan los valores del inspector.
                cargaLocal = carriedPalletLocalPosition;
                descargaLocal = unloadPalletLocalPosition;
                cargaRotacionLocal = Quaternion.identity;
                posicionesCargaListas = true;
                Debug.LogWarning("[CARGA] AGV " + agentId +
                                 ": no se encontraron horquillas (Pala*/Horquilla*). " +
                                 "Se usan los offsets del inspector.");
                return;
            }

            // Avance real del modelo: del cuerpo hacia las horquillas.
            Vector3 haciaHorquillas = b.center - transform.position;
            haciaHorquillas.y = 0f;
            if (haciaHorquillas.sqrMagnitude < 0.0001f)
                haciaHorquillas = transform.right;
            haciaHorquillas.Normalize();

            // El pivote de la carga es el centro de la base de la tarima, y la base
            // mide 0.10 de alto (ver CreateTransportLoad), asi que medio espesor
            // por encima de la cara superior de las horquillas la deja apoyada.
            Vector3 apoyoMundo = new Vector3(b.center.x, b.max.y + 0.05f, b.center.z);

            alturaApoyoRaiz = transform.InverseTransformPoint(apoyoMundo).y;
            cargaLocal = padre.InverseTransformPoint(apoyoMundo);
            descargaLocal = padre.InverseTransformPoint(apoyoMundo + haciaHorquillas * 0.55f);

            // La tarima es 0.70 x 0.84: su lado largo (Z propio) se alinea con las
            // horquillas en vez de quedar atravesado.
            Vector3 frenteLocal = padre.InverseTransformDirection(haciaHorquillas);
            frenteLocal.y = 0f;
            cargaRotacionLocal = frenteLocal.sqrMagnitude > 0.0001f
                ? Quaternion.LookRotation(frenteLocal.normalized, Vector3.up)
                : Quaternion.identity;

            posicionesCargaListas = true;

            Debug.Log("[CARGA] AGV " + agentId + " apoyo sobre horquillas = " +
                      cargaLocal.ToString("0.00") + " (padre: " + padre.name + ")");
        }

        Vector3 CargaLocal()
        {
            CalcularPosicionesDeCarga();
            return posicionesCargaListas ? cargaLocal : carriedPalletLocalPosition;
        }

        Vector3 DescargaLocal()
        {
            CalcularPosicionesDeCarga();
            return posicionesCargaListas ? descargaLocal : unloadPalletLocalPosition;
        }

        Quaternion CargaRotacionLocal()
        {
            CalcularPosicionesDeCarga();
            return posicionesCargaListas ? cargaRotacionLocal : Quaternion.identity;
        }

        void AttachPayload()
        {
            RemovePayload();

            CacheForkCarriage();
            Transform padreCarga = forkCarriage != null ? forkCarriage : transform;

            Vector3 worldPosition = padreCarga.TransformPoint(CargaLocal());
            payloadVisual = CreateTransportLoad(worldPosition, transform.rotation, mission != null ? mission.sourcePallet : null);
            payloadIsScenePallet = false;
            payloadVisual.name = mission != null ? "Pallet_Mision_" + mission.id : "Pallet_Mision";

            payloadVisual.transform.SetParent(padreCarga, false);
            payloadVisual.transform.localPosition = CargaLocal();
            payloadVisual.transform.localRotation = CargaRotacionLocal();
        }

        void RemovePayload()
        {
            if (payloadVisual == null)
            {
                payloadIsScenePallet = false;
                return;
            }

            // Las Tarimas reales pertenecen a la escena y el manager las restaura
            // a su rack al reiniciar baseline/propuesta. Nunca se destruyen aqui.
            if (payloadIsScenePallet)
            {
                payloadVisual = null;
                payloadIsScenePallet = false;
                return;
            }

            if (Application.isPlaying)
                Destroy(payloadVisual);
            else
                DestroyImmediate(payloadVisual);

            payloadVisual = null;
            payloadIsScenePallet = false;
        }

        void CreateLabel()
        {
            Transform old = transform.Find("AGV_Label");
            if (old != null)
            {
                label = old.GetComponent<TextMesh>();
                if (label != null)
                    return;
            }

            GameObject go = new GameObject("AGV_Label");
            go.transform.SetParent(transform, false);
            go.transform.localPosition = new Vector3(0f, 2.8f, 0f);

            label = go.AddComponent<TextMesh>();
            label.anchor = TextAnchor.MiddleCenter;
            label.alignment = TextAlignment.Center;
            label.characterSize = 0.11f;
            label.fontSize = 42;
        }

        void UpdateLabel()
        {
            if (label == null)
                return;

            string missionText = mission != null ? " M" + mission.id : "";
            string targetText = "";
            if (mission != null && state == StackerState.ToPickup) targetText = " -> " + mission.pickupName;
            if (mission != null && state == StackerState.ToDropoff) targetText = " -> " + mission.dropoffName;
            label.text = "AGV " + agentId + missionText + "\n" + state + targetText + "\n" + battery.ToString("0") + "%";

            Camera cam = Camera.main;
            if (cam != null)
            {
                Vector3 dir = label.transform.position - cam.transform.position;
                if (dir.sqrMagnitude > 0.001f)
                    label.transform.rotation = Quaternion.LookRotation(dir);
            }
        }

        void OnDrawGizmosSelected()
        {
            if (route == null || route.Count == 0)
                return;

            Vector3 p = transform.position;
            for (int i = routeIndex; i < route.Count; i++)
            {
                Gizmos.DrawLine(p, route[i]);
                p = route[i];
            }
        }
    }
}
