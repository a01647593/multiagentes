// ============================================================================
//  VEHICULO 02 - AGV DETALLADO (carro remolcador tipo plataforma)
// ----------------------------------------------------------------------------
//  Version mas detallada del AGV, inspirada en un carro remolcador industrial:
//  plataforma plana baja, borde con franjas de advertencia, consola de control
//  con botones y pantalla, rueda motriz con rin rojo visible, ruedas locas en
//  las esquinas y una antena/sensor trasero.
//
//  Como usarlo:
//   1) Copia este archivo a Assets/Editor/Vehiculo_AGV_Detallado.cs
//      (mismo requisito que el otro script: ProBuilder debe estar instalado -
//      Window > Package Manager > Unity Registry > ProBuilder > Install)
//   2) En el menu de Unity: Reto ProBuilder > AGV Detallado
//   3) Aparece un GameObject "Vehiculo_02_AGV_Detallado" en la escena
//
//  Es un script independiente: crea sus propios materiales (solo color, sin
//  texturas de imagen) bajo Assets/Materials/AGV_*.mat, asi que no depende del
//  generador grande. Si ya generaste la escena completa antes con el otro
//  script, puedes borrar el "Vehiculo_02_AGV" viejo y meter este en su lugar.
// ============================================================================

using UnityEditor;
using UnityEngine;
using UnityEngine.ProBuilder;

public static class AGVDetalladoGenerator
{
    const string MAT_DIR = "Assets/Materials";

    [MenuItem("Reto ProBuilder/AGV Detallado", priority = 30)]
    public static void GenerarAGVDetallado()
    {
        AsegurarCarpeta(MAT_DIR);

        var existente = GameObject.Find("Vehiculo_02_AGV_Detallado");
        if (existente != null) GameObject.DestroyImmediate(existente);

        var root = new GameObject("Vehiculo_02_AGV_Detallado").transform;

        var matBase = Mat("AGV_Base", new Color(0.86f, 0.87f, 0.85f), 0.35f);
        var matCubierta = Mat("AGV_Cubierta", new Color(0.06f, 0.06f, 0.07f), 0.25f);
        var matAmarillo = Mat("AGV_Franja_Amarilla", new Color(0.95f, 0.75f, 0.06f), 0.3f);
        var matNegro = Mat("AGV_Franja_Negra", new Color(0.05f, 0.05f, 0.05f), 0.2f);
        var matPanel = Mat("AGV_Panel", new Color(0.16f, 0.17f, 0.18f), 0.3f);
        var matPantalla = Mat("AGV_Pantalla", new Color(0.10f, 0.35f, 0.30f), 0.6f);
        var matBotonRojo = Mat("AGV_Boton_Rojo", new Color(0.75f, 0.08f, 0.06f), 0.45f);
        var matBotonAmarillo = Mat("AGV_Boton_Amarillo", new Color(0.85f, 0.65f, 0.05f), 0.45f);
        var matBotonVerde = Mat("AGV_Boton_Verde", new Color(0.10f, 0.55f, 0.20f), 0.45f);
        var matLlanta = Mat("AGV_Llanta", new Color(0.04f, 0.04f, 0.04f), 0.15f);
        var matRin = Mat("AGV_Rin", new Color(0.62f, 0.08f, 0.06f), 0.55f);
        var matAntena = Mat("AGV_Antena", new Color(0.20f, 0.21f, 0.22f), 0.4f, true);

        // -------- Cuerpo base --------
        Caja("Zocalo", new Vector3(0.75f, 0.22f, 1.90f), new Vector3(0, 0.11f, 0), matBase, root);
        Caja("Cubierta", new Vector3(0.70f, 0.04f, 1.85f), new Vector3(0, 0.24f, 0), matCubierta, root);

        // -------- Borde de advertencia (franjas amarillo/negro) --------
        FranjaBorde(root, 0.36f, 0.93f, 0.27f, 0.05f, 0.04f, 0.18f, matAmarillo, matNegro);

        // -------- Consola de control (extremo frontal, Z+) --------
        Caja("Consola", new Vector3(0.55f, 0.22f, 0.16f), new Vector3(0, 0.37f, 0.87f), matPanel, root);
        Caja("Pantalla", new Vector3(0.16f, 0.10f, 0.02f), new Vector3(-0.15f, 0.42f, 0.955f), matPantalla, root);
        Cilindro("Boton_Emergencia", 0.045f, 0.03f, new Vector3(0.10f, 0.42f, 0.955f), matBotonRojo, root, new Vector3(90, 0, 0));
        Cilindro("Boton_Amarillo", 0.03f, 0.03f, new Vector3(0.19f, 0.42f, 0.955f), matBotonAmarillo, root, new Vector3(90, 0, 0));
        Cilindro("Boton_Verde", 0.03f, 0.03f, new Vector3(0.19f, 0.35f, 0.955f), matBotonVerde, root, new Vector3(90, 0, 0));

        // -------- Placa de identificacion (lateral) --------
        Caja("Placa_ID", new Vector3(0.24f, 0.14f, 0.01f), new Vector3(-0.355f, 0.24f, 0.55f), matAmarillo, root, new Vector3(0, 90, 0));

        // -------- Antena / sensor trasero --------
        Cilindro("Antena", 0.015f, 0.35f, new Vector3(-0.28f, 0.42f, -0.82f), matAntena, root);

        // -------- Rueda motriz (grande, sobresale del chasis para que se vea) --------
        // El chasis mide 0.75 de ancho (mitad = 0.375). Centramos la llanta en X=0.44
        // para que sobresalga claramente del costado en vez de quedar escondida adentro.
        Cilindro("Llanta_Motriz", 0.17f, 0.12f, new Vector3(0.44f, 0.17f, 0.05f), matLlanta, root, new Vector3(0, 0, 90));
        Cilindro("Rin_Motriz", 0.08f, 0.14f, new Vector3(0.44f, 0.17f, 0.05f), matRin, root, new Vector3(0, 0, 90));

        // -------- Ruedas locas (esquinas, tambien sobresalen del chasis) --------
        RuedaLoca(root, matLlanta, matBase, new Vector3(-0.42f, 0.09f, 0.78f), 0.09f, 0.07f);
        RuedaLoca(root, matLlanta, matBase, new Vector3(0.42f, 0.09f, -0.75f), 0.09f, 0.07f);
        RuedaLoca(root, matLlanta, matBase, new Vector3(-0.42f, 0.09f, -0.75f), 0.09f, 0.07f);

        Selection.activeGameObject = root.gameObject;
        Debug.Log("[Reto ProBuilder] AGV detallado generado: Vehiculo_02_AGV_Detallado");
    }

    private static void RuedaLoca(Transform padre, Material llanta, Material soporte, Vector3 pos, float radio, float ancho)
    {
        Cilindro("Soporte_Rueda", radio * 0.4f, 0.08f, pos + new Vector3(0, radio * 0.9f, 0), soporte, padre);
        Cilindro("Rueda_Loca", radio, ancho, pos, llanta, padre, new Vector3(0, 0, 90));
    }

    // Genera un borde de franjas alternadas amarillo/negro alrededor de un
    // rectangulo de mitadX * mitadZ (medidas desde el centro), a la altura y.
    private static void FranjaBorde(Transform padre, float mitadX, float mitadZ, float y, float grosor, float alto, float segmento, Material amarillo, Material negro)
    {
        int nz = Mathf.CeilToInt((mitadZ * 2f) / segmento);
        for (int i = 0; i < nz; i++)
        {
            float z = -mitadZ + segmento * i + segmento / 2f;
            var mat = (i % 2 == 0) ? amarillo : negro;
            Caja($"Franja_Izq_{i}", new Vector3(grosor, alto, segmento * 0.9f), new Vector3(-mitadX, y, z), mat, padre);
            Caja($"Franja_Der_{i}", new Vector3(grosor, alto, segmento * 0.9f), new Vector3(mitadX, y, z), mat, padre);
        }

        int nx = Mathf.CeilToInt((mitadX * 2f) / segmento);
        for (int i = 0; i < nx; i++)
        {
            float x = -mitadX + segmento * i + segmento / 2f;
            var mat = (i % 2 == 0) ? negro : amarillo;
            Caja($"Franja_Frente_{i}", new Vector3(segmento * 0.9f, alto, grosor), new Vector3(x, y, mitadZ), mat, padre);
            Caja($"Franja_Atras_{i}", new Vector3(segmento * 0.9f, alto, grosor), new Vector3(x, y, -mitadZ), mat, padre);
        }
    }

    // ---------------------------------------------------------------- HELPERS

    private static void AsegurarCarpeta(string ruta)
    {
        if (AssetDatabase.IsValidFolder(ruta)) return;
        var partes = ruta.Split('/');
        string acc = partes[0];
        for (int i = 1; i < partes.Length; i++)
        {
            string siguiente = acc + "/" + partes[i];
            if (!AssetDatabase.IsValidFolder(siguiente))
                AssetDatabase.CreateFolder(acc, partes[i]);
            acc = siguiente;
        }
    }

    private static Shader ShaderPorDefecto()
    {
        if (UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null)
        {
            var urp = Shader.Find("Universal Render Pipeline/Lit");
            if (urp != null) return urp;
            var hdrp = Shader.Find("HDRP/Lit");
            if (hdrp != null) return hdrp;
        }
        var std = Shader.Find("Standard");
        return std != null ? std : Shader.Find("Diffuse");
    }

    private static Material Mat(string nombre, Color color, float suavidad = 0.4f, bool metalico = false)
    {
        string path = $"{MAT_DIR}/{nombre}.mat";
        var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(ShaderPorDefecto());
            AssetDatabase.CreateAsset(mat, path);
        }
        mat.color = color;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metalico ? 0.7f : 0.0f);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", suavidad);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", suavidad);
        EditorUtility.SetDirty(mat);
        return mat;
    }

    private static ProBuilderMesh Caja(string nombre, Vector3 tamano, Vector3 posLocal, Material mat, Transform padre, Vector3 rotEuler = default)
    {
        var pb = ShapeGenerator.GenerateCube(PivotLocation.Center, tamano);
        pb.gameObject.name = nombre;
        pb.transform.SetParent(padre, false);
        pb.transform.localPosition = posLocal;
        pb.transform.localRotation = Quaternion.Euler(rotEuler);
        if (mat != null) pb.GetComponent<MeshRenderer>().sharedMaterial = mat;
        return pb;
    }

    private static ProBuilderMesh Cilindro(string nombre, float radio, float altura, Vector3 posLocal, Material mat, Transform padre, Vector3 rotEuler = default, int divisiones = 14)
    {
        var pb = ShapeGenerator.GenerateCylinder(PivotLocation.Center, divisiones, radio, altura, 0);
        pb.gameObject.name = nombre;
        pb.transform.SetParent(padre, false);
        pb.transform.localPosition = posLocal;
        pb.transform.localRotation = Quaternion.Euler(rotEuler);
        if (mat != null) pb.GetComponent<MeshRenderer>().sharedMaterial = mat;
        return pb;
    }
}
