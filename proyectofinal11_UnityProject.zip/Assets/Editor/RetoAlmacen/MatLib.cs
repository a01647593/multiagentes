// -----------------------------------------------------------------------------
//  MatLib.cs  -  Biblioteca de materiales del reto  (v3)
// -----------------------------------------------------------------------------
//  Crea los .mat en Assets/Materials a partir de los PNG de Assets/Textures.
//
//  Cambios respecto a la version anterior:
//   1. Busca cada PNG en TODO el proyecto, no solo en Assets/Textures.
//   2. Fuerza Wrap Mode = Repeat y mipmaps en el importer.
//   3. Si una textura no aparece, el material toma un COLOR de respaldo correcto
//      (el rack sale azul aunque falte el PNG) en vez de quedarse blanco.
//   4. Escribe en consola, textura por textura, cual se aplico y cual no.
// -----------------------------------------------------------------------------
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace RetoAlmacen
{
    public static class MatLib
    {
        public const string TexDir = "Assets/Textures";
        public const string MatDir = "Assets/Materials";

        static Dictionary<string, Material> _cache;
        static readonly StringBuilder _reporte = new StringBuilder();
        static int _texOk, _texFail;

        // ---------------------------------------------------------------- shader
        static Shader Lit()
        {
            var s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("HDRP/Lit");
            if (s == null) s = Shader.Find("Standard");
            if (s == null) s = Shader.Find("Diffuse");
            return s;
        }

        static bool IsUrp { get { return Shader.Find("Universal Render Pipeline/Lit") != null; } }

        // -------------------------------------------------------------- texturas
        /// <summary>Busca el PNG por ruta directa y, si falla, por nombre en todo el proyecto.</summary>
        static Texture2D FindTexture(string fileName)
        {
            string path = TexDir + "/" + fileName;
            var t = AssetDatabase.LoadAssetAtPath<Texture2D>(path);

            if (t == null)
            {
                string bare = Path.GetFileNameWithoutExtension(fileName);
                foreach (var g in AssetDatabase.FindAssets(bare + " t:Texture2D"))
                {
                    var p = AssetDatabase.GUIDToAssetPath(g);
                    if (Path.GetFileName(p).Equals(fileName, System.StringComparison.OrdinalIgnoreCase))
                    {
                        t = AssetDatabase.LoadAssetAtPath<Texture2D>(p);
                        path = p;
                        break;
                    }
                }
            }

            if (t == null) return null;

            // El tiling de ProBuilder necesita Repeat; con Clamp la textura se estira.
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp != null && (imp.wrapMode != TextureWrapMode.Repeat || !imp.mipmapEnabled))
            {
                imp.wrapMode = TextureWrapMode.Repeat;
                imp.mipmapEnabled = true;
                imp.SaveAndReimport();
                t = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            }
            return t;
        }

        // ----------------------------------------------------------- propiedades
        static void SetTex(Material m, Texture2D t)
        {
            if (m.HasProperty("_BaseMap")) m.SetTexture("_BaseMap", t);
            if (m.HasProperty("_MainTex")) m.SetTexture("_MainTex", t);
        }

        static void SetColor(Material m, Color c)
        {
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
            if (m.HasProperty("_Color")) m.SetColor("_Color", c);
        }

        static void SetPbr(Material m, float metallic, float smoothness)
        {
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smoothness);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smoothness);
        }

        static void SetEmission(Material m, Color c, float intensity)
        {
            m.EnableKeyword("_EMISSION");
            if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", c * intensity);
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
        }

        // ------------------------------------------------------------------ build
        /// <param name="tint">
        /// Con textura presente se usa blanco (para no tenirla). Si NO hay textura,
        /// este color se aplica tal cual, para que la pieza nunca quede blanca.
        /// </param>
        static Material Make(string name, string texFile, Color tint,
                             float metallic, float smoothness, Color? emission = null)
        {
            EnsureFolder(MatDir);
            string path = MatDir + "/" + name + ".mat";

            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null)
            {
                m = new Material(Lit());
                m.name = name;
                AssetDatabase.CreateAsset(m, path);
            }
            else if (m.shader != Lit())
            {
                m.shader = Lit();
            }

            if (string.IsNullOrEmpty(texFile))
            {
                SetTex(m, null);
                SetColor(m, tint);
            }
            else
            {
                var t = FindTexture(texFile);
                SetTex(m, t);
                SetColor(m, t != null ? Color.white : tint);
                if (t != null)
                {
                    _texOk++;
                    _reporte.AppendLine("   OK     " + texFile + "  ->  " + name);
                }
                else
                {
                    _texFail++;
                    _reporte.AppendLine("   FALTA  " + texFile + "  ->  " + name + "  (se usa color solido)");
                }
            }

            SetPbr(m, metallic, smoothness);
            if (emission.HasValue) SetEmission(m, emission.Value, 3f);

            EditorUtility.SetDirty(m);
            return m;
        }

        // ---------------------------------------------------------------- publico
        public static Material Get(string key)
        {
            if (_cache == null) Build();
            Material m;
            return _cache.TryGetValue(key, out m) ? m : _cache["Gris"];
        }

        public static void Build()
        {
            // Si el paquete se acaba de importar, los PNG pueden no estar listos.
            AssetDatabase.Refresh();

            _cache = new Dictionary<string, Material>();
            _reporte.Length = 0;
            _texOk = 0; _texFail = 0;

            // ---- materiales con textura ------------------------------------------
            // El color del 3er parametro es el RESPALDO: solo se usa si el PNG no
            // aparece, para que la pieza conserve su color caracteristico.
            Add("Concreto",       Make("M_Concreto",       "01_concreto_piso.png",           new Color(0.55f, 0.55f, 0.56f), 0f,    0.15f));
            Add("PisoCarril",     Make("M_PisoCarril",     "02_piso_linea_carril.png",       new Color(0.42f, 0.44f, 0.46f), 0f,    0.35f));
            Add("Carton",         Make("M_Carton",         "03_carton_corrugado.png",        new Color(0.72f, 0.56f, 0.38f), 0f,    0.05f));
            Add("MaderaTarima",   Make("M_MaderaTarima",   "04_madera_tarima.png",           new Color(0.66f, 0.52f, 0.34f), 0f,    0.10f));
            Add("RackAzul",       Make("M_RackAzul",       "05_acero_rack_azul.png",         new Color(0.11f, 0.24f, 0.55f), 0.6f,  0.45f));
            Add("RackRojo",       Make("M_RackRojo",       "06_acero_rack_rojo.png",         new Color(0.62f, 0.14f, 0.12f), 0.6f,  0.45f));
            Add("Antiderrapante", Make("M_Antiderrapante", "07_placa_antiderrapante.png",    new Color(0.50f, 0.51f, 0.53f), 0.8f,  0.35f));
            Add("Peligro",        Make("M_Peligro",        "08_franjas_peligro.png",         new Color(0.85f, 0.68f, 0.08f), 0f,    0.30f));
            Add("PinturaEquipo",  Make("M_PinturaEquipo",  "09_pintura_amarilla_equipo.png", new Color(0.90f, 0.72f, 0.06f), 0.2f,  0.55f));
            Add("Llanta",         Make("M_Llanta",         "10_hule_llanta.png",             new Color(0.13f, 0.13f, 0.14f), 0f,    0.10f));
            Add("MetalCepillado", Make("M_MetalCepillado", "11_metal_cepillado.png",         new Color(0.66f, 0.68f, 0.71f), 0.9f,  0.60f));
            Add("Marcador",       Make("M_Marcador",       "12_marcador_piso_fiducial.png",  new Color(0.90f, 0.90f, 0.90f), 0f,    0.20f));
            Add("PlasticoAzul",   Make("M_PlasticoAzul",   "13_plastico_azul_caja.png",      new Color(0.13f, 0.31f, 0.66f), 0f,    0.45f));
            Add("MuroPanel",      Make("M_MuroPanel",      "14_panel_muro_industrial.png",   new Color(0.84f, 0.85f, 0.87f), 0f,    0.25f));
            Add("CortinaAnden",   Make("M_CortinaAnden",   "15_cortina_anden.png",           new Color(0.58f, 0.60f, 0.64f), 0.7f,  0.40f));
            Add("Galvanizado",    Make("M_Galvanizado",    "16_acero_galvanizado.png",       new Color(0.68f, 0.71f, 0.74f), 0.85f, 0.55f));

            // ---- colores planos de apoyo -----------------------------------------
            Add("NegroMate",  Make("M_NegroMate",  null, new Color(0.09f, 0.09f, 0.10f), 0.1f, 0.20f));
            Add("Gris",       Make("M_Gris",       null, new Color(0.45f, 0.46f, 0.48f), 0.3f, 0.35f));
            Add("GrisOscuro", Make("M_GrisOscuro", null, new Color(0.22f, 0.23f, 0.25f), 0.4f, 0.30f));
            Add("Naranja",    Make("M_Naranja",    null, new Color(0.95f, 0.42f, 0.06f), 0.0f, 0.50f));
            Add("Rojo",       Make("M_Rojo",       null, new Color(0.72f, 0.10f, 0.09f), 0.0f, 0.45f));
            Add("Verde",      Make("M_Verde",      null, new Color(0.10f, 0.55f, 0.25f), 0.0f, 0.45f));
            Add("Blanco",     Make("M_Blanco",     null, new Color(0.90f, 0.91f, 0.93f), 0.0f, 0.30f));
            Add("Cromo",      Make("M_Cromo",      null, new Color(0.78f, 0.80f, 0.83f), 1.0f, 0.85f));
            Add("Vidrio",     Make("M_Vidrio",     null, new Color(0.65f, 0.78f, 0.82f), 0.5f, 0.95f));
            Add("LuzLED",     Make("M_LuzLED",     null, Color.white, 0f, 0.9f, new Color(1f, 0.96f, 0.88f)));
            Add("LuzRoja",    Make("M_LuzRoja",    null, Color.white, 0f, 0.9f, new Color(1f, 0.15f, 0.10f)));

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            SceneView.RepaintAll();

            string pipe = IsUrp ? "URP" : "Built-in";
            string sh = Lit() != null ? Lit().name : "NINGUNO";
            string head = "[MatLib] " + _cache.Count + " materiales | texturas aplicadas " +
                          _texOk + "/16 | pipeline " + pipe + " | shader " + sh + "\n";

            if (_texFail == 0)
                Debug.Log(head + _reporte);
            else
                Debug.LogError(head + _reporte +
                    "\n-> Las marcadas FALTA no se encontraron. Revisa que esos PNG esten dentro de " +
                    "Assets/ y vuelve a pulsar 'Reconstruir materiales'.");
        }

        static void Add(string k, Material m) { _cache[k] = m; }

        /// <summary>Crea la carpeta en el AssetDatabase si no existe (rutas anidadas).</summary>
        public static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            var parts = path.Split('/');
            string acc = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = acc + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(acc, parts[i]);
                acc = next;
            }
        }

        // ------------------------------------------------------------ diagnostico
        [MenuItem("Reto Almacen/Diagnostico de texturas y materiales", false, 30)]
        public static void Diagnostico()
        {
            var pngs = AssetDatabase.FindAssets("t:Texture2D")
                .Select(AssetDatabase.GUIDToAssetPath)
                .Where(p => p.StartsWith("Assets/") &&
                            p.ToLower().EndsWith(".png"))
                .OrderBy(p => p).ToList();

            var sb = new StringBuilder();
            sb.AppendLine("===== DIAGNOSTICO RETO ALMACEN =====");
            sb.AppendLine("Pipeline : " + (IsUrp ? "URP" : "Built-in"));
            sb.AppendLine("Shader   : " + (Lit() != null ? Lit().name : "NINGUNO (problema grave)"));
            sb.AppendLine("PNG dentro de Assets: " + pngs.Count);
            foreach (var p in pngs.Take(25)) sb.AppendLine("   " + p);

            if (AssetDatabase.IsValidFolder(MatDir))
            {
                var mats = AssetDatabase.FindAssets("t:Material", new[] { MatDir })
                    .Select(AssetDatabase.GUIDToAssetPath).OrderBy(p => p).ToList();
                sb.AppendLine("Materiales en " + MatDir + ": " + mats.Count);
                foreach (var p in mats)
                {
                    var m = AssetDatabase.LoadAssetAtPath<Material>(p);
                    if (m == null) continue;
                    Texture tex = m.HasProperty("_BaseMap") ? m.GetTexture("_BaseMap") : null;
                    if (tex == null && m.HasProperty("_MainTex")) tex = m.GetTexture("_MainTex");
                    Color c = m.HasProperty("_BaseColor") ? m.GetColor("_BaseColor")
                            : (m.HasProperty("_Color") ? m.GetColor("_Color") : Color.magenta);
                    sb.AppendLine("   " + Path.GetFileNameWithoutExtension(p).PadRight(18) +
                                  " tex=" + (tex != null ? tex.name : "-- NINGUNA --").PadRight(32) +
                                  " color=" + c);
                }
            }
            else sb.AppendLine("NO EXISTE la carpeta " + MatDir);

            Debug.Log(sb.ToString());
        }

        /// <summary>Reconstruye materiales y obliga a los renderers a releerlos.</summary>
        [MenuItem("Reto Almacen/Forzar refresco visual de la escena", false, 31)]
        public static void ForzarRefresco()
        {
            Build();
            int n = 0;
            foreach (var r in Object.FindObjectsByType<MeshRenderer>(FindObjectsSortMode.None))
            {
                var mm = r.sharedMaterial;
                if (mm == null) continue;
                r.sharedMaterial = null;
                r.sharedMaterial = mm;
                n++;
            }
            SceneView.RepaintAll();
            Debug.Log("[MatLib] Refresco forzado sobre " + n + " renderers.");
        }
    }
}
