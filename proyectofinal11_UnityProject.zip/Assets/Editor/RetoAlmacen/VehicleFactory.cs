// -----------------------------------------------------------------------------
//  VehicleFactory.cs  -  Los 6 vehiculos del entregable (40% de la rubrica)
// -----------------------------------------------------------------------------
//  1. Montacargas contrabalanceado E80        (el del reto, escala real)
//  2. Robot montacargas con LiDAR             (el prototipo del video)
//  3. Transpaleta electrica (pallet jack)
//  4. Apilador / stacker
//  5. AGV plano tipo Kiva
//  6. Tractor de arrastre + carro de remolque
//
//  Convencion: el frente de todo vehiculo mira hacia +Z. Unidades = metros.
// -----------------------------------------------------------------------------
using UnityEngine;
using UnityEngine.ProBuilder;

namespace RetoAlmacen
{
    public static class VehicleFactory
    {
        // ---------------------------------------------------------------- helpers
        static Material M(string k) => MatLib.Get(k);

        /// <summary>Llanta = neumatico + rin. Eje sobre X (gira como rueda).</summary>
        static void Wheel(Transform parent, string name, Vector3 pos,
                          float radius, float width, string rimMat = "Cromo")
        {
            var t = PBGen.Group(name, parent, pos);
            PBGen.Cylinder(name + "_Neumatico", t, radius, width, Vector3.zero,
                           M("Llanta"), 20, new Vector3(0, 0, 90), 2f);
            PBGen.Cylinder(name + "_Rin", t, radius * 0.55f, width * 1.06f, Vector3.zero,
                           M(rimMat), 16, new Vector3(0, 0, 90));
        }

        /// <summary>Poste vertical delgado (jaula de proteccion, mastiles, barandales).</summary>
        static void Post(Transform parent, string name, Vector3 pos, float height,
                         float radius, string mat) =>
            PBGen.Cylinder(name, parent, radius, height, pos, M(mat), 10);

        // =====================================================================
        //  1. MONTACARGAS CONTRABALANCEADO E80
        // =====================================================================
        public static GameObject MontacargasE80(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V1_Montacargas_E80", parent, pos, new Vector3(0, yaw, 0));

            // --- chasis y carroceria -----------------------------------------
            PBGen.Cube("Chasis", root, new Vector3(0.95f, 0.45f, 1.70f),
                       new Vector3(0, 0.42f, 0.05f), M("PinturaEquipo"), default, 0.8f);
            PBGen.Cube("Capo_Motor", root, new Vector3(1.00f, 0.52f, 0.95f),
                       new Vector3(0, 0.90f, -0.62f), M("PinturaEquipo"), default, 0.8f);
            PBGen.Prism("Contrapeso", root, new Vector3(1.00f, 0.55f, 0.75f),
                        new Vector3(0, 0.92f, -1.28f), M("PinturaEquipo"),
                        new Vector3(0, 180f, 0), 0.8f);
            PBGen.Cube("Contrapeso_Base", root, new Vector3(0.86f, 0.50f, 0.75f),
                       new Vector3(0, 0.40f, -1.28f), M("PinturaEquipo"), default, 0.8f);
            PBGen.Cube("Estribo", root, new Vector3(1.18f, 0.05f, 0.55f),
                       new Vector3(0, 0.60f, 0.15f), M("Antiderrapante"), default, 3f);
            PBGen.Cube("Franja_Precaucion", root, new Vector3(1.02f, 0.14f, 0.78f),
                       new Vector3(0, 1.20f, -1.28f), M("Peligro"), default, 2f);

            // --- puesto del operador -----------------------------------------
            PBGen.Cube("Piso_Cabina", root, new Vector3(0.85f, 0.04f, 0.75f),
                       new Vector3(0, 0.67f, -0.05f), M("Antiderrapante"), default, 3f);
            PBGen.Cube("Asiento_Base", root, new Vector3(0.50f, 0.13f, 0.48f),
                       new Vector3(0, 0.84f, -0.30f), M("NegroMate"));
            PBGen.Cube("Asiento_Respaldo", root, new Vector3(0.50f, 0.60f, 0.12f),
                       new Vector3(0, 1.18f, -0.54f), M("NegroMate"), new Vector3(-10f, 0, 0));
            PBGen.Cylinder("Columna_Direccion", root, 0.045f, 0.55f,
                           new Vector3(0, 1.00f, 0.24f), M("GrisOscuro"), 10, new Vector3(-25f, 0, 0));
            PBGen.Cylinder("Volante", root, 0.19f, 0.045f,
                           new Vector3(0, 1.26f, 0.35f), M("NegroMate"), 20, new Vector3(65f, 0, 0));
            PBGen.Cube("Tablero", root, new Vector3(0.42f, 0.16f, 0.10f),
                       new Vector3(0, 1.10f, 0.12f), M("GrisOscuro"));
            PBGen.Cube("Palancas_Hidraulicas", root, new Vector3(0.05f, 0.30f, 0.05f),
                       new Vector3(0.34f, 1.05f, 0.05f), M("Naranja"));
            PBGen.Cube("Palancas_Hidraulicas_2", root, new Vector3(0.05f, 0.30f, 0.05f),
                       new Vector3(0.44f, 1.05f, 0.05f), M("Naranja"));

            // --- jaula de proteccion (overhead guard) -------------------------
            Post(root, "Poste_FI", new Vector3(-0.52f, 1.42f, 0.34f), 1.55f, 0.040f, "PinturaEquipo");
            Post(root, "Poste_FD", new Vector3(0.52f, 1.42f, 0.34f), 1.55f, 0.040f, "PinturaEquipo");
            Post(root, "Poste_TI", new Vector3(-0.52f, 1.55f, -0.86f), 1.30f, 0.040f, "PinturaEquipo");
            Post(root, "Poste_TD", new Vector3(0.52f, 1.55f, -0.86f), 1.30f, 0.040f, "PinturaEquipo");
            PBGen.Cube("Techo_Marco", root, new Vector3(1.16f, 0.07f, 1.55f),
                       new Vector3(0, 2.20f, -0.24f), M("PinturaEquipo"), default, 1.5f);
            for (int i = 0; i < 5; i++)  // rejilla del techo
                PBGen.Cube("Techo_Barra_" + i, root, new Vector3(1.02f, 0.035f, 0.10f),
                           new Vector3(0, 2.19f, -0.84f + i * 0.30f), M("GrisOscuro"));

            // --- mastil y horquillas ------------------------------------------
            var mast = PBGen.Group("Mastil", root, new Vector3(0, 0, 0.92f));
            PBGen.Cube("Riel_Ext_I", mast, new Vector3(0.10f, 2.30f, 0.14f),
                       new Vector3(-0.44f, 1.20f, 0), M("Galvanizado"), default, 1.5f);
            PBGen.Cube("Riel_Ext_D", mast, new Vector3(0.10f, 2.30f, 0.14f),
                       new Vector3(0.44f, 1.20f, 0), M("Galvanizado"), default, 1.5f);
            PBGen.Cube("Riel_Int_I", mast, new Vector3(0.07f, 2.10f, 0.09f),
                       new Vector3(-0.32f, 1.35f, 0.03f), M("MetalCepillado"), default, 1.5f);
            PBGen.Cube("Riel_Int_D", mast, new Vector3(0.07f, 2.10f, 0.09f),
                       new Vector3(0.32f, 1.35f, 0.03f), M("MetalCepillado"), default, 1.5f);
            PBGen.Cube("Traviesa_Sup", mast, new Vector3(1.00f, 0.10f, 0.12f),
                       new Vector3(0, 2.28f, 0), M("Galvanizado"));
            PBGen.Cube("Traviesa_Inf", mast, new Vector3(1.00f, 0.12f, 0.12f),
                       new Vector3(0, 0.18f, 0), M("Galvanizado"));
            PBGen.Cylinder("Cilindro_Elevacion", mast, 0.055f, 1.90f,
                           new Vector3(0, 1.10f, -0.10f), M("Cromo"), 12);
            PBGen.Cylinder("Cilindro_Inclinacion", root, 0.05f, 0.70f,
                           new Vector3(0.40f, 0.72f, 0.55f), M("Cromo"), 10, new Vector3(55f, 0, 0));
            PBGen.Cylinder("Cilindro_Inclinacion_2", root, 0.05f, 0.70f,
                           new Vector3(-0.40f, 0.72f, 0.55f), M("Cromo"), 10, new Vector3(55f, 0, 0));

            var carro = PBGen.Group("Carro_Horquillas", root, new Vector3(0, 0, 1.02f));
            PBGen.Cube("Placa_Carro", carro, new Vector3(0.98f, 0.55f, 0.06f),
                       new Vector3(0, 0.42f, 0), M("MetalCepillado"), default, 2f);
            PBGen.Cube("Respaldo_Carga", carro, new Vector3(0.94f, 0.85f, 0.05f),
                       new Vector3(0, 1.00f, -0.02f), M("Galvanizado"), default, 2f);
            for (int i = 0; i < 4; i++)
                PBGen.Cube("Respaldo_Barra_" + i, carro, new Vector3(0.90f, 0.05f, 0.08f),
                           new Vector3(0, 0.68f + i * 0.22f, 0.02f), M("Galvanizado"));
            // horquillas en L
            foreach (int s in new[] { -1, 1 })
            {
                float x = 0.30f * s;
                string sfx = s < 0 ? "I" : "D";
                PBGen.Cube("Horquilla_Vertical_" + sfx, carro, new Vector3(0.13f, 0.50f, 0.05f),
                           new Vector3(x, 0.32f, 0.05f), M("MetalCepillado"), default, 2f);
                PBGen.Cube("Horquilla_" + sfx, carro, new Vector3(0.13f, 0.05f, 1.20f),
                           new Vector3(x, 0.09f, 0.66f), M("MetalCepillado"), default, 2f);
                PBGen.Prism("Horquilla_Punta_" + sfx, carro, new Vector3(0.13f, 0.05f, 0.18f),
                            new Vector3(x, 0.09f, 1.34f), M("MetalCepillado"), new Vector3(-90f, 0, 0));
            }

            // --- llantas -------------------------------------------------------
            Wheel(root, "Llanta_Del_I", new Vector3(-0.57f, 0.33f, 0.60f), 0.33f, 0.24f);
            Wheel(root, "Llanta_Del_D", new Vector3(0.57f, 0.33f, 0.60f), 0.33f, 0.24f);
            Wheel(root, "Llanta_Tra_I", new Vector3(-0.44f, 0.25f, -1.05f), 0.25f, 0.20f);
            Wheel(root, "Llanta_Tra_D", new Vector3(0.44f, 0.25f, -1.05f), 0.25f, 0.20f);

            // --- luces / senalizacion -------------------------------------------
            PBGen.Cube("Faro_I", root, new Vector3(0.16f, 0.10f, 0.04f),
                       new Vector3(-0.38f, 1.05f, -1.66f), M("LuzLED"));
            PBGen.Cube("Faro_D", root, new Vector3(0.16f, 0.10f, 0.04f),
                       new Vector3(0.38f, 1.05f, -1.66f), M("LuzLED"));
            PBGen.Cylinder("Baliza", root, 0.07f, 0.11f,
                           new Vector3(0, 2.29f, -0.24f), M("LuzRoja"), 12);
            PBGen.Cube("Placa_Datos", root, new Vector3(0.30f, 0.18f, 0.02f),
                       new Vector3(0, 1.30f, -1.67f), M("Blanco"));

            return root.gameObject;
        }

        // =====================================================================
        //  2. ROBOT MONTACARGAS CON LiDAR  (prototipo del reto)
        // =====================================================================
        public static GameObject RobotLidar(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V2_Robot_Montacargas_LiDAR", parent, pos, new Vector3(0, yaw, 0));

            // --- plataforma ----------------------------------------------------
            PBGen.Cube("Chasis_Placa", root, new Vector3(0.34f, 0.025f, 0.44f),
                       new Vector3(0, 0.075f, -0.02f), M("Antiderrapante"), default, 6f);
            PBGen.Cube("Placa_Electronica", root, new Vector3(0.30f, 0.015f, 0.32f),
                       new Vector3(0, 0.145f, -0.05f), M("Galvanizado"), default, 6f);
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Separador_" + (s < 0 ? "I" : "D"), root, new Vector3(0.02f, 0.06f, 0.02f),
                           new Vector3(0.14f * s, 0.11f, -0.05f), M("Cromo"));

            // --- traccion ------------------------------------------------------
            foreach (int s in new[] { -1, 1 })
            {
                string sfx = s < 0 ? "I" : "D";
                var w = PBGen.Group("Rueda_" + sfx, root, new Vector3(0.185f * s, 0.075f, -0.02f));
                PBGen.Cylinder("Rueda_" + sfx + "_Hule", w, 0.075f, 0.028f, Vector3.zero,
                               M("Llanta"), 20, new Vector3(0, 0, 90), 6f);
                PBGen.Cylinder("Rueda_" + sfx + "_Rin", w, 0.055f, 0.032f, Vector3.zero,
                               M("Naranja"), 16, new Vector3(0, 0, 90));
                PBGen.Cube("Motor_" + sfx, root, new Vector3(0.06f, 0.05f, 0.05f),
                           new Vector3(0.13f * s, 0.075f, -0.02f), M("GrisOscuro"));
            }
            PBGen.Cylinder("Rueda_Loca", root, 0.032f, 0.020f,
                           new Vector3(0, 0.032f, -0.20f), M("NegroMate"), 14, new Vector3(0, 0, 90));
            PBGen.Cube("Soporte_Rueda_Loca", root, new Vector3(0.03f, 0.05f, 0.03f),
                       new Vector3(0, 0.075f, -0.20f), M("Cromo"));

            // --- LiDAR ----------------------------------------------------------
            PBGen.Cylinder("LiDAR_Base", root, 0.052f, 0.045f,
                           new Vector3(0, 0.175f, -0.04f), M("GrisOscuro"), 20);
            PBGen.Cylinder("LiDAR_Cabezal", root, 0.048f, 0.038f,
                           new Vector3(0, 0.216f, -0.04f), M("NegroMate"), 20);
            PBGen.Cylinder("LiDAR_Tapa", root, 0.050f, 0.008f,
                           new Vector3(0, 0.239f, -0.04f), M("GrisOscuro"), 20);

            // --- torre elevadora -------------------------------------------------
            var mast = PBGen.Group("Mastil_Mini", root, new Vector3(0, 0, 0.20f));
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Guia_" + (s < 0 ? "I" : "D"), mast, new Vector3(0.018f, 0.40f, 0.018f),
                           new Vector3(0.085f * s, 0.28f, 0), M("NegroMate"));
            PBGen.Cube("Mastil_Traviesa", mast, new Vector3(0.20f, 0.02f, 0.02f),
                       new Vector3(0, 0.475f, 0), M("NegroMate"));
            PBGen.Cube("Husillo", mast, new Vector3(0.012f, 0.40f, 0.012f),
                       new Vector3(0, 0.28f, -0.02f), M("Cromo"));
            PBGen.Cube("Carro_Mini", mast, new Vector3(0.20f, 0.03f, 0.025f),
                       new Vector3(0, 0.16f, 0.02f), M("GrisOscuro"));
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Horquilla_Mini_" + (s < 0 ? "I" : "D"), mast,
                           new Vector3(0.028f, 0.008f, 0.19f),
                           new Vector3(0.065f * s, 0.148f, 0.115f), M("MetalCepillado"), default, 6f);

            // --- electronica visible ---------------------------------------------
            PBGen.Cube("Bateria_LiPo", root, new Vector3(0.11f, 0.035f, 0.07f),
                       new Vector3(-0.06f, 0.172f, -0.16f), M("Rojo"));
            PBGen.Cube("Driver_Motores", root, new Vector3(0.07f, 0.022f, 0.05f),
                       new Vector3(0.09f, 0.166f, -0.14f), M("Verde"));
            PBGen.Cube("Microcontrolador", root, new Vector3(0.06f, 0.018f, 0.04f),
                       new Vector3(0.10f, 0.163f, 0.03f), M("PlasticoAzul"), default, 8f);
            PBGen.Cube("Camara", root, new Vector3(0.035f, 0.025f, 0.02f),
                       new Vector3(-0.10f, 0.165f, 0.06f), M("NegroMate"));
            PBGen.Cylinder("Antena", root, 0.004f, 0.20f,
                           new Vector3(-0.13f, 0.25f, -0.17f), M("NegroMate"), 6);
            // cableado simplificado
            PBGen.Cylinder("Cableado_1", root, 0.006f, 0.16f,
                           new Vector3(0.02f, 0.20f, -0.10f), M("Blanco"), 8, new Vector3(0, 0, 62f));
            PBGen.Cylinder("Cableado_2", root, 0.006f, 0.14f,
                           new Vector3(-0.05f, 0.19f, 0.02f), M("Blanco"), 8, new Vector3(48f, 20f, 0));
            PBGen.Cylinder("Cableado_3", root, 0.005f, 0.12f,
                           new Vector3(0.08f, 0.19f, -0.06f), M("NegroMate"), 8, new Vector3(0, 35f, 70f));
            PBGen.Cube("LED_Estado", root, new Vector3(0.02f, 0.008f, 0.008f),
                       new Vector3(0, 0.158f, 0.11f), M("LuzLED"));

            return root.gameObject;
        }

        // =====================================================================
        //  3. TRANSPALETA ELECTRICA
        // =====================================================================
        public static GameObject Transpaleta(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V3_Transpaleta_Electrica", parent, pos, new Vector3(0, yaw, 0));

            PBGen.Cube("Cuerpo", root, new Vector3(0.66f, 0.78f, 0.52f),
                       new Vector3(0, 0.45f, -0.62f), M("PinturaEquipo"), default, 1.2f);
            PBGen.Cube("Tapa_Bateria", root, new Vector3(0.60f, 0.10f, 0.46f),
                       new Vector3(0, 0.89f, -0.62f), M("GrisOscuro"));
            PBGen.Cube("Franja_Peligro", root, new Vector3(0.68f, 0.10f, 0.54f),
                       new Vector3(0, 0.12f, -0.62f), M("Peligro"), default, 2f);
            PBGen.Cube("Carcasa_Motor", root, new Vector3(0.34f, 0.26f, 0.30f),
                       new Vector3(0, 0.22f, -0.55f), M("NegroMate"));

            // timon
            PBGen.Cylinder("Timon", root, 0.045f, 0.85f,
                           new Vector3(0, 0.95f, -1.10f), M("GrisOscuro"), 10, new Vector3(32f, 0, 0));
            PBGen.Cube("Cabeza_Mando", root, new Vector3(0.38f, 0.14f, 0.20f),
                       new Vector3(0, 1.27f, -1.34f), M("NegroMate"), new Vector3(32f, 0, 0));
            foreach (int s in new[] { -1, 1 })
                PBGen.Cylinder("Mariposa_" + (s < 0 ? "I" : "D"), root, 0.035f, 0.10f,
                               new Vector3(0.17f * s, 1.29f, -1.32f), M("Naranja"), 12,
                               new Vector3(0, 0, 90));

            // horquillas
            PBGen.Cube("Puente", root, new Vector3(0.58f, 0.14f, 0.16f),
                       new Vector3(0, 0.13f, -0.32f), M("MetalCepillado"), default, 2f);
            foreach (int s in new[] { -1, 1 })
            {
                string sfx = s < 0 ? "I" : "D";
                PBGen.Cube("Horquilla_" + sfx, root, new Vector3(0.16f, 0.075f, 1.15f),
                           new Vector3(0.21f * s, 0.085f, 0.35f), M("MetalCepillado"), default, 2f);
                PBGen.Prism("Punta_" + sfx, root, new Vector3(0.16f, 0.075f, 0.16f),
                            new Vector3(0.21f * s, 0.085f, 0.99f), M("MetalCepillado"),
                            new Vector3(-90f, 0, 0));
                PBGen.Cylinder("Rodillo_" + sfx, root, 0.045f, 0.06f,
                               new Vector3(0.21f * s, 0.045f, 0.78f), M("NegroMate"), 12,
                               new Vector3(0, 0, 90));
            }
            Wheel(root, "Rueda_Motriz", new Vector3(0, 0.15f, -0.72f), 0.15f, 0.11f, "GrisOscuro");
            PBGen.Cylinder("Rueda_Estab_I", root, 0.055f, 0.05f,
                           new Vector3(-0.30f, 0.055f, -0.72f), M("NegroMate"), 12, new Vector3(0, 0, 90));
            PBGen.Cylinder("Rueda_Estab_D", root, 0.055f, 0.05f,
                           new Vector3(0.30f, 0.055f, -0.72f), M("NegroMate"), 12, new Vector3(0, 0, 90));

            return root.gameObject;
        }

        // =====================================================================
        //  4. APILADOR / STACKER
        // =====================================================================
        public static GameObject Apilador(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V4_Apilador_Stacker", parent, pos, new Vector3(0, yaw, 0));

            PBGen.Cube("Cuerpo", root, new Vector3(0.62f, 0.95f, 0.55f),
                       new Vector3(0, 0.52f, -0.62f), M("PinturaEquipo"), default, 1.2f);
            PBGen.Cube("Panel_Control", root, new Vector3(0.40f, 0.22f, 0.06f),
                       new Vector3(0, 1.04f, -0.88f), M("GrisOscuro"));
            PBGen.Cube("Franja_Peligro", root, new Vector3(0.64f, 0.12f, 0.57f),
                       new Vector3(0, 0.10f, -0.62f), M("Peligro"), default, 2f);

            // mastil de 2 etapas
            var mast = PBGen.Group("Mastil", root, new Vector3(0, 0, -0.28f));
            foreach (int s in new[] { -1, 1 })
            {
                PBGen.Cube("Riel_Ext_" + (s < 0 ? "I" : "D"), mast, new Vector3(0.09f, 2.10f, 0.13f),
                           new Vector3(0.24f * s, 1.08f, 0), M("Galvanizado"), default, 1.5f);
                PBGen.Cube("Riel_Int_" + (s < 0 ? "I" : "D"), mast, new Vector3(0.06f, 1.95f, 0.09f),
                           new Vector3(0.16f * s, 1.22f, 0.04f), M("MetalCepillado"), default, 1.5f);
            }
            PBGen.Cube("Traviesa", mast, new Vector3(0.58f, 0.09f, 0.12f),
                       new Vector3(0, 2.10f, 0), M("Galvanizado"));
            PBGen.Cylinder("Cilindro", mast, 0.045f, 1.80f,
                           new Vector3(0, 1.05f, -0.09f), M("Cromo"), 12);
            PBGen.Cube("Cadena", mast, new Vector3(0.03f, 1.90f, 0.02f),
                       new Vector3(0.09f, 1.10f, -0.05f), M("NegroMate"));

            // carro + horquillas
            var carro = PBGen.Group("Carro", root, new Vector3(0, 0.55f, -0.18f));
            PBGen.Cube("Placa_Carro", carro, new Vector3(0.58f, 0.30f, 0.05f),
                       Vector3.zero, M("MetalCepillado"), default, 2f);
            PBGen.Cube("Respaldo", carro, new Vector3(0.56f, 0.55f, 0.04f),
                       new Vector3(0, 0.40f, -0.02f), M("Galvanizado"), default, 2f);
            foreach (int s in new[] { -1, 1 })
            {
                string sfx = s < 0 ? "I" : "D";
                PBGen.Cube("Horquilla_" + sfx, carro, new Vector3(0.11f, 0.05f, 1.05f),
                           new Vector3(0.17f * s, -0.12f, 0.56f), M("MetalCepillado"), default, 2f);
                PBGen.Prism("Punta_" + sfx, carro, new Vector3(0.11f, 0.05f, 0.14f),
                            new Vector3(0.17f * s, -0.12f, 1.15f), M("MetalCepillado"),
                            new Vector3(-90f, 0, 0));
            }

            // patas straddle + ruedas
            foreach (int s in new[] { -1, 1 })
            {
                string sfx = s < 0 ? "I" : "D";
                PBGen.Cube("Pata_" + sfx, root, new Vector3(0.12f, 0.16f, 1.30f),
                           new Vector3(0.40f * s, 0.11f, 0.28f), M("PinturaEquipo"), default, 1.5f);
                PBGen.Cylinder("Rueda_Pata_" + sfx, root, 0.065f, 0.07f,
                               new Vector3(0.40f * s, 0.065f, 0.80f), M("NegroMate"), 12,
                               new Vector3(0, 0, 90));
            }
            Wheel(root, "Rueda_Motriz", new Vector3(0, 0.14f, -0.75f), 0.14f, 0.11f, "GrisOscuro");
            PBGen.Cylinder("Timon", root, 0.04f, 0.60f,
                           new Vector3(0, 1.16f, -1.02f), M("GrisOscuro"), 10, new Vector3(38f, 0, 0));
            PBGen.Cube("Cabeza_Mando", root, new Vector3(0.34f, 0.12f, 0.18f),
                       new Vector3(0, 1.40f, -1.20f), M("NegroMate"), new Vector3(38f, 0, 0));

            return root.gameObject;
        }

        // =====================================================================
        //  5. AGV PLANO TIPO KIVA
        // =====================================================================
        public static GameObject AgvKiva(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V5_AGV_Plano", parent, pos, new Vector3(0, yaw, 0));

            PBGen.Cube("Cuerpo", root, new Vector3(0.82f, 0.26f, 1.10f),
                       new Vector3(0, 0.19f, 0), M("Naranja"), default, 1.5f);
            PBGen.Cube("Faldon", root, new Vector3(0.86f, 0.06f, 1.14f),
                       new Vector3(0, 0.07f, 0), M("NegroMate"));
            PBGen.Cube("Cubierta", root, new Vector3(0.78f, 0.05f, 1.06f),
                       new Vector3(0, 0.34f, 0), M("GrisOscuro"), default, 2f);
            PBGen.Cylinder("Plato_Giratorio", root, 0.36f, 0.07f,
                           new Vector3(0, 0.40f, 0), M("Antiderrapante"), 28, default, 3f);
            PBGen.Plane("Marcador_Superior", root, 0.26f, 0.26f,
                        new Vector3(0, 0.437f, 0), M("Marcador"));

            // parachoques y luces
            foreach (int s in new[] { -1, 1 })
            {
                PBGen.Cube("Bumper_" + (s < 0 ? "Tra" : "Del"), root, new Vector3(0.84f, 0.11f, 0.05f),
                           new Vector3(0, 0.13f, 0.57f * s), M("NegroMate"));
                PBGen.Cube("Franja_LED_" + (s < 0 ? "Tra" : "Del"), root, new Vector3(0.60f, 0.03f, 0.02f),
                           new Vector3(0, 0.29f, 0.56f * s), M(s > 0 ? "LuzLED" : "LuzRoja"));
            }
            PBGen.Cube("Franja_Peligro", root, new Vector3(0.83f, 0.08f, 1.11f),
                       new Vector3(0, 0.30f, 0), M("Peligro"), default, 3f);

            // sensores
            PBGen.Cylinder("Escaner_Seguridad", root, 0.05f, 0.07f,
                           new Vector3(0, 0.20f, 0.56f), M("NegroMate"), 16, new Vector3(90f, 0, 0));
            PBGen.Cube("Camara_Piso", root, new Vector3(0.08f, 0.04f, 0.06f),
                       new Vector3(0, 0.05f, 0.36f), M("NegroMate"));

            // llantas
            foreach (int sx in new[] { -1, 1 })
                foreach (int sz in new[] { -1, 1 })
                    Wheel(root, $"Rueda_{(sz > 0 ? "D" : "T")}{(sx > 0 ? "D" : "I")}",
                          new Vector3(0.42f * sx, 0.10f, 0.34f * sz), 0.10f, 0.07f, "GrisOscuro");

            return root.gameObject;
        }

        // =====================================================================
        //  6. TRACTOR DE ARRASTRE + CARRO
        // =====================================================================
        public static GameObject TractorArrastre(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var root = PBGen.Group("V6_Tractor_Arrastre", parent, pos, new Vector3(0, yaw, 0));
            var trac = PBGen.Group("Tractor", root);

            PBGen.Cube("Chasis", trac, new Vector3(0.92f, 0.30f, 1.85f),
                       new Vector3(0, 0.40f, 0), M("PlasticoAzul"), default, 1.2f);
            PBGen.Cube("Capo", trac, new Vector3(0.88f, 0.42f, 0.66f),
                       new Vector3(0, 0.75f, 0.58f), M("PlasticoAzul"), default, 1.2f);
            PBGen.Cube("Parrilla", trac, new Vector3(0.70f, 0.22f, 0.04f),
                       new Vector3(0, 0.72f, 0.92f), M("GrisOscuro"), default, 4f);
            PBGen.Cube("Piso_Cabina", trac, new Vector3(0.80f, 0.04f, 0.60f),
                       new Vector3(0, 0.57f, -0.05f), M("Antiderrapante"), default, 3f);
            PBGen.Cube("Asiento_Base", trac, new Vector3(0.46f, 0.12f, 0.44f),
                       new Vector3(0, 0.76f, -0.42f), M("NegroMate"));
            PBGen.Cube("Asiento_Respaldo", trac, new Vector3(0.46f, 0.52f, 0.10f),
                       new Vector3(0, 1.06f, -0.63f), M("NegroMate"), new Vector3(-12f, 0, 0));
            PBGen.Cylinder("Columna", trac, 0.04f, 0.48f,
                           new Vector3(0, 0.90f, 0.16f), M("GrisOscuro"), 10, new Vector3(-22f, 0, 0));
            PBGen.Cylinder("Volante", trac, 0.17f, 0.04f,
                           new Vector3(0, 1.12f, 0.26f), M("NegroMate"), 20, new Vector3(68f, 0, 0));

            // roll bar
            foreach (int sx in new[] { -1, 1 })
                foreach (int sz in new[] { -1, 1 })
                    Post(trac, $"Poste_{(sz > 0 ? "D" : "T")}{(sx > 0 ? "D" : "I")}",
                         new Vector3(0.44f * sx, 1.30f, sz > 0 ? 0.20f : -0.72f), 1.45f, 0.035f, "PlasticoAzul");
            PBGen.Cube("Techo", trac, new Vector3(1.00f, 0.06f, 1.20f),
                       new Vector3(0, 2.04f, -0.26f), M("Blanco"), default, 1.5f);

            // ruedas y enganche
            Wheel(trac, "Rueda_Del_I", new Vector3(-0.48f, 0.24f, 0.62f), 0.24f, 0.16f);
            Wheel(trac, "Rueda_Del_D", new Vector3(0.48f, 0.24f, 0.62f), 0.24f, 0.16f);
            Wheel(trac, "Rueda_Tra_I", new Vector3(-0.50f, 0.28f, -0.62f), 0.28f, 0.20f);
            Wheel(trac, "Rueda_Tra_D", new Vector3(0.50f, 0.28f, -0.62f), 0.28f, 0.20f);
            PBGen.Cube("Enganche", trac, new Vector3(0.14f, 0.10f, 0.34f),
                       new Vector3(0, 0.34f, -1.02f), M("GrisOscuro"));
            PBGen.Cylinder("Perno_Enganche", trac, 0.035f, 0.16f,
                           new Vector3(0, 0.32f, -1.16f), M("Cromo"), 10);
            PBGen.Cube("Faro_I", trac, new Vector3(0.14f, 0.09f, 0.03f),
                       new Vector3(-0.30f, 0.86f, 0.92f), M("LuzLED"));
            PBGen.Cube("Faro_D", trac, new Vector3(0.14f, 0.09f, 0.03f),
                       new Vector3(0.30f, 0.86f, 0.92f), M("LuzLED"));
            PBGen.Cylinder("Baliza", trac, 0.06f, 0.10f,
                           new Vector3(0, 2.12f, -0.26f), M("LuzRoja"), 12);

            // ---------------- carro de remolque ---------------------------------
            var carro = PBGen.Group("Carro_Remolque", root, new Vector3(0, 0, -2.05f));
            PBGen.Cube("Plataforma", carro, new Vector3(1.05f, 0.07f, 1.55f),
                       new Vector3(0, 0.44f, 0), M("MaderaTarima"), default, 1.2f);
            PBGen.Cube("Bastidor", carro, new Vector3(1.00f, 0.12f, 1.50f),
                       new Vector3(0, 0.36f, 0), M("Galvanizado"), default, 1.5f);
            PBGen.Cube("Lanza", carro, new Vector3(0.10f, 0.08f, 0.70f),
                       new Vector3(0, 0.32f, 0.99f), M("Galvanizado"));
            PBGen.Cylinder("Argolla", carro, 0.05f, 0.05f,
                           new Vector3(0, 0.32f, 1.32f), M("Cromo"), 12);
            foreach (int sx in new[] { -1, 1 })
                foreach (int sz in new[] { -1, 1 })
                {
                    Post(carro, $"Barandal_{(sz > 0 ? "D" : "T")}{(sx > 0 ? "D" : "I")}",
                         new Vector3(0.48f * sx, 0.70f, 0.70f * sz), 0.46f, 0.025f, "Galvanizado");
                    PBGen.Cylinder($"Rueda_{(sz > 0 ? "D" : "T")}{(sx > 0 ? "D" : "I")}",
                                   carro, 0.12f, 0.08f,
                                   new Vector3(0.50f * sx, 0.12f, 0.55f * sz), M("NegroMate"), 14,
                                   new Vector3(0, 0, 90), 3f);
                }
            foreach (int sz in new[] { -1, 1 })
                PBGen.Cube("Barandal_Trav_" + (sz > 0 ? "D" : "T"), carro,
                           new Vector3(1.02f, 0.04f, 0.04f),
                           new Vector3(0, 0.92f, 0.70f * sz), M("Galvanizado"));

            return root.gameObject;
        }

        // =====================================================================
        //  Instancia los 6 en la escena
        // =====================================================================
        public static GameObject BuildAll(Transform parent)
        {
            var root = PBGen.Group("VEHICULOS", parent);

            // Colocados en pasillos y zona de maniobra (ver WarehouseFactory).
            MontacargasE80(root, new Vector3(-6.6f, 0, -8.6f), 0f);      // maniobrando frente al anden D1/D2
            RobotLidar(root, new Vector3(-1.0f, 0, -2.5f), 90f);         // pasillo entre filas 2 y 3
            Transpaleta(root, new Vector3(4.9f, 0, -8.0f), 180f);        // staging de embarque D3
            Apilador(root, new Vector3(9.9f, 0, -5.0f), 90f);            // pasillo oriente / D4
            AgvKiva(root, new Vector3(0.5f, 0, 2.5f), 0f);               // pasillo entre filas 1 y 2
            TractorArrastre(root, new Vector3(8.0f, 0, 0.5f), 180f);     // pasillo oriente

            return root.gameObject;
        }
    }
}
