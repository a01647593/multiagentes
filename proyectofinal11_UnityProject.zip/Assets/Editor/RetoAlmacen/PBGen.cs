// -----------------------------------------------------------------------------
//  PBGen.cs  -  Utilidades de construccion con la API de ProBuilder
//  Reto: Almacen automatizado (montacargas E80)  -  Unity 6 / ProBuilder 6.x
// -----------------------------------------------------------------------------
//  Todo lo que se genera en este proyecto sale de estos 4 primitivos de
//  ProBuilder: Cube, Cylinder, Prism y Plane. Nada de meshes importados.
// -----------------------------------------------------------------------------
using UnityEngine;
using UnityEngine.ProBuilder;

namespace RetoAlmacen
{
    public static class PBGen
    {
        /// <summary>Contenedor vacio (para agrupar piezas de un modelo).</summary>
        public static Transform Group(string name, Transform parent = null,
                                      Vector3 pos = default, Vector3 euler = default)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localEulerAngles = euler;
            return go.transform;
        }

        // ------------------------------------------------------------------ CUBO
        /// <param name="size">Ancho(X) x Alto(Y) x Largo(Z) en metros.</param>
        public static ProBuilderMesh Cube(string name, Transform parent, Vector3 size,
                                          Vector3 pos, Material mat,
                                          Vector3 euler = default, float uvScale = 1f)
        {
            var pb = ShapeGenerator.GenerateCube(PivotLocation.Center, size);
            return Finish(pb, name, parent, pos, euler, mat, uvScale);
        }

        // -------------------------------------------------------------- CILINDRO
        /// <summary>Cilindro sobre el eje Y. Usa 'euler' para acostarlo (ej. llantas: 0,0,90).</summary>
        public static ProBuilderMesh Cylinder(string name, Transform parent, float radius,
                                              float height, Vector3 pos, Material mat,
                                              int sides = 16, Vector3 euler = default,
                                              float uvScale = 1f)
        {
            var pb = ShapeGenerator.GenerateCylinder(PivotLocation.Center, sides, radius, height, 0, -1);
            return Finish(pb, name, parent, pos, euler, mat, uvScale);
        }

        // ----------------------------------------------------------------- PRISMA
        /// <summary>Prisma triangular (rampas de anden, contrapesos inclinados, cunas).</summary>
        public static ProBuilderMesh Prism(string name, Transform parent, Vector3 size,
                                           Vector3 pos, Material mat,
                                           Vector3 euler = default, float uvScale = 1f)
        {
            var pb = ShapeGenerator.GeneratePrism(PivotLocation.Center, size);
            return Finish(pb, name, parent, pos, euler, mat, uvScale);
        }

        // ------------------------------------------------------------------ PLANO
        /// <summary>Plano horizontal (piso, calcomanias de piso, marcadores).</summary>
        public static ProBuilderMesh Plane(string name, Transform parent, float width,
                                           float length, Vector3 pos, Material mat,
                                           int cuts = 0, Vector3 euler = default,
                                           float uvScale = 1f)
        {
            var pb = ShapeGenerator.GeneratePlane(PivotLocation.Center, width, length, cuts, cuts, Axis.Up);
            return Finish(pb, name, parent, pos, euler, mat, uvScale);
        }

        // ------------------------------------------------------------------ CONO
        public static ProBuilderMesh Cone(string name, Transform parent, float radius,
                                          float height, Vector3 pos, Material mat,
                                          int sides = 12, Vector3 euler = default,
                                          float uvScale = 1f)
        {
            var pb = ShapeGenerator.GenerateCone(PivotLocation.Center, radius, height, sides);
            return Finish(pb, name, parent, pos, euler, mat, uvScale);
        }

        // ------------------------------------------------------------ FINALIZADOR
        static ProBuilderMesh Finish(ProBuilderMesh pb, string name, Transform parent,
                                     Vector3 pos, Vector3 euler, Material mat, float uvScale)
        {
            pb.gameObject.name = name;
            pb.transform.SetParent(parent, false);
            pb.transform.localPosition = pos;
            pb.transform.localEulerAngles = euler;

            if (mat != null)
                pb.GetComponent<MeshRenderer>().sharedMaterial = mat;

            SetUvScale(pb, uvScale);
            pb.ToMesh();
            pb.Refresh();
            return pb;
        }

        /// <summary>
        /// Ajusta el "Auto UV" de todas las caras. scale = cuantas veces se repite la
        /// textura por metro. 1 = 1 repeticion por metro; 0.5 = textura del doble de grande.
        /// </summary>
        public static void SetUvScale(ProBuilderMesh pb, float scale)
        {
            if (Mathf.Approximately(scale, 1f)) return;
            foreach (var face in pb.faces)
            {
                var uv = face.uv;
                uv.scale = new Vector2(scale, scale);
                face.uv = uv;
            }
        }

        /// <summary>Escala UV distinta en U y V (util en muros y bandas largas).</summary>
        public static void SetUvScale(ProBuilderMesh pb, Vector2 scale)
        {
            foreach (var face in pb.faces)
            {
                var uv = face.uv;
                uv.scale = scale;
                face.uv = uv;
            }
            pb.ToMesh();
            pb.Refresh();
        }

        /// <summary>Agrega MeshCollider a todo lo que cuelgue de 'root' (obstaculos).</summary>
        public static void AddColliders(Transform root)
        {
            foreach (var mf in root.GetComponentsInChildren<MeshFilter>())
                if (mf.GetComponent<Collider>() == null && mf.sharedMesh != null)
                    mf.gameObject.AddComponent<MeshCollider>();
        }

        /// <summary>Marca toda la rama como Static (para lightmapping / occlusion).</summary>
        public static void MarkStatic(Transform root)
        {
#if UNITY_EDITOR
            var flags = UnityEditor.StaticEditorFlags.ContributeGI
                      | UnityEditor.StaticEditorFlags.OccluderStatic
                      | UnityEditor.StaticEditorFlags.OccludeeStatic
                      | UnityEditor.StaticEditorFlags.BatchingStatic
                      | UnityEditor.StaticEditorFlags.ReflectionProbeStatic;
            foreach (var t in root.GetComponentsInChildren<Transform>())
                UnityEditor.GameObjectUtility.SetStaticEditorFlags(t.gameObject, flags);
#endif
        }
    }
}
