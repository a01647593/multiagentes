// -----------------------------------------------------------------------------
//  WarehouseFactory.cs  -  Entorno 3D del almacen (40% de la rubrica)
// -----------------------------------------------------------------------------
//  Reproduce la maqueta del reto a escala real (metros):
//    - Nave de 26 x 24 m, muros de 5 m.
//    - Muro SUR : 4 andenes de embarque D1..D4 con rampas niveladoras.
//    - Muro NORTE: INBOUND AREA con 4 carriles L1..L4 y bandas de rodillos.
//    - 3 filas dobles de rack selectivo con tarimas y cajas.
//    - Obstaculos: columnas, mobiliario de oficina, barandales, conos,
//      estacion de carga, pilas de tarimas, contenedores, extintores.
//    - Marcadores fiduciales en piso para la localizacion del robot.
// -----------------------------------------------------------------------------
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.ProBuilder;

namespace RetoAlmacen
{
    public static class WarehouseFactory
    {
        // ------------------------------------------------------------ dimensiones
        public const float W = 26f;    // ancho  (X)
        public const float D = 24f;    // fondo  (Z)
        public const float H = 5.0f;   // altura de muro
        const float T = 0.25f;         // espesor de muro

        static float X0 { get { return -W / 2f; } }
        static float X1 { get { return  W / 2f; } }
        static float Z0 { get { return -D / 2f; } }
        static float Z1 { get { return  D / 2f; } }

        static Material M(string k) => MatLib.Get(k);

        // =====================================================================
        //  PIEZAS REUTILIZABLES
        // =====================================================================

        /// <summary>Muro paralelo al eje X con huecos (puertas / andenes).</summary>
        static void WallX(string name, Transform parent, float z, float height,
                          Material mat, List<Vector2> openings, float openingHeight = 4.0f)
        {
            var g = PBGen.Group(name, parent);
            var cuts = new List<Vector2>(openings);
            cuts.Sort((a, b) => a.x.CompareTo(b.x));

            float cursor = X0;
            int i = 0;
            foreach (var o in cuts)
            {
                float left = o.x - o.y / 2f, right = o.x + o.y / 2f;
                if (left > cursor)
                {
                    float w = left - cursor;
                    PBGen.Cube($"{name}_Seg{i++}", g, new Vector3(w, height, T),
                               new Vector3(cursor + w / 2f, height / 2f, z), mat, default, 0.4f);
                }
                // dintel sobre el hueco
                float lh = height - openingHeight;
                if (lh > 0.01f)
                    PBGen.Cube($"{name}_Dintel{i}", g, new Vector3(o.y, lh, T),
                               new Vector3(o.x, openingHeight + lh / 2f, z), mat, default, 0.4f);
                cursor = right;
            }
            if (cursor < X1)
                PBGen.Cube($"{name}_Seg{i}", g, new Vector3(X1 - cursor, height, T),
                           new Vector3(cursor + (X1 - cursor) / 2f, height / 2f, z), mat, default, 0.4f);
        }

        /// <summary>Muro paralelo al eje Z (sin huecos).</summary>
        static void WallZ(string name, Transform parent, float x, float height, Material mat)
        {
            PBGen.Cube(name, parent, new Vector3(T, height, D),
                       new Vector3(x, height / 2f, 0), mat, default, 0.4f);
        }

        /// <summary>Tarima de madera estandar 1.20 x 1.00 m.</summary>
        public static Transform Pallet(Transform parent, Vector3 pos, float yaw = 0f,
                                       bool plastico = false)
        {
            var mat = plastico ? M("PlasticoAzul") : M("MaderaTarima");
            var t = PBGen.Group("Tarima", parent, pos, new Vector3(0, yaw, 0));
            for (int i = 0; i < 3; i++)   // patines
                PBGen.Cube("Patin_" + i, t, new Vector3(1.20f, 0.075f, 0.10f),
                           new Vector3(0, 0.037f, -0.45f + i * 0.45f), mat, default, 2f);
            for (int i = 0; i < 3; i++)   // tacos
                PBGen.Cube("Taco_" + i, t, new Vector3(0.10f, 0.055f, 1.00f),
                           new Vector3(-0.55f + i * 0.55f, 0.10f, 0), mat, default, 2f);
            for (int i = 0; i < 5; i++)   // duelas superiores
                PBGen.Cube("Duela_" + i, t, new Vector3(1.20f, 0.022f, 0.14f),
                           new Vector3(0, 0.139f, -0.43f + i * 0.215f), mat, default, 2f);
            return t;
        }

        /// <summary>Estiba de cajas de carton sobre una tarima.</summary>
        public static void BoxStack(Transform parent, Vector3 pos, int niveles = 3,
                                    float yaw = 0f, bool negras = false)
        {
            var t = PBGen.Group("Estiba", parent, pos, new Vector3(0, yaw, 0));
            var mat = negras ? M("NegroMate") : M("Carton");
            float y = 0.15f;
            for (int n = 0; n < niveles; n++)
            {
                float h = 0.28f;
                for (int cx = 0; cx < 2; cx++)
                    for (int cz = 0; cz < 2; cz++)
                        PBGen.Cube($"Caja_{n}_{cx}{cz}", t, new Vector3(0.56f, h, 0.46f),
                                   new Vector3(-0.29f + cx * 0.58f, y + h / 2f, -0.24f + cz * 0.48f),
                                   mat, new Vector3(0, (n % 2) * 0f, 0), 1.6f);
                y += h + 0.005f;
            }
        }

        /// <summary>Marco de rack selectivo: 'bahias' bahias x 'niveles' niveles de viga.</summary>
        public static Transform RackRow(Transform parent, string name, Vector3 pos, float yaw,
                                        int bahias = 4, int niveles = 2,
                                        float anchoBahia = 2.70f, float fondo = 1.10f,
                                        float altura = 4.20f)
        {
            var t = PBGen.Group(name, parent, pos, new Vector3(0, yaw, 0));
            float largo = bahias * anchoBahia;
            float x0 = -largo / 2f;

            // --- marcos verticales (azules) --------------------------------------
            for (int b = 0; b <= bahias; b++)
            {
                float x = x0 + b * anchoBahia;
                var marco = PBGen.Group("Marco_" + b, t, new Vector3(x, 0, 0));
                foreach (int s in new[] { -1, 1 })
                    PBGen.Cube("Puntal_" + (s < 0 ? "A" : "B"), marco,
                               new Vector3(0.09f, altura, 0.09f),
                               new Vector3(0, altura / 2f, fondo / 2f * s), M("RackAzul"), default, 1.5f);
                // diagonales de celosia
                for (int d = 0; d < 5; d++)
                    PBGen.Cube("Diagonal_" + d, marco, new Vector3(0.05f, 0.05f, fondo * 1.18f),
                               new Vector3(0, 0.45f + d * 0.85f, 0), M("RackAzul"),
                               new Vector3((d % 2 == 0 ? 32f : -32f), 0, 0), 2f);
                PBGen.Cube("Placa_Base", marco, new Vector3(0.16f, 0.03f, 0.16f),
                           new Vector3(0, 0.015f, fondo / 2f), M("Galvanizado"));
                PBGen.Cube("Placa_Base2", marco, new Vector3(0.16f, 0.03f, 0.16f),
                           new Vector3(0, 0.015f, -fondo / 2f), M("Galvanizado"));
            }

            // --- vigas (naranjas/rojas) + carga -----------------------------------
            for (int n = 0; n < niveles; n++)
            {
                float y = 1.05f + n * 1.55f;
                for (int b = 0; b < bahias; b++)
                {
                    float cx = x0 + b * anchoBahia + anchoBahia / 2f;
                    foreach (int s in new[] { -1, 1 })
                        PBGen.Cube($"Viga_{n}_{b}_{(s < 0 ? "A" : "B")}", t,
                                   new Vector3(anchoBahia - 0.09f, 0.13f, 0.06f),
                                   new Vector3(cx, y, fondo / 2f * s), M("RackRojo"), default, 1.5f);
                    // largueros de apoyo
                    for (int l = 0; l < 2; l++)
                        PBGen.Cube($"Larguero_{n}_{b}_{l}", t,
                                   new Vector3(anchoBahia - 0.20f, 0.04f, 0.05f),
                                   new Vector3(cx, y + 0.06f, -0.35f + l * 0.70f), M("Galvanizado"));
                }
            }
            return t;
        }

        /// <summary>Rellena un rack con tarimas y estibas (patron alternado).</summary>
        static void FillRack(Transform rack, int bahias, int niveles,
                             float anchoBahia, float fondo, int seed)
        {
            var rnd = new System.Random(seed);
            float x0 = -bahias * anchoBahia / 2f;
            for (int n = 0; n < niveles; n++)
            {
                float y = 1.05f + n * 1.55f + 0.09f;
                for (int b = 0; b < bahias; b++)
                {
                    float cx = x0 + b * anchoBahia + anchoBahia / 2f;
                    for (int p = 0; p < 2; p++)          // 2 tarimas por bahia
                    {
                        if (rnd.NextDouble() < 0.18) continue;   // hueco de inventario
                        float px = cx + (p == 0 ? -0.66f : 0.66f);
                        Pallet(rack, new Vector3(px, y, 0), 0, rnd.NextDouble() < 0.25);
                        BoxStack(rack, new Vector3(px, y, 0), rnd.Next(2, 4), 0,
                                 rnd.NextDouble() < 0.3);
                    }
                }
            }
            // nivel de piso
            for (int b = 0; b < bahias; b++)
            {
                float cx = x0 + b * anchoBahia + anchoBahia / 2f;
                if (rnd.NextDouble() < 0.25) continue;
                Pallet(rack, new Vector3(cx - 0.66f, 0, 0));
                BoxStack(rack, new Vector3(cx - 0.66f, 0, 0), rnd.Next(2, 4));
            }
        }

        /// <summary>Banda transportadora de rodillos (como las negras de la maqueta).</summary>
        public static Transform Conveyor(Transform parent, string name, Vector3 pos,
                                         float largo, float yaw = 0f, float alto = 0.55f,
                                         float ancho = 0.80f, bool azul = false)
        {
            var t = PBGen.Group(name, parent, pos, new Vector3(0, yaw, 0));
            var estr = azul ? M("PlasticoAzul") : M("NegroMate");

            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Riel_" + (s < 0 ? "I" : "D"), t, new Vector3(0.07f, 0.16f, largo),
                           new Vector3(ancho / 2f * s, alto, 0), estr, default, 1.5f);

            int patas = Mathf.Max(2, Mathf.RoundToInt(largo / 1.2f) + 1);
            for (int i = 0; i < patas; i++)
            {
                float z = -largo / 2f + i * (largo / (patas - 1));
                foreach (int s in new[] { -1, 1 })
                    PBGen.Cube($"Pata_{i}_{(s < 0 ? "I" : "D")}", t,
                               new Vector3(0.05f, alto - 0.08f, 0.05f),
                               new Vector3(ancho / 2f * s, (alto - 0.08f) / 2f, z), M("Galvanizado"));
                PBGen.Cube($"Travesano_{i}", t, new Vector3(ancho, 0.04f, 0.04f),
                           new Vector3(0, 0.12f, z), M("Galvanizado"));
            }

            int rodillos = Mathf.Min(60, Mathf.RoundToInt(largo / 0.16f));
            for (int i = 0; i < rodillos; i++)
            {
                float z = -largo / 2f + 0.08f + i * (largo - 0.16f) / Mathf.Max(1, rodillos - 1);
                PBGen.Cylinder("Rodillo_" + i, t, 0.045f, ancho - 0.08f,
                               new Vector3(0, alto + 0.045f, z), M("Cromo"), 10,
                               new Vector3(0, 0, 90));
            }
            return t;
        }

        /// <summary>Anden de embarque: hueco, cortina, rampa niveladora, defensas y letrero.</summary>
        static void DockDoor(Transform parent, string label, float x, float z, bool sur)
        {
            float dir = sur ? 1f : -1f;   // hacia adentro de la nave
            var t = PBGen.Group("Anden_" + label, parent, new Vector3(x, 0, z));

            PBGen.Cube("Cortina", t, new Vector3(3.0f, 3.9f, 0.08f),
                       new Vector3(0, 1.95f, 0.02f * -dir), M("CortinaAnden"), default, 0.6f);
            PBGen.Cube("Marco_Sup", t, new Vector3(3.3f, 0.20f, 0.30f),
                       new Vector3(0, 4.05f, 0.12f * dir), M("Galvanizado"), default, 2f);
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Marco_" + (s < 0 ? "I" : "D"), t, new Vector3(0.16f, 4.05f, 0.30f),
                           new Vector3(1.58f * s, 2.02f, 0.12f * dir), M("Galvanizado"), default, 2f);

            // rampa niveladora + placa antiderrapante
            PBGen.Cube("Nivelador", t, new Vector3(2.20f, 0.10f, 2.00f),
                       new Vector3(0, 0.06f, 1.15f * dir), M("Antiderrapante"), default, 2f);
            PBGen.Prism("Transicion", t, new Vector3(2.20f, 0.10f, 0.45f),
                        new Vector3(0, 0.06f, 2.38f * dir), M("Antiderrapante"),
                        new Vector3(-90f * dir, 0, 0), 2f);

            // defensas de hule
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Defensa_" + (s < 0 ? "I" : "D"), t, new Vector3(0.25f, 0.45f, 0.20f),
                           new Vector3(1.42f * s, 0.55f, 0.10f * dir), M("Llanta"), default, 3f);

            // franjas de aproximacion en piso
            PBGen.Plane("Franja_Aprox", t, 3.0f, 0.55f,
                        new Vector3(0, 0.012f, 2.9f * dir), M("Peligro"), 0, default, 2f);

            // letrero D1 / L1
            PBGen.Cube("Letrero", t, new Vector3(0.70f, 0.34f, 0.05f),
                       new Vector3(0, 4.45f, 0.05f * dir), M("Blanco"));
            PBGen.Cube("Semaforo", t, new Vector3(0.18f, 0.45f, 0.14f),
                       new Vector3(1.85f, 2.60f, 0.10f * dir), M("GrisOscuro"));
            PBGen.Cube("Semaforo_Luz", t, new Vector3(0.12f, 0.12f, 0.04f),
                       new Vector3(1.85f, 2.72f, 0.18f * dir), M("LuzRoja"));
        }

        // ---------------------------------------------------------- mobiliario
        static void Mesa(Transform parent, Vector3 pos, float yaw = 0f,
                         float w = 1.40f, float d = 0.70f)
        {
            var t = PBGen.Group("Mesa", parent, pos, new Vector3(0, yaw, 0));
            PBGen.Cube("Cubierta", t, new Vector3(w, 0.04f, d), new Vector3(0, 0.74f, 0),
                       M("Blanco"), default, 1.5f);
            foreach (int sx in new[] { -1, 1 })
                foreach (int sz in new[] { -1, 1 })
                    PBGen.Cube("Pata", t, new Vector3(0.05f, 0.72f, 0.05f),
                               new Vector3((w / 2f - 0.08f) * sx, 0.36f, (d / 2f - 0.08f) * sz),
                               M("Cromo"));
        }

        static void Silla(Transform parent, Vector3 pos, float yaw = 0f, string mat = "Naranja")
        {
            var t = PBGen.Group("Silla", parent, pos, new Vector3(0, yaw, 0));
            PBGen.Cube("Asiento", t, new Vector3(0.44f, 0.05f, 0.44f), new Vector3(0, 0.45f, 0), M(mat));
            PBGen.Cube("Respaldo", t, new Vector3(0.44f, 0.42f, 0.05f),
                       new Vector3(0, 0.68f, -0.20f), M(mat), new Vector3(-8f, 0, 0));
            foreach (int sx in new[] { -1, 1 })
                foreach (int sz in new[] { -1, 1 })
                    PBGen.Cube("Pata", t, new Vector3(0.03f, 0.44f, 0.03f),
                               new Vector3(0.18f * sx, 0.22f, 0.18f * sz), M("Cromo"));
        }

        static void Gabinete(Transform parent, Vector3 pos, float yaw = 0f)
        {
            var t = PBGen.Group("Gabinete", parent, pos, new Vector3(0, yaw, 0));
            PBGen.Cube("Cuerpo", t, new Vector3(0.95f, 1.85f, 0.48f), new Vector3(0, 0.93f, 0),
                       M("Gris"), default, 1.2f);
            for (int i = 0; i < 2; i++)
                PBGen.Cube("Puerta_" + i, t, new Vector3(0.45f, 1.78f, 0.03f),
                           new Vector3(-0.235f + i * 0.47f, 0.93f, 0.25f), M("MetalCepillado"), default, 1.5f);
            PBGen.Cube("Manija", t, new Vector3(0.04f, 0.22f, 0.04f),
                       new Vector3(0.02f, 1.10f, 0.28f), M("Cromo"));
        }

        static void ConoSeguridad(Transform parent, Vector3 pos)
        {
            var t = PBGen.Group("Cono", parent, pos);
            PBGen.Cube("Base", t, new Vector3(0.34f, 0.04f, 0.34f), new Vector3(0, 0.02f, 0), M("Naranja"));
            PBGen.Cone("Cuerpo", t, 0.14f, 0.52f, new Vector3(0, 0.28f, 0), M("Naranja"), 12);
            PBGen.Cylinder("Reflejante", t, 0.105f, 0.07f, new Vector3(0, 0.34f, 0), M("Blanco"), 12);
        }

        static void Extintor(Transform parent, Vector3 pos, float yaw)
        {
            var t = PBGen.Group("Extintor", parent, pos, new Vector3(0, yaw, 0));
            PBGen.Cylinder("Tanque", t, 0.09f, 0.50f, new Vector3(0, 0.25f, 0), M("Rojo"), 14);
            PBGen.Cylinder("Valvula", t, 0.035f, 0.12f, new Vector3(0, 0.55f, 0), M("Cromo"), 10);
            PBGen.Cube("Soporte", t, new Vector3(0.16f, 0.30f, 0.05f), new Vector3(0, 0.30f, -0.11f), M("Rojo"));
        }

        static void Barandal(Transform parent, string name, Vector3 pos, float largo, float yaw)
        {
            var t = PBGen.Group(name, parent, pos, new Vector3(0, yaw, 0));
            int postes = Mathf.Max(2, Mathf.RoundToInt(largo / 1.5f) + 1);
            for (int i = 0; i < postes; i++)
            {
                float z = -largo / 2f + i * (largo / (postes - 1));
                PBGen.Cube("Poste_" + i, t, new Vector3(0.08f, 1.10f, 0.08f),
                           new Vector3(0, 0.55f, z), M("Peligro"), default, 2f);
                PBGen.Cube("Base_" + i, t, new Vector3(0.20f, 0.02f, 0.20f),
                           new Vector3(0, 0.01f, z), M("Galvanizado"));
            }
            for (int r = 0; r < 2; r++)
                PBGen.Cube("Riel_" + r, t, new Vector3(0.06f, 0.10f, largo),
                           new Vector3(0, 0.50f + r * 0.52f, 0), M("Peligro"), default, 2f);
        }

        static void EstacionCarga(Transform parent, Vector3 pos, float yaw)
        {
            var t = PBGen.Group("Estacion_Carga", parent, pos, new Vector3(0, yaw, 0));
            PBGen.Cube("Piso", t, new Vector3(3.20f, 0.02f, 2.20f), new Vector3(0, 0.012f, 0),
                       M("Peligro"), default, 1.5f);
            for (int i = 0; i < 3; i++)
            {
                PBGen.Cube("Cargador_" + i, t, new Vector3(0.55f, 1.10f, 0.40f),
                           new Vector3(-1.0f + i * 1.0f, 0.60f, -0.85f), M("Gris"), default, 1.5f);
                PBGen.Cube("Panel_" + i, t, new Vector3(0.36f, 0.24f, 0.03f),
                           new Vector3(-1.0f + i * 1.0f, 0.95f, -0.64f), M("LuzLED"));
                PBGen.Cylinder("Cable_" + i, t, 0.02f, 0.75f,
                               new Vector3(-0.75f + i * 1.0f, 0.35f, -0.62f), M("NegroMate"), 8,
                               new Vector3(20f, 0, 55f));
            }
        }

        static void LamparaIndustrial(Transform parent, Vector3 pos, float intensidad = 300f)
        {
            var t = PBGen.Group("Lampara", parent, pos);
            PBGen.Cylinder("Tubo", t, 0.02f, 0.60f, new Vector3(0, 0.30f, 0), M("Galvanizado"), 6);
            PBGen.Cube("Carcasa", t, new Vector3(1.20f, 0.10f, 0.30f), new Vector3(0, -0.05f, 0),
                       M("MetalCepillado"), default, 2f);
            PBGen.Cube("Difusor", t, new Vector3(1.10f, 0.03f, 0.24f), new Vector3(0, -0.11f, 0),
                       M("LuzLED"));

            var lgo = new GameObject("Luz_Nave");
            lgo.transform.SetParent(t, false);
            lgo.transform.localPosition = new Vector3(0, -0.15f, 0);
            var l = lgo.AddComponent<Light>();
            l.type = LightType.Point;
            l.range = 16f;
            l.intensity = intensidad / 200f;
            l.color = new Color(1f, 0.97f, 0.90f);
            l.shadows = LightShadows.None;   // el direccional aporta las sombras
        }

        /// <summary>Marcador fiducial pegado al piso (localizacion del robot).</summary>
        static void MarcadorPiso(Transform parent, Vector3 pos, float size = 0.60f, float yaw = 0f)
        {
            PBGen.Plane("Marcador_Piso", parent, size, size,
                        new Vector3(pos.x, 0.011f, pos.z), M("Marcador"), 0, new Vector3(0, yaw, 0));
        }

        // =====================================================================
        //  ESCENA COMPLETA
        // =====================================================================
        public static GameObject Build(Transform parent, bool conTecho = false)
        {
            var root = PBGen.Group("ALMACEN", parent);

            // ---------------------------------------------------- piso y pintura
            var piso = PBGen.Group("Piso", root);
            PBGen.Plane("Losa_Concreto", piso, W, D, new Vector3(0, 0, 0), M("Concreto"), 8, default, 0.25f);
            PBGen.Cube("Losa_Espesor", piso, new Vector3(W, 0.30f, D), new Vector3(0, -0.16f, 0),
                       M("Concreto"), default, 0.3f);

            // pasillo peatonal (verde) pegado al muro oeste
            PBGen.Plane("Andador_Peatonal", piso, 1.60f, D - 1f, new Vector3(X0 + 1.2f, 0.012f, 0),
                        M("PisoCarril"), 0, default, 0.6f);
            // carriles de circulacion
            PBGen.Plane("Carril_Central", piso, W - 2f, 0.20f, new Vector3(0, 0.012f, -7.8f),
                        M("Peligro"), 0, default, 3f);
            PBGen.Plane("Carril_Central2", piso, W - 2f, 0.20f, new Vector3(0, 0.012f, 7.4f),
                        M("Peligro"), 0, default, 3f);

            // marcadores fiduciales de navegacion
            for (int i = 0; i < 6; i++)
                MarcadorPiso(piso, new Vector3(-10f + i * 4f, 0, -7.8f));
            for (int i = 0; i < 5; i++)
                MarcadorPiso(piso, new Vector3(-8f + i * 4f, 0, 2.5f), 0.5f, 45f);

            // ------------------------------------------------------------- muros
            var muros = PBGen.Group("Muros", root);
            var andenesSur = new List<Vector2> {
                new Vector2(-8.5f, 3.2f), new Vector2(-3.0f, 3.2f),
                new Vector2( 3.0f, 3.2f), new Vector2( 8.5f, 3.2f) };
            var carrilesNorte = new List<Vector2> {
                new Vector2(-6.0f, 2.6f), new Vector2(-2.0f, 2.6f),
                new Vector2( 2.0f, 2.6f), new Vector2( 6.0f, 2.6f) };

            WallX("Muro_Sur", muros, Z0, H, M("MuroPanel"), andenesSur, 4.0f);
            WallX("Muro_Norte", muros, Z1, H, M("MuroPanel"), carrilesNorte, 3.2f);
            WallZ("Muro_Oeste", muros, X0, H, M("MuroPanel"));
            WallZ("Muro_Este", muros, X1, H, M("MuroPanel"));

            // zoclo de proteccion
            foreach (float z in new[] { Z0 + 0.2f, Z1 - 0.2f })
                PBGen.Cube("Zoclo", muros, new Vector3(W, 0.30f, 0.06f), new Vector3(0, 0.15f, z),
                           M("Peligro"), default, 4f);

            if (conTecho)
            {
                PBGen.Cube("Techo", muros, new Vector3(W, 0.20f, D), new Vector3(0, H + 0.1f, 0),
                           M("MetalCepillado"), default, 0.5f);
                for (int i = 0; i < 5; i++)
                    PBGen.Cube("Trabe_" + i, muros, new Vector3(W, 0.35f, 0.25f),
                               new Vector3(0, H - 0.2f, -10f + i * 5f), M("Galvanizado"), default, 1.5f);
            }

            // ------------------------------------------------ andenes de embarque
            var docks = PBGen.Group("Andenes_Outbound", root);
            string[] dn = { "D1", "D2", "D3", "D4" };
            for (int i = 0; i < 4; i++)
                DockDoor(docks, dn[i], andenesSur[i].x, Z0 + T / 2f, true);

            // ------------------------------------------------------ area inbound
            var inb = PBGen.Group("Inbound_Area", root);
            string[] ln = { "L1", "L2", "L3", "L4" };
            for (int i = 0; i < 4; i++)
            {
                float x = carrilesNorte[i].x;
                DockDoor(inb, ln[i], x, Z1 - T / 2f, false);
                Conveyor(inb, "Banda_" + ln[i], new Vector3(x, 0, Z1 - 2.6f), 3.4f, 0f, 0.55f, 0.85f, i % 2 == 1);
                Pallet(inb, new Vector3(x + 1.55f, 0, Z1 - 2.4f));
                BoxStack(inb, new Vector3(x + 1.55f, 0, Z1 - 2.4f), 3);
            }
            PBGen.Cube("Letrero_Inbound", inb, new Vector3(4.0f, 0.45f, 0.06f),
                       new Vector3(0, 4.55f, Z1 - 0.16f), M("Blanco"));

            // ------------------------------------------------------------- racks
            var racks = PBGen.Group("Racks", root);
            float[] filas = { 5.0f, 0.0f, -5.0f };
            int bahias = 4; float ancho = 2.70f, fondo = 1.05f;
            for (int f = 0; f < filas.Length; f++)
            {
                // fila doble: dos racks espalda con espalda
                for (int s = 0; s < 2; s++)
                {
                    float z = filas[f] + (s == 0 ? -0.60f : 0.60f);
                    var r = RackRow(racks, $"Rack_F{f + 1}_{(s == 0 ? "A" : "B")}",
                                    new Vector3(-1.5f, 0, z), 0f, bahias, 2, ancho, fondo);
                    FillRack(r, bahias, 2, ancho, fondo, f * 10 + s);
                }
            }
            // racks sencillos contra el muro este
            for (int i = 0; i < 2; i++)
            {
                var r = RackRow(racks, "Rack_Este_" + i, new Vector3(X1 - 1.1f, 0, -2.5f + i * 6.5f),
                                90f, 2, 2, ancho, fondo);
                FillRack(r, 2, 2, ancho, fondo, 50 + i);
            }

            // ------------------------------------------------- zona de embarque
            var stage = PBGen.Group("Staging_Outbound", root);
            for (int i = 0; i < 4; i++)
            {
                float x = andenesSur[i].x;
                Conveyor(stage, "Banda_Salida_" + dn[i], new Vector3(x, 0, Z0 + 4.4f), 2.6f, 0f, 0.5f, 0.8f, i % 2 == 0);
                Pallet(stage, new Vector3(x - 1.65f, 0, Z0 + 4.4f), 0, true);
                BoxStack(stage, new Vector3(x - 1.65f, 0, Z0 + 4.4f), 2, 0, true);
            }
            // tarimas vacias apiladas
            for (int p = 0; p < 8; p++)
                Pallet(stage, new Vector3(X0 + 1.6f, p * 0.16f, Z0 + 6.8f), p % 2 == 0 ? 0f : 90f);
            for (int p = 0; p < 6; p++)
                Pallet(stage, new Vector3(X0 + 3.2f, p * 0.16f, Z0 + 6.8f), 0, true);

            // ----------------------------------------------- obstaculos / mobiliario
            var obs = PBGen.Group("Obstaculos", root);

            // columnas estructurales
            var columnas = new[] {
                new Vector2(-10.5f, -8.8f), new Vector2(10.5f, -8.8f),
                new Vector2(-10.5f,  0.0f), new Vector2(10.5f,  0.0f),
                new Vector2(-10.5f,  4.4f), new Vector2(10.5f,  6.0f) };
            foreach (var c in columnas)
            {
                PBGen.Cube("Columna", obs, new Vector3(0.42f, H, 0.42f),
                           new Vector3(c.x, H / 2f, c.y), M("Galvanizado"), default, 1.5f);
                PBGen.Cube("Proteccion_Columna", obs, new Vector3(0.60f, 0.55f, 0.60f),
                           new Vector3(c.x, 0.28f, c.y), M("Peligro"), default, 2f);
            }

            // oficina / estacion de control (esquina noroeste)
            var ofi = PBGen.Group("Oficina_Control", obs, new Vector3(X0 + 2.9f, 0, Z1 - 2.8f));
            PBGen.Cube("Muro_Ofi_A", ofi, new Vector3(5.0f, 2.80f, 0.12f), new Vector3(0, 1.40f, -2.2f), M("Vidrio"));
            PBGen.Cube("Muro_Ofi_B", ofi, new Vector3(0.12f, 2.80f, 4.4f), new Vector3(2.5f, 1.40f, 0), M("Vidrio"));
            PBGen.Cube("Losa_Ofi", ofi, new Vector3(5.1f, 0.14f, 4.5f), new Vector3(0, 2.87f, 0), M("Blanco"), default, 0.6f);
            Mesa(ofi, new Vector3(-1.0f, 0, -1.2f));
            Mesa(ofi, new Vector3(1.0f, 0, 0.6f), 90f);
            Silla(ofi, new Vector3(-1.0f, 0, -0.3f), 180f, "Naranja");
            Silla(ofi, new Vector3(0.2f, 0, 0.6f), 90f, "PlasticoAzul");
            Gabinete(ofi, new Vector3(-2.1f, 0, 1.5f), 90f);
            PBGen.Cube("Monitor", ofi, new Vector3(0.60f, 0.36f, 0.03f), new Vector3(-1.0f, 0.95f, -1.45f), M("NegroMate"));
            PBGen.Cube("Monitor_Pantalla", ofi, new Vector3(0.56f, 0.32f, 0.01f), new Vector3(-1.0f, 0.95f, -1.43f), M("LuzLED"));

            // banco de trabajo / mantenimiento (muro oeste)
            var mant = PBGen.Group("Mantenimiento", obs, new Vector3(X0 + 2.4f, 0, -3.0f));
            PBGen.Cube("Banco", mant, new Vector3(2.60f, 0.08f, 0.80f), new Vector3(0, 0.90f, 0), M("MetalCepillado"), default, 1.5f);
            foreach (int s in new[] { -1, 1 })
                PBGen.Cube("Pata_Banco", mant, new Vector3(0.08f, 0.86f, 0.70f), new Vector3(1.20f * s, 0.43f, 0), M("Gris"));
            PBGen.Cube("Panel_Herramientas", mant, new Vector3(2.60f, 1.20f, 0.05f), new Vector3(0, 1.65f, -0.40f), M("Peligro"), default, 2f);
            Gabinete(mant, new Vector3(1.9f, 0, 0.2f), 90f);

            // contenedores y botes
            for (int i = 0; i < 3; i++)
            {
                PBGen.Cube("Contenedor_" + i, obs, new Vector3(0.75f, 1.05f, 0.65f),
                           new Vector3(X1 - 0.9f, 0.53f, -9.6f + i * 1.15f),
                           M(i == 0 ? "Verde" : i == 1 ? "PlasticoAzul" : "Rojo"), default, 1.5f);
                PBGen.Cube("Tapa_" + i, obs, new Vector3(0.78f, 0.06f, 0.68f),
                           new Vector3(X1 - 0.9f, 1.08f, -9.6f + i * 1.15f), M("NegroMate"));
            }

            // conos y barandales
            foreach (var p in new[] { new Vector3(-9.9f, 0, -8.6f), new Vector3(-1.2f, 0, -9.0f),
                                      new Vector3(5.0f, 0, -8.6f), new Vector3(10.4f, 0, -6.4f),
                                      new Vector3(0.4f, 0, 9.4f), new Vector3(-8.4f, 0, 2.4f) })
                ConoSeguridad(obs, p);
            Barandal(obs, "Barandal_Peatonal", new Vector3(X0 + 1.9f, 0, 2.5f), 7f, 0f);
            Barandal(obs, "Barandal_Oficina", new Vector3(X0 + 5.9f, 0, Z1 - 2.8f), 4.4f, 0f);

            // extintores y senalizacion en muros
            Extintor(obs, new Vector3(X0 + 0.35f, 1.10f, -1.0f), 90f);
            Extintor(obs, new Vector3(X1 - 0.35f, 1.10f, 4.0f), -90f);
            PBGen.Cube("Senal_Salida", obs, new Vector3(0.60f, 0.28f, 0.05f),
                       new Vector3(X0 + 0.2f, 3.20f, 8.0f), M("Verde"));
            PBGen.Cube("Senal_Limite_Vel", obs, new Vector3(0.50f, 0.50f, 0.05f),
                       new Vector3(X1 - 0.2f, 2.60f, -6.0f), M("Blanco"));

            // estacion de carga de baterias (esquina noreste)
            EstacionCarga(obs, new Vector3(X1 - 3.2f, 0, Z1 - 2.6f), 180f);

            // ----------------------------------------------------------- luminarias
            var luces = PBGen.Group("Iluminacion", root);
            for (int ix = 0; ix < 3; ix++)
                for (int iz = 0; iz < 3; iz++)
                    LamparaIndustrial(luces, new Vector3(-8f + ix * 8f, H - 0.35f, -8f + iz * 8f), 320f);

            return root.gameObject;
        }
    }
}
