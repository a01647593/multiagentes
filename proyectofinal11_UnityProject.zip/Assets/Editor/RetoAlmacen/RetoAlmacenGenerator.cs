// -----------------------------------------------------------------------------
//  RetoAlmacenGenerator.cs  -  Panel de control del generador
// -----------------------------------------------------------------------------
//  Menu de Unity:  Reto Almacen > Generador de escena
//
//  Flujo recomendado:
//    1) Importar el paquete / carpeta Assets (Textures + Editor).
//    2) Window > Package Manager > ProBuilder  (instalar si no esta).
//    3) Reto Almacen > Generador de escena  ->  "Generar TODO".
//    4) Reto Almacen > Exportar UnityPackage de entrega.
// -----------------------------------------------------------------------------
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.ProBuilder;

namespace RetoAlmacen
{
    public class RetoAlmacenGenerator : EditorWindow
    {
        const string RootName = "RETO_ALMACEN";
        const string ScenePath = "Assets/Scenes/Almacen_Reto.unity";
        const string PrefabDir = "Assets/Prefabs/Vehiculos";

        bool conTecho = false;
        bool conColliders = true;
        bool marcarStatic = true;
        bool crearCamara = true;
        bool exportarPrefabs = true;

        [MenuItem("Reto Almacen/Generador de escena", false, 0)]
        static void Open() => GetWindow<RetoAlmacenGenerator>(true, "Reto Almacen - Generador");

        void OnGUI()
        {
            EditorGUILayout.LabelField("Modelado con ProBuilder", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Genera la escena completa del reto: 6 vehiculos + nave de 26 x 24 m " +
                "con andenes, racks, bandas y obstaculos. Todo con primitivas de ProBuilder.",
                MessageType.Info);

            EditorGUILayout.Space();
            conTecho       = EditorGUILayout.Toggle(new GUIContent("Generar techo",
                             "Desactivado permite ver la nave desde arriba."), conTecho);
            conColliders   = EditorGUILayout.Toggle("Agregar colliders", conColliders);
            marcarStatic   = EditorGUILayout.Toggle("Marcar entorno como Static", marcarStatic);
            crearCamara    = EditorGUILayout.Toggle("Crear camara de presentacion", crearCamara);
            exportarPrefabs= EditorGUILayout.Toggle("Guardar vehiculos como Prefab", exportarPrefabs);

            EditorGUILayout.Space();
            if (!ProBuilderDisponible())
            {
                EditorGUILayout.HelpBox("No se encontro ProBuilder. Instalalo en " +
                    "Window > Package Manager > Unity Registry > ProBuilder.", MessageType.Error);
            }

            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("GENERAR TODO", GUILayout.Height(38))) GenerarTodo();
                if (GUILayout.Button("Limpiar", GUILayout.Height(38), GUILayout.Width(90))) Limpiar();
            }
            EditorGUILayout.Space();
            if (GUILayout.Button("Solo vehiculos")) GenerarVehiculos();
            if (GUILayout.Button("Solo entorno")) GenerarEntorno();
            if (GUILayout.Button("Reconstruir materiales")) { MatLib.Build(); AssetDatabase.Refresh(); }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Entrega", EditorStyles.boldLabel);
            if (GUILayout.Button("Exportar UnityPackage de entrega")) ExportarPaquete();
        }

        static bool ProBuilderDisponible()
        {
            return System.AppDomain.CurrentDomain.GetAssemblies()
                .Any(a => a.GetName().Name.Contains("Unity.ProBuilder"));
        }

        // ------------------------------------------------------------------ raiz
        static Transform GetRoot(bool limpiar)
        {
            var old = GameObject.Find(RootName);
            if (old != null)
            {
                if (limpiar) Object.DestroyImmediate(old);
                else return old.transform;
            }
            var go = new GameObject(RootName);
            Undo.RegisterCreatedObjectUndo(go, "Generar Reto Almacen");
            return go.transform;
        }

        // -------------------------------------------------------------- acciones
        void GenerarTodo()
        {
            var t0 = System.DateTime.Now;
            EditorUtility.DisplayProgressBar("Reto Almacen", "Preparando materiales...", 0.05f);
            MatLib.Build();

            var root = GetRoot(true);

            EditorUtility.DisplayProgressBar("Reto Almacen", "Modelando la nave...", 0.25f);
            var almacen = WarehouseFactory.Build(root, conTecho);

            EditorUtility.DisplayProgressBar("Reto Almacen", "Modelando los 6 vehiculos...", 0.70f);
            var vehiculos = VehicleFactory.BuildAll(root);

            EditorUtility.DisplayProgressBar("Reto Almacen", "Iluminacion y camara...", 0.88f);
            ConfigurarIluminacion(root);
            if (crearCamara) ConfigurarCamara(root);

            if (conColliders) PBGen.AddColliders(almacen.transform);
            if (marcarStatic) PBGen.MarkStatic(almacen.transform);

            if (exportarPrefabs) GuardarPrefabs(vehiculos.transform);

            EditorUtility.ClearProgressBar();
            GuardarEscena();

            int piezas = root.GetComponentsInChildren<ProBuilderMesh>().Length;
            Debug.Log($"[Reto Almacen] Escena generada: {piezas} objetos de ProBuilder " +
                      $"en {(System.DateTime.Now - t0).TotalSeconds:0.0} s.");
            Selection.activeGameObject = root.gameObject;
            SceneView.lastActiveSceneView?.FrameSelected();
        }

        void GenerarVehiculos()
        {
            MatLib.Build();
            var root = GetRoot(false);
            var v = GameObject.Find(RootName + "/VEHICULOS");
            if (v != null) DestroyImmediate(v);
            var go = VehicleFactory.BuildAll(root);
            if (exportarPrefabs) GuardarPrefabs(go.transform);
            Selection.activeGameObject = go;
        }

        void GenerarEntorno()
        {
            MatLib.Build();
            var root = GetRoot(false);
            var a = GameObject.Find(RootName + "/ALMACEN");
            if (a != null) DestroyImmediate(a);
            var go = WarehouseFactory.Build(root, conTecho);
            if (conColliders) PBGen.AddColliders(go.transform);
            if (marcarStatic) PBGen.MarkStatic(go.transform);
            Selection.activeGameObject = go;
        }

        static void Limpiar()
        {
            var old = GameObject.Find(RootName);
            if (old != null) Undo.DestroyObjectImmediate(old);
        }

        // ---------------------------------------------------------- iluminacion
        static void ConfigurarIluminacion(Transform root)
        {
            // Sol / luz principal
            var solGO = GameObject.Find("Directional Light") ?? new GameObject("Directional Light");
            var sol = solGO.GetComponent<Light>() ?? solGO.AddComponent<Light>();
            sol.type = LightType.Directional;
            sol.color = new Color(1f, 0.96f, 0.89f);
            sol.intensity = 1.15f;
            sol.shadows = LightShadows.Soft;
            sol.shadowStrength = 0.75f;
            solGO.transform.rotation = Quaternion.Euler(52f, -42f, 0f);

            // Relleno frio desde los tragaluces
            var fill = new GameObject("Luz_Relleno");
            fill.transform.SetParent(root, false);
            fill.transform.rotation = Quaternion.Euler(35f, 155f, 0f);
            var lf = fill.AddComponent<Light>();
            lf.type = LightType.Directional;
            lf.color = new Color(0.72f, 0.80f, 0.95f);
            lf.intensity = 0.35f;
            lf.shadows = LightShadows.None;

            // Ambiente
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor    = new Color(0.55f, 0.58f, 0.64f);
            RenderSettings.ambientEquatorColor= new Color(0.42f, 0.43f, 0.46f);
            RenderSettings.ambientGroundColor = new Color(0.22f, 0.22f, 0.23f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = new Color(0.62f, 0.64f, 0.68f);
            RenderSettings.fogStartDistance = 24f;
            RenderSettings.fogEndDistance = 70f;
        }

        static void ConfigurarCamara(Transform root)
        {
            var camGO = GameObject.Find("Camara_Presentacion");
            if (camGO == null)
            {
                camGO = new GameObject("Camara_Presentacion");
                camGO.AddComponent<Camera>();
            }
            camGO.transform.SetParent(root, false);
            camGO.transform.position = new Vector3(-14.5f, 11.5f, -17f);
            camGO.transform.rotation = Quaternion.Euler(28f, 42f, 0f);
            var c = camGO.GetComponent<Camera>();
            c.fieldOfView = 55f;
            c.farClipPlane = 200f;
        }

        // -------------------------------------------------------------- prefabs
        static void GuardarPrefabs(Transform vehiculos)
        {
            MatLib.EnsureFolder(PrefabDir);
            foreach (Transform v in vehiculos)
            {
                foreach (var pb in v.GetComponentsInChildren<ProBuilderMesh>())
                {
                    pb.ToMesh();
                    pb.Refresh();
                }
                string path = $"{PrefabDir}/{v.name}.prefab";
                PrefabUtility.SaveAsPrefabAsset(v.gameObject, path);
            }
            AssetDatabase.SaveAssets();
            Debug.Log($"[Reto Almacen] Prefabs guardados en {PrefabDir}");
        }

        // ---------------------------------------------------------------- escena
        static void GuardarEscena()
        {
            MatLib.EnsureFolder("Assets/Scenes");
            var s = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(s.path))
                EditorSceneManager.SaveScene(s, ScenePath);
            else
                EditorSceneManager.SaveScene(s);
            AssetDatabase.Refresh();
        }

        // ------------------------------------------------------------- entregable
        [MenuItem("Reto Almacen/Exportar UnityPackage de entrega", false, 20)]
        public static void ExportarPaquete()
        {
            GuardarEscena();
            var carpetas = new[] { "Assets/Editor", "Assets/Textures", "Assets/Materials",
                                   "Assets/Scenes", "Assets/Prefabs", "Assets/Documentacion" }
                           .Where(AssetDatabase.IsValidFolder).ToArray();

            string destino = EditorUtility.SaveFilePanel(
                "Guardar UnityPackage de entrega", "", "RetoAlmacen_Equipo.unitypackage", "unitypackage");
            if (string.IsNullOrEmpty(destino)) return;

            AssetDatabase.ExportPackage(carpetas, destino,
                ExportPackageOptions.Recurse | ExportPackageOptions.IncludeDependencies);
            Debug.Log($"[Reto Almacen] UnityPackage exportado en: {destino}");
            EditorUtility.RevealInFinder(destino);
        }
    }
}
