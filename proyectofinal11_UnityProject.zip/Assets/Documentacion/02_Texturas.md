# Catálogo de texturas (20 % de la rúbrica)

16 archivos PNG de **512 × 512**, generados proceduralmente para este proyecto
(ruido periódico + patrones dibujados), por lo que son **seamless**: se repiten sin
costura y no tienen problemas de licencia.

| # | Archivo | Material | Metallic / Smooth | Dónde se usa | Tiling típico |
|---|---|---|---|---|---|
| 01 | `01_concreto_piso.png` | `M_Concreto` | 0.00 / 0.15 | Losa de la nave | 0.25 |
| 02 | `02_piso_linea_carril.png` | `M_PisoCarril` | 0.00 / 0.35 | Andador peatonal | 0.6 |
| 03 | `03_carton_corrugado.png` | `M_Carton` | 0.00 / 0.05 | Cajas de las estibas | 1.6 |
| 04 | `04_madera_tarima.png` | `M_MaderaTarima` | 0.00 / 0.10 | Tarimas, plataforma del carro | 2.0 |
| 05 | `05_acero_rack_azul.png` | `M_RackAzul` | 0.60 / 0.45 | Puntales y diagonales del rack | 1.5 |
| 06 | `06_acero_rack_rojo.png` | `M_RackRojo` | 0.60 / 0.45 | Vigas del rack | 1.5 |
| 07 | `07_placa_antiderrapante.png` | `M_Antiderrapante` | 0.80 / 0.35 | Estribos, rampas, plato del AGV | 2–3 |
| 08 | `08_franjas_peligro.png` | `M_Peligro` | 0.00 / 0.30 | Barandales, zoclos, protecciones | 2–4 |
| 09 | `09_pintura_amarilla_equipo.png` | `M_PinturaEquipo` | 0.20 / 0.55 | Carrocería del E80, transpaleta, apilador | 0.8–1.5 |
| 10 | `10_hule_llanta.png` | `M_Llanta` | 0.00 / 0.10 | Neumáticos, defensas de andén | 2–6 |
| 11 | `11_metal_cepillado.png` | `M_MetalCepillado` | 0.90 / 0.60 | Horquillas, rieles internos | 1.5–2 |
| 12 | `12_marcador_piso_fiducial.png` | `M_Marcador` | 0.00 / 0.20 | Marcadores de navegación en piso y AGV | 1.0 |
| 13 | `13_plastico_azul_caja.png` | `M_PlasticoAzul` | 0.00 / 0.45 | Tarimas plásticas, tractor, bandas azules | 1.2–1.5 |
| 14 | `14_panel_muro_industrial.png` | `M_MuroPanel` | 0.00 / 0.25 | Muros perimetrales | 0.4 |
| 15 | `15_cortina_anden.png` | `M_CortinaAnden` | 0.70 / 0.40 | Cortinas de los 8 accesos | 0.6 |
| 16 | `16_acero_galvanizado.png` | `M_Galvanizado` | 0.85 / 0.55 | Columnas, marcos, largueros | 1.5 |

## Materiales de color plano (sin textura)

`M_NegroMate`, `M_Gris`, `M_GrisOscuro`, `M_Naranja`, `M_Rojo`, `M_Verde`, `M_Blanco`,
`M_Cromo`, `M_Vidrio`, `M_LuzLED` (emisivo), `M_LuzRoja` (emisivo).

Los dos emisivos son los que hacen que faros, balizas y franjas LED se vean encendidos
sin necesidad de una `Light` por pieza.

## Importación recomendada en Unity

Para las 16, en el inspector del PNG:

- **Texture Type**: Default
- **Wrap Mode**: Repeat  ← imprescindible, si no el tiling se estira
- **Filter Mode**: Bilinear
- **Compression**: Normal Quality
- `12_marcador_piso_fiducial.png`: bajen **Filter Mode a Point** si quieren que el
  marcador se vea con bordes duros (útil si luego lo detectan por visión).

## Cómo se regeneran

Están hechas con un script de Python (`gen_texturas.py`, incluido). Si quieren variantes
—otro color de rack, otro patrón de marcador— cambien el `seed` o los colores base y
vuelvan a correrlo. No hace falta para la entrega, pero sirve si les piden más ejemplos.
