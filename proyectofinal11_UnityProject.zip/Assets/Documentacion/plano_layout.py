#!/usr/bin/env python3
"""Plano en planta del almacen + verificacion de traslapes.
Refleja los mismos numeros que WarehouseFactory.cs / VehicleFactory.cs."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch

W, D = 26.0, 24.0
X0, X1, Z0, Z1 = -W/2, W/2, -D/2, D/2

fig, ax = plt.subplots(figsize=(13, 12))
ax.set_facecolor("#3c3f43")

boxes = []          # (x0,z0,x1,z1,label,kind)


def add(cx, cz, w, d, label, kind, yaw=0):
    if yaw % 180 == 90:
        w, d = d, w
    boxes.append((cx - w/2, cz - d/2, cx + w/2, cz + d/2, label, kind))


# ---------------------------------------------------------------- muros
ax.add_patch(Rectangle((X0, Z0), W, D, fc="#5a5d61", ec="none"))

# --------------------------------------------------------------- andenes
docks = [-8.5, -3.0, 3.0, 8.5]
for i, x in enumerate(docks):
    add(x, Z0 + 1.15, 2.2, 2.0, f"D{i+1}", "dock")
lanes = [-6.0, -2.0, 2.0, 6.0]
for i, x in enumerate(lanes):
    add(x, Z1 - 2.6, 0.85, 3.4, f"L{i+1}", "conv")
    add(x + 1.55, Z1 - 2.4, 1.2, 1.0, "", "pallet")

# ----------------------------------------------------------------- racks
filas = [5.0, 0.0, -5.0]
bahias, ancho, fondo = 4, 2.70, 1.05
for f, zc in enumerate(filas):
    for s, off in ((0, -0.60), (1, 0.60)):
        add(-1.5, zc + off, bahias*ancho, fondo, f"Rack F{f+1}", "rack")
for i in range(2):
    add(X1 - 1.1, -2.5 + i*6.5, 2*ancho, fondo, "Rack E", "rack", yaw=90)

# ------------------------------------------------------------ staging sur
for i, x in enumerate(docks):
    add(x, Z0 + 4.4, 0.8, 2.6, "", "conv")
    add(x - 1.65, Z0 + 4.4, 1.2, 1.0, "", "pallet")
add(X0 + 1.6, Z0 + 6.8, 1.2, 1.0, "", "pallet")
add(X0 + 3.2, Z0 + 6.8, 1.2, 1.0, "", "pallet")

# ------------------------------------------------------------- obstaculos
for cx, cz in ((-10.5, -8.8), (10.5, -8.8), (-10.5, 0), (10.5, 0),
               (10.5, 6.0), (-10.5, 4.4)):
    add(cx, cz, 0.6, 0.6, "", "col")
add(X0 + 2.9, Z1 - 2.8, 5.0, 4.4, "Oficina", "obs")
add(X0 + 2.4, -3.0, 2.6, 0.8, "Mtto", "obs")
add(X1 - 3.2, Z1 - 2.6, 3.2, 2.2, "Carga", "obs")
for i in range(3):
    add(X1 - 0.9, -9.6 + i*1.15, 0.78, 0.68, "", "obs")
add(X0 + 1.9, 2.5, 0.2, 7.0, "", "obs")

# -------------------------------------------------------------- vehiculos
veh = [("E80",        -6.6, -8.6, 1.4, 4.4,  0),
       ("Robot",      -1.0, -2.5, 0.5, 0.7, 90),
       ("Transpaleta", 4.9, -8.0, 0.8, 2.6, 180),
       ("Apilador",    9.9, -5.0, 0.9, 2.6, 90),
       ("AGV",         0.5,  2.5, 0.9, 1.2,  0),
       ("Tractor",     8.0,  0.5, 1.1, 5.2, 180)]
for n, x, z, w, d, y in veh:
    add(x, z, w, d, n, "veh", yaw=y)

# ------------------------------------------------------------------ dibujo
col = {"dock": "#8a6d1f", "conv": "#2b2b2e", "rack": "#1f4b96", "pallet": "#a8814f",
       "col": "#9aa0a6", "obs": "#6b6f74", "veh": "#e0b423"}
for x0, z0, x1, z1, lb, k in boxes:
    ax.add_patch(Rectangle((x0, z0), x1-x0, z1-z0, fc=col[k],
                           ec="#101215", lw=0.8, alpha=0.95))
    if lb:
        ax.text((x0+x1)/2, (z0+z1)/2, lb, ha="center", va="center",
                fontsize=7, color="white", weight="bold")

# --------------------------------------------------------- traslape check
def overlap(a, b):
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])

conf = []
for i in range(len(boxes)):
    for j in range(i+1, len(boxes)):
        a, b = boxes[i], boxes[j]
        if a[5] == "pallet" and b[5] == "rack":
            continue
        if b[5] == "pallet" and a[5] == "rack":
            continue
        if overlap(a, b):
            conf.append((a[4] or a[5], b[4] or b[5], (round(a[0],2),round(a[1],2),round(a[2],2),round(a[3],2)), (round(b[0],2),round(b[1],2),round(b[2],2),round(b[3],2))))

ax.set_xlim(X0-1, X1+1); ax.set_ylim(Z0-1, Z1+1)
ax.set_aspect("equal"); ax.grid(color="#6e7278", lw=0.3)
ax.set_title("Plano en planta - Almacen del reto (26 x 24 m)  |  Z+ = INBOUND, Z- = ANDENES",
             color="#eee", fontsize=11)
ax.tick_params(colors="#ccc")
fig.patch.set_facecolor("#2a2c30")
fig.savefig("/home/claude/AlmacenReto/Assets/Documentacion/plano_layout.png",
            dpi=130, bbox_inches="tight", facecolor=fig.get_facecolor())
print("TRASLAPES:", len(conf))
for c in conf:
    print("  !", c)
