# Guía manual — modelar el reto a mano con ProBuilder

Esta guía reproduce **lo mismo que hace el generador**, pero paso a paso en la interfaz.
Sirve para dos cosas: entender qué hicieron y poder modificarlo en vivo si el profesor
pide cambios durante la revisión.

Abrir la ventana: `Tools > ProBuilder > ProBuilder Window`.
Trabajen en modo **Icons** y con la barra de modos de edición (Objeto / Vértice / Arista / Cara).

---

## 0. Convenciones que usamos

| Regla | Valor |
|---|---|
| Unidad | 1 unidad de Unity = **1 metro** |
| Frente de un vehículo | eje **+Z** |
| Pivote de las piezas | `Center` (New Shape > Pivot: Center) |
| Snap | `Ctrl` mientras mueven = 0.25 m; en `Edit > Grid and Snap` bájenlo a 0.05 m para detalle |
| Nombres | `Categoria_Pieza_Lado` → `Horquilla_I`, `Riel_Ext_D` |

Atajos que van a usar todo el tiempo:

- `Shift + arrastrar` sobre una cara = **Extrude**
- `Ctrl+E` / `Cmd+E` = Extrude de la selección
- `Alt+B` = Bevel
- `Alt+U` = abrir el **UV Editor**
- `Alt+X` = Set Pivot to Center of Selection

---

## 1. Preparar materiales (hacerlo primero)

1. `Assets > Create > Folder` → `Materials`.
2. Por cada textura de `Assets/Textures`: `Create > Material`, arrastren el PNG al slot
   **Base Map**, y nómbrenlo `M_<loquesea>`.
3. Ajusten **Metallic / Smoothness** según la tabla de `02_Texturas.md`.
4. Para aplicar: seleccionen el objeto (o caras) → en la ProBuilder Window,
   **Material Editor** → arrastren el material al slot → **Apply**.

> Truco: con caras seleccionadas pueden aplicar un material distinto **solo a esas caras**.
> Así el montacargas lleva amarillo en la carrocería y antiderrapante en el estribo,
> sin ser objetos separados.

---

## 2. Entorno — la nave

### 2.1 Piso
1. `New Shape > Plane`, tamaño **26 × 24 m**, 8 cortes en cada eje.
2. Posición `(0, 0, 0)`. Material `M_Concreto`.
3. `Alt+U` → UV Editor → pestaña **Auto** → `Tiling = 0.25` para que el concreto no se vea gigante.
4. Duplíquenlo (`Ctrl+D`), escálenlo a la franja del andador peatonal y súbanlo a `y = 0.012`
   para que no haya *z-fighting*. Material `M_PisoCarril`.

### 2.2 Muros con huecos de andén
Esto es lo que más se pregunta. Dos formas:

**Forma A (la que usa el script) — por segmentos:**
crear un cubo por cada tramo entre puertas, más un cubo de dintel encima del hueco.
Es la más limpia y no deja geometría rara.

**Forma B — recortando:**
1. Cubo de **26 × 5 × 0.25 m** en `z = -12`.
2. Modo **Cara**, seleccionen la cara interior.
3. `Subdivide` dos veces para tener cuadrícula.
4. Seleccionen las caras del hueco → `Delete Faces`.
5. Modo **Arista**, seleccionen el borde del hueco → `Extrude` hacia adentro 0.25 m para cerrar el marco.

Alturas: muro **5 m**, hueco de andén **4 m**, hueco de carril inbound **3.2 m**.

### 2.3 Andén de embarque (repetir 4 veces: D1–D4)
| Pieza | Primitiva | Tamaño (m) |
|---|---|---|
| Cortina | Cube | 3.00 × 3.90 × 0.08 · `M_CortinaAnden` |
| Marco superior | Cube | 3.30 × 0.20 × 0.30 · `M_Galvanizado` |
| Jambas (×2) | Cube | 0.16 × 4.05 × 0.30 |
| Rampa niveladora | Cube | 2.20 × 0.10 × 2.00 · `M_Antiderrapante` |
| Transición | **Prism** rotado −90° en X | 2.20 × 0.10 × 0.45 |
| Defensas (×2) | Cube | 0.25 × 0.45 × 0.20 · `M_Llanta` |
| Franja de aproximación | Plane en `y = 0.012` | 3.00 × 0.55 · `M_Peligro` |

Cuando terminen **uno**, agrúpenlo en un GameObject vacío y dupliquen a
`x = -8.5, -3.0, 3.0, 8.5`.

### 2.4 Rack selectivo
Un marco = 2 puntales + 5 diagonales.

1. Puntal: Cube **0.09 × 4.20 × 0.09**, uno en `z = +0.525` y otro en `z = -0.525`.
2. Diagonal: Cube **0.05 × 0.05 × 1.24** rotado **±32° en X**, repetido cada 0.85 m de altura.
3. Placa base: Cube 0.16 × 0.03 × 0.16 al pie de cada puntal.
4. Agrupen el marco y dupliquen cada **2.70 m** (ancho de bahía) → 5 marcos = 4 bahías.
5. Vigas: Cube **2.61 × 0.13 × 0.06** en `y = 1.05` y `y = 2.60`, al frente y atrás.
   Material `M_RackRojo`; los marcos van con `M_RackAzul`.
6. Larguero de apoyo: Cube 2.50 × 0.04 × 0.05, dos por bahía.

Coloquen las filas dobles en `z = 5.0, 0.0, -5.0`, cada fila con dos racks en `z ± 0.60`.
Pasillo resultante ≈ 2.45 m.

### 2.5 Tarima (la pieza que más se repite)
| Sub-pieza | Cantidad | Tamaño |
|---|---|---|
| Patines | 3 | 1.20 × 0.075 × 0.10 |
| Tacos | 3 | 0.10 × 0.055 × 1.00 |
| Duelas superiores | 5 | 1.20 × 0.022 × 0.14 |

Material `M_MaderaTarima` (o `M_PlasticoAzul`). **Guárdenla como Prefab** —
la van a usar 100+ veces.

### 2.6 Banda de rodillos
1. Rieles: 2 cubos 0.07 × 0.16 × largo, separados el ancho de la banda.
2. Patas: cubos 0.05 × 0.47 × 0.05 cada 1.2 m + travesaño.
3. Rodillos: **Cylinder** r = 0.045, altura = ancho − 0.08, rotado **(0, 0, 90)**,
   repetido cada 0.16 m. Material `M_Cromo`.

### 2.7 Obstáculos
Cubos simples, pero con proporciones creíbles:

- Columna: 0.42 × 5.00 × 0.42, con un cubo 0.60 × 0.55 × 0.60 de `M_Peligro` en la base.
- Mesa: cubierta 1.40 × 0.04 × 0.70 a `y = 0.74` + 4 patas de 0.05.
- Silla: asiento a `y = 0.45`, respaldo inclinado −8°.
- Cono: **Cone** r = 0.14, h = 0.52 + base 0.34 × 0.04 × 0.34 + anillo reflejante.
- Barandal: postes cada 1.5 m + 2 rieles horizontales, todo con `M_Peligro`.

---

## 3. Vehículos

### 3.1 Montacargas E80 — orden de armado
1. **Chasis**: Cube 0.95 × 0.45 × 1.70 en `y = 0.42`.
2. **Capó**: Cube 1.00 × 0.52 × 0.95 en `(0, 0.90, −0.62)`.
3. **Contrapeso**: Cube 0.86 × 0.50 × 0.75 + **Prism** 1.00 × 0.55 × 0.75 rotado 180° en Y encima.
4. **Puesto**: piso `M_Antiderrapante`, asiento (base + respaldo −10°), columna de dirección
   (Cylinder r 0.045 inclinado −25°) y volante (Cylinder r 0.19, h 0.045, rotado 65° en X).
5. **Jaula**: 4 postes Cylinder r 0.04 + techo 1.16 × 0.07 × 1.55 en `y = 2.20`
   + 5 barras transversales.
6. **Mástil** (agrúpenlo en un vacío en `z = 0.92`): 2 rieles externos 0.10 × 2.30 × 0.14
   en `x = ±0.44`, 2 internos más chicos, traviesas arriba y abajo,
   cilindro de elevación Cylinder r 0.055 × 1.90.
7. **Carro + horquillas** (otro vacío en `z = 1.02`): placa, respaldo de carga con 4 barras,
   y por lado: tramo vertical 0.13 × 0.50 × 0.05 + tramo horizontal 0.13 × 0.05 × 1.20
   + punta **Prism** rotado −90° en X.
8. **Llantas**: Cylinder rotado **(0, 0, 90)**. Delanteras r 0.33 ancho 0.24 en `(±0.57, 0.33, 0.60)`;
   traseras r 0.25 ancho 0.20 en `(±0.44, 0.25, −1.05)`. Rin = cilindro interior `M_Cromo`.
9. **Detalles**: faros y baliza con `M_LuzLED` / `M_LuzRoja` (emisivos), franja `M_Peligro`
   en el contrapeso, placa de datos blanca.

> Regla de oro para que se vea bien: **la llanta siempre tiene que asomar del carrocería**.
> Si el ancho del chasis es mayor que la posición de la llanta, la llanta desaparece.

### 3.2 Robot con LiDAR (el del video)
Escala real ≈ 0.45 m de largo. Piezas clave:
placa base 0.34 × 0.025 × 0.44 (`M_Antiderrapante`), placa de electrónica encima con
separadores, 2 ruedas r 0.075 con rin naranja, rueda loca atrás,
**LiDAR** = 3 cilindros apilados (base gris, cabezal negro, tapa), torre de 2 guías 0.018 ×
0.40, carro y mini-horquillas, más batería roja, driver verde, micro azul, antena y
3 cilindros delgados como cableado.

### 3.3 Los otros cuatro
- **Transpaleta**: cuerpo + timón (Cylinder inclinado 32°) + 2 horquillas de 1.15 m con
  punta en Prism + rodillos de carga.
- **Apilador**: mismo mástil que el E80 pero de 2.10 m, con **patas straddle** de
  0.12 × 0.16 × 1.30 y ruedas r 0.065.
- **AGV**: caja 0.82 × 0.26 × 1.10, plato giratorio (Cylinder r 0.36) y un Plane con
  `M_Marcador` en la tapa, franjas LED emisivas al frente y atrás.
- **Tractor**: chasis + capó + roll bar de 4 postes + techo, enganche atrás y carro de
  remolque con plataforma de madera y barandal.

---

## 4. UVs y texturas

1. Seleccionen el objeto → `Alt+U`.
2. Pestaña **Auto** (no toquen Manual salvo que lo necesiten).
3. `Fill Mode: Tile`, y ajusten **Tiling**:
   - piso de concreto → 0.25
   - muros → 0.4
   - cartón, madera → 1.5–2
   - piezas chicas (llantas, antiderrapante) → 2–6
4. `Anchor` déjenlo en `None`; si una franja se ve corrida, usen `Offset`.
5. Para las franjas de peligro conviene `Rotation = 0` y tiling alto en U.

---

## 5. Iluminación

1. **Directional Light** principal: rotación `(52, −42, 0)`, intensidad 1.15, sombras Soft.
2. Segunda directional de relleno azulada: `(35, 155, 0)`, intensidad 0.35, **sin sombras**.
3. 9 luminarias de nave: `Point Light`, rango 16, intensidad ≈ 1.6, color cálido,
   **sombras apagadas** (si las 9 proyectan sombra, el editor se arrastra).
4. `Window > Rendering > Lighting`:
   - Environment Lighting → `Gradient`, cielo gris azulado, suelo oscuro.
   - Fog lineal de 24 a 70 m para dar profundidad a la nave.
5. Si quieren hornear: marquen el entorno como **Static** y usen
   `Generate Lighting` con *Lightmap Resolution* baja (8–10) para que no tarde una hora.

---

## 6. Errores comunes

| Síntoma | Causa | Solución |
|---|---|---|
| Todo rosa | Material con shader del pipeline equivocado | Menú `Reto Almacen > Reconstruir materiales` |
| La textura se ve gigante | Tiling en 1 sobre una pieza grande | UV Editor > Auto > bajar Tiling |
| Parpadeo entre dos caras | *z-fighting* por caras coincidentes | Separar 0.005–0.012 m |
| El objeto no se ve al mover el pivote | Pivote fuera de la malla | `Alt+X` (Center Pivot) |
| ProBuilder no aparece en el menú | Paquete no instalado | Package Manager > ProBuilder |
| El prefab del vehículo sale vacío | Se guardó antes de `ToMesh()` | Volver a generar con la opción de prefabs activada |
