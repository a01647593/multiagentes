#!/usr/bin/env python3
"""Genera 15 texturas seamless 512x512 para el proyecto de almacen en Unity/ProBuilder."""
import os, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = "/home/claude/AlmacenReto/Assets/Textures"
os.makedirs(OUT, exist_ok=True)
S = 512
rng = np.random.default_rng(7)


def save(arr_or_img, name):
    if isinstance(arr_or_img, np.ndarray):
        img = Image.fromarray(np.clip(arr_or_img, 0, 255).astype(np.uint8))
    else:
        img = arr_or_img
    img = img.convert("RGB")
    img.save(os.path.join(OUT, name), optimize=True)
    print("  ->", name)


def tileable_noise(size, freq, seed=0):
    """Ruido periodico (suma de senos con fase aleatoria) -> perfectamente seamless."""
    r = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size] / size * 2 * math.pi
    acc = np.zeros((size, size))
    for _ in range(24):
        fx, fy = r.integers(1, freq + 1), r.integers(1, freq + 1)
        ph = r.random() * 2 * math.pi
        amp = 1.0 / math.hypot(fx, fy)
        acc += amp * np.sin(fx * x + fy * y + ph)
    acc -= acc.min()
    acc /= acc.max()
    return acc


def fbm(size, octaves=5, base=4, seed=0):
    acc = np.zeros((size, size))
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        acc += amp * tileable_noise(size, base * (2 ** o), seed + o * 13)
        tot += amp
        amp *= 0.5
    return acc / tot


def colorize(mask, c_lo, c_hi):
    m = mask[..., None]
    return np.array(c_lo) * (1 - m) + np.array(c_hi) * m


# ---------------------------------------------------------------- 01 concreto
def t_concrete():
    n = fbm(S, 6, 3, seed=1)
    grain = rng.normal(0, 1, (S, S))
    grain = np.array(Image.fromarray(((grain - grain.min()) / np.ptp(grain) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.6))) / 255.0
    m = 0.65 * n + 0.35 * grain
    arr = colorize(m, (118, 118, 121), (168, 168, 170))
    # manchas oscuras
    stain = fbm(S, 3, 2, seed=44)
    arr *= (0.85 + 0.15 * stain)[..., None]
    save(arr, "01_concreto_piso.png")


# ------------------------------------------------- 02 piso epoxico con linea
def t_floor_lane():
    n = fbm(S, 5, 3, seed=2)
    arr = colorize(n, (92, 96, 100), (126, 130, 134))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 40, S, 74], fill=(226, 176, 24))     # linea amarilla
    d.rectangle([0, 438, S, 472], fill=(226, 176, 24))
    for x in range(0, S, 4):                              # desgaste
        if random.random() < 0.25:
            d.line([(x, 40), (x, 74)], fill=(150, 130, 70))
    save(img, "02_piso_linea_carril.png")


# --------------------------------------------------------------- 03 carton
def t_cardboard():
    n = fbm(S, 5, 4, seed=3)
    arr = colorize(n, (176, 132, 86), (208, 166, 118))
    # corrugado vertical suave
    x = np.arange(S)
    corr = 0.06 * np.sin(x / S * 2 * math.pi * 64)
    arr *= (1 + corr)[None, :, None]
    fib = rng.normal(0, 6, (S, S, 1))
    save(arr + fib, "03_carton_corrugado.png")


# ------------------------------------------------------- 04 madera de tarima
def t_pallet_wood():
    grain = fbm(S, 6, 3, seed=4)
    x = np.arange(S)[None, :]
    y = np.arange(S)[:, None]
    rings = 0.5 + 0.5 * np.sin(y / 6.0 + grain * 14)
    m = 0.55 * rings + 0.45 * grain
    arr = colorize(m, (150, 116, 74), (198, 165, 116))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for yy in (0, 128, 256, 384):                        # juntas entre duelas
        d.rectangle([0, yy, S, yy + 4], fill=(96, 72, 46))
    for cx, cy in ((60, 64), (250, 192), (430, 320), (150, 448)):
        d.ellipse([cx - 5, cy - 5, cx + 5, cy + 5], fill=(70, 55, 40))  # clavos
    save(img, "04_madera_tarima.png")


# ------------------------------------------- 05 / 06 acero pintado de rack
def painted_steel(base, name, holes=True):
    n = fbm(S, 4, 3, seed=hash(name) % 999)
    arr = colorize(n, tuple(int(c * 0.86) for c in base), tuple(min(255, int(c * 1.12)) for c in base))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    if holes:
        for yy in range(24, S, 48):
            d.rounded_rectangle([236, yy, 276, yy + 22], radius=6, fill=(38, 40, 44))
            d.rounded_rectangle([238, yy + 2, 274, yy + 20], radius=5, outline=(20, 22, 26), width=2)
    for _ in range(220):                                  # rayones
        x0, y0 = random.randrange(S), random.randrange(S)
        d.line([(x0, y0), (x0 + random.randint(-14, 14), y0 + random.randint(-5, 5))],
               fill=(210, 210, 214), width=1)
    save(img, name)


# --------------------------------------------------- 07 placa antiderrapante
def t_diamond_plate():
    arr = np.full((S, S, 3), 132.0)
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    step = 64
    for iy, yy in enumerate(range(0, S, step)):
        for xx in range(0, S, step):
            ox = (step // 2) if iy % 2 else 0
            cx, cy = (xx + ox) % S, yy + step // 2
            for dx, dy, col in ((2, 2, (86, 88, 92)), (0, 0, (196, 198, 204))):
                d.polygon([(cx - 22 + dx, cy - 8 + dy), (cx + 22 + dx, cy - 16 + dy),
                           (cx + 22 + dx, cy - 6 + dy), (cx - 22 + dx, cy + 2 + dy)], fill=col)
    img = img.filter(ImageFilter.GaussianBlur(0.7))
    a = np.array(img).astype(float) + fbm(S, 5, 4, seed=9)[..., None] * 26 - 13
    save(a, "07_placa_antiderrapante.png")


# ----------------------------------------------------- 08 franjas de peligro
def t_hazard():
    img = Image.new("RGB", (S, S), (232, 186, 20))
    d = ImageDraw.Draw(img)
    w = 64
    for i in range(-S // w, 2 * S // w):
        d.polygon([(i * w * 2, 0), (i * w * 2 + w, 0), (i * w * 2 + w + S, S), (i * w * 2 + S, S)],
                  fill=(28, 28, 30))
    a = np.array(img).astype(float)
    a *= (0.88 + 0.12 * fbm(S, 4, 3, seed=11))[..., None]
    save(a, "08_franjas_peligro.png")


# ------------------------------------------------- 09 pintura amarilla equipo
def t_forklift_paint():
    n = fbm(S, 4, 2, seed=12)
    arr = colorize(n, (206, 158, 12), (246, 202, 40))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for _ in range(90):                                   # golpes / desgaste
        x0, y0 = random.randrange(S), random.randrange(S)
        r = random.randint(1, 4)
        d.ellipse([x0 - r, y0 - r, x0 + r, y0 + r], fill=(120, 112, 104))
    save(img, "09_pintura_amarilla_equipo.png")


# ------------------------------------------------------------- 10 llanta
def t_tire():
    arr = np.full((S, S, 3), 34.0)
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for i in range(16):
        y = i * 32
        off = 16 if i % 2 else 0
        for j in range(8):
            x = j * 64 + off
            d.rounded_rectangle([x, y + 4, x + 44, y + 26], radius=8, fill=(64, 66, 70))
    img = img.filter(ImageFilter.GaussianBlur(1.2))
    a = np.array(img).astype(float) + fbm(S, 6, 5, seed=13)[..., None] * 22 - 11
    save(a, "10_hule_llanta.png")


# --------------------------------------------------------- 11 metal cepillado
def t_brushed():
    base = rng.normal(0, 1, (1, S)).repeat(S, axis=0)
    base = np.array(Image.fromarray(((base - base.min()) / np.ptp(base) * 255).astype(np.uint8))
                    .filter(ImageFilter.GaussianBlur(0.8))) / 255.0
    m = 0.75 * base + 0.25 * fbm(S, 4, 3, seed=14)
    arr = colorize(m, (128, 132, 138), (206, 210, 216))
    save(arr, "11_metal_cepillado.png")


# --------------------------------------- 12 marcador fiducial de piso (ArUco)
def t_marker():
    img = Image.new("RGB", (S, S), (238, 238, 238))
    d = ImageDraw.Draw(img)
    d.rectangle([56, 56, S - 56, S - 56], fill=(18, 18, 18))
    cell = (S - 112 - 2 * 50) // 4
    r = random.Random(5)
    for iy in range(4):
        for ix in range(4):
            if r.random() < 0.5:
                x = 56 + 50 + ix * cell
                y = 56 + 50 + iy * cell
                d.rectangle([x, y, x + cell - 2, y + cell - 2], fill=(240, 240, 240))
    a = np.array(img).astype(float) * (0.9 + 0.1 * fbm(S, 4, 3, seed=15))[..., None]
    save(a, "12_marcador_piso_fiducial.png")


# ------------------------------------------------- 13 caja de plastico azul
def t_plastic_crate():
    n = fbm(S, 4, 4, seed=16)
    arr = colorize(n, (24, 62, 132), (46, 96, 186))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for yy in range(0, S, 42):                            # nervaduras
        d.rectangle([0, yy, S, yy + 6], fill=(16, 46, 104))
        d.rectangle([0, yy + 6, S, yy + 9], fill=(78, 130, 214))
    for xx in range(0, S, 128):
        d.rectangle([xx, 0, xx + 8, S], fill=(18, 50, 112))
    save(img, "13_plastico_azul_caja.png")


# ------------------------------------------------- 14 panel de muro industrial
def t_wall_panel():
    n = fbm(S, 4, 3, seed=17)
    arr = colorize(n, (208, 208, 212), (240, 240, 244))
    img = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for xx in range(0, S + 1, 128):                       # juntas de panel
        d.rectangle([xx - 3, 0, xx + 3, S], fill=(178, 178, 184))
        d.line([(xx + 3, 0), (xx + 3, S)], fill=(250, 250, 252))
    d.rectangle([0, S - 46, S, S], fill=(150, 152, 158))  # zoclo
    d.rectangle([0, S - 50, S, S - 46], fill=(96, 98, 104))
    save(img, "14_panel_muro_industrial.png")


# ------------------------------------------------------- 15 corti,na de anden
def t_dock_door():
    arr = np.zeros((S, S, 3))
    x = np.arange(S)
    prof = 0.5 + 0.5 * np.sin(x / S * 2 * math.pi * 16 - math.pi / 2)
    prof = prof ** 0.7
    col = colorize(prof[None, :].repeat(S, 0), (108, 112, 120), (198, 202, 210))
    img = Image.fromarray(col.astype(np.uint8))
    d = ImageDraw.Draw(img)
    for yy in range(0, S, 64):                            # lamas horizontales
        d.rectangle([0, yy, S, yy + 3], fill=(70, 74, 80))
        d.rectangle([0, yy + 3, S, yy + 5], fill=(222, 226, 232))
    a = np.array(img).astype(float) * (0.9 + 0.1 * fbm(S, 5, 4, seed=18))[..., None]
    save(a, "15_cortina_anden.png")


# ------------------------------------------------------- 16 acero galvanizado
def t_galvanized():
    n = fbm(S, 6, 5, seed=19)
    m = (n > 0.52).astype(float) * 0.35 + n * 0.65
    arr = colorize(m, (140, 146, 152), (214, 220, 226))
    save(arr, "16_acero_galvanizado.png")


if __name__ == "__main__":
    random.seed(3)
    print("Generando texturas en", OUT)
    t_concrete(); t_floor_lane(); t_cardboard(); t_pallet_wood()
    painted_steel((32, 70, 150), "05_acero_rack_azul.png")
    painted_steel((168, 38, 34), "06_acero_rack_rojo.png")
    t_diamond_plate(); t_hazard(); t_forklift_paint(); t_tire(); t_brushed()
    t_marker(); t_plastic_crate(); t_wall_panel(); t_dock_door(); t_galvanized()
    print("Listo:", len(os.listdir(OUT)), "archivos")
