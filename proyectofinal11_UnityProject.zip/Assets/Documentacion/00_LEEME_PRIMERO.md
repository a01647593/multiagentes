# Tarea G1 — Modelado, texturizado e iluminación (Reto: almacén automatizado)

Este paquete contiene **todo lo necesario para armar la entrega**: un generador que
construye la escena con la API de ProBuilder, 16 texturas propias y la documentación.

---

## 1. Puesta en marcha (5 minutos)

1. Crea o abre un proyecto de **Unity 6 (6000.x)**.
2. `Window > Package Manager > Unity Registry > ProBuilder` → **Install**.
   (Es obligatorio: todo el modelado usa su API.)
3. Copia la carpeta `Assets/` de este paquete dentro del `Assets/` de tu proyecto,
   o importa el `.unitypackage`. Deben quedar:
   ```
   Assets/Editor/RetoAlmacen/   (5 scripts C#)
   Assets/Textures/             (16 PNG)
   Assets/Documentacion/
   ```
4. Espera a que Unity compile (no debe haber errores en consola).
5. Menú superior → **Reto Almacen > Generador de escena** → botón **GENERAR TODO**.
6. Cuando termine (≈10–30 s), menú → **Reto Almacen > Exportar UnityPackage de entrega**
   y sube ese archivo a Canvas.

> Si el proyecto es **URP**, el generador detecta el pipeline y usa
> `Universal Render Pipeline/Lit`. Si es **Built-in**, usa `Standard`. No hay que tocar nada.

---

## 2. Qué genera exactamente

| Elemento | Cantidad | Dónde queda en la jerarquía |
|---|---|---|
| Vehículos con material asignado | **6** | `RETO_ALMACEN / VEHICULOS` |
| Texturas (archivos de imagen) | **16** | `Assets/Textures` |
| Materiales creados | 27 | `Assets/Materials` |
| Nave, andenes, racks, obstáculos | ~1 500 objetos ProBuilder | `RETO_ALMACEN / ALMACEN` |
| Luminarias con `Light` real | 9 + sol + relleno | `RETO_ALMACEN / ALMACEN / Iluminacion` |
| Prefabs de vehículos | 6 | `Assets/Prefabs/Vehiculos` |

### Los 6 vehículos

| # | Modelo | Por qué está en el reto |
|---|---|---|
| 1 | **Montacargas contrabalanceado E80** | El equipo real que se está automatizando |
| 2 | **Robot montacargas con LiDAR** | El prototipo del video (LiDAR, ruedas naranjas, electrónica expuesta) |
| 3 | **Transpaleta eléctrica** | Movimiento de tarima a nivel de piso |
| 4 | **Apilador / stacker** | Estiba en niveles bajos, pasillo angosto |
| 5 | **AGV plano tipo Kiva** | Alternativa de automatización a comparar |
| 6 | **Tractor de arrastre + carro** | Movimiento de lotes entre andén y racks |

### El entorno (26 × 24 m)

- Muro **sur**: 4 andenes de embarque `D1–D4` con cortina, marco, rampa niveladora,
  defensas de hule, semáforo y franja de aproximación.
- Muro **norte**: `INBOUND AREA` con 4 carriles `L1–L4` y bandas de rodillos.
- **3 filas dobles** de rack selectivo (4 bahías × 2 niveles) + 2 racks contra el muro
  oriente, cargados con tarimas de madera/plástico y estibas de cartón.
- **Obstáculos a evitar**: columnas estructurales con protección, oficina de control
  con cristal y mobiliario, banco de mantenimiento, barandales, conos, contenedores,
  extintores, estación de carga de baterías y pilas de tarimas vacías.
- **Marcadores fiduciales** pintados en el piso para la localización del robot.

Ver `plano_layout.png` para el plano en planta con medidas.

---

## 3. Cómo se cubre la rúbrica

| Criterio | Peso | Evidencia |
|---|---|---|
| Modelos de vehículos diferentes, con materiales | 40 % | 6 vehículos, cada pieza con material asignado explícitamente. Prefabs en `Assets/Prefabs/Vehiculos`. |
| Ejemplos de texturas | 20 % | 16 PNG **originales** de 512×512, seamless, generados para este proyecto (ver `02_Texturas.md`). |
| Modelo del entorno | 40 % | Nave completa modelada con ProBuilder, con obstáculos, andenes, racks e iluminación. |

**Todo el modelado usa exclusivamente primitivas de ProBuilder**
(`ShapeGenerator.GenerateCube / GenerateCylinder / GeneratePrism / GeneratePlane /
GenerateCone`). No hay ningún mesh importado de fuera.

---

## 4. Opciones del generador

| Opción | Para qué sirve |
|---|---|
| **Generar techo** | Actívalo solo para renders interiores; apagado permite ver la nave desde arriba. |
| **Agregar colliders** | `MeshCollider` en todo el entorno, listo para simular navegación del robot. |
| **Marcar entorno como Static** | Necesario si van a hornear iluminación (`Window > Rendering > Lighting > Generate Lighting`). |
| **Crear cámara de presentación** | Cámara en tres cuartos para el render de la entrega. |
| **Guardar vehículos como Prefab** | Deja los 6 modelos reutilizables para la fase de simulación. |

Botones adicionales: *Solo vehículos*, *Solo entorno*, *Reconstruir materiales*, *Limpiar*.

---

## 5. Antes de entregar — checklist

- [ ] La consola no tiene errores rojos.
- [ ] `Assets/Textures` tiene los 16 PNG y todos se ven en el inspector.
- [ ] Los 6 vehículos están en la escena y **cada uno se ve con color/textura**
      (si algo sale rosa: `Reto Almacen > Generador > Reconstruir materiales`).
- [ ] La escena está guardada en `Assets/Scenes/Almacen_Reto.unity`.
- [ ] Exportaron con **Reto Almacen > Exportar UnityPackage de entrega**.
- [ ] Tomaron 3–4 capturas (vista general, andenes, pasillo con el robot, close-up del E80)
      por si el profe pide evidencia visual.

---

## 6. Para la presentación

`01_Guia_Manual_ProBuilder.md` explica cómo se modeló cada pieza **a mano** con las
herramientas de ProBuilder (New Shape, Extrude, Bevel, Auto UV). Úsenlo para poder
explicar y modificar el modelo sin depender del script — es lo que suelen preguntar.
